package com.att.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "UserActivity")
public class UserActivity {
	
	@Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "UserTabActivitySeq")
    @SequenceGenerator(name = "UserTabActivitySeq", sequenceName = "USER_TAB_ACTIVITY_SEQ", allocationSize = 1, initialValue=1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "app_id")
    private int app_id;

    @Column(name = "att_id")
    private String att_id;
    
    @Column(name = "event_id")
    private int event_id;

    public int getEvent_id() {
		return event_id;
	}

	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}

	@Column(name = "updatedDateTime")
    private LocalDateTime updatedDateTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public String getAtt_id() {
		return att_id;
	}

	public void setAtt_id(String att_id) {
		this.att_id = att_id;
	}

	public LocalDateTime getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	@Override
	public String toString() {
		return "UserActivity [id=" + id + ", app_id=" + app_id + ", att_id=" + att_id + ", event_id=" + event_id
				+ ", updatedDateTime=" + updatedDateTime + "]";
	}

	public UserActivity( int app_id, String att_id, int event_id, LocalDateTime updatedDateTime) {
		super();
		this.app_id = app_id;
		this.att_id = att_id;
		this.event_id = event_id;
		this.updatedDateTime = updatedDateTime;
	}
	
	
	

	
    

}

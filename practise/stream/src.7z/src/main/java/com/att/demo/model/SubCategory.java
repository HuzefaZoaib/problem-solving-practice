package com.att.demo.model;

public class SubCategory {

	private int category_id;
	private int subcategory_id;
	private String subcategory_name;
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	@Override
	public String toString() {
		return "SubCategory [category_id=" + category_id + ", subcategory_id=" + subcategory_id + ", subcategory_name="
				+ subcategory_name + "]";
	}
	public SubCategory(int category_id, int subcategory_id, String subcategory_name) {
		super();
		this.category_id = category_id;
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
	}



}
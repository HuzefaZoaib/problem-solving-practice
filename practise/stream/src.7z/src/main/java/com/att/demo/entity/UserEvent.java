package com.att.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "UserEvent")
public class UserEvent 
{
	
	@Id
    @Column(name = "id")
    private Integer id;
	
	@Column(name = "eventName")
    private String eventName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	@Override
	public String toString() {
		return "UserEvent [id=" + id + ", eventName=" + eventName + "]";
	}

	public UserEvent(Integer id, String eventName) {
		super();
		this.id = id;
		this.eventName = eventName;
	}
	
	
	

}

package com.att.demo.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.att.demo.entity.FunctionalMapping;
import com.att.demo.exception.ErrorResponse;
import com.att.demo.model.*;
import com.att.demo.service.FunctionMappingService;
import com.att.demo.util.web.WebRequestUtil;
import org.springframework.http.ResponseEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.att.demo.nlp.OpenNLPNounPhraseExtractor;

import com.att.demo.entity.AppMaster;
import com.att.demo.service.AppMasterService;
import com.att.demo.service.AppMasterServiceImpl.OwnerRecord;

import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@RestController
@Slf4j
@MultipartConfig
public class AppMasterController {

	
	@Autowired
	private AppMasterService appMasterService;
	
	 @Autowired
	 OpenNLPNounPhraseExtractor openNLPNounPhraseExtractor;

	@Autowired
	private FunctionMappingService functionMappingService;

	@Autowired
	private WebRequestUtil webRequestUtil;

	@GetMapping(value = "/restcontroller-get-app-master-data")
	public List<AppMaster> findAll(HttpServletRequest request)  {
		return appMasterService.getAppMasters();
	}
	@GetMapping(value = "/restcontroller-get-app-master-data-by-id/{id}")
	public AppMasterDetails find(@PathVariable String id) {
		return appMasterService.getAppMasterByItapID(id);
	}

	@PostMapping(value = "/restcontroller-app-master-data-save")
	public HttpStatusCode AppMasterInster(@RequestBody AppMaster appMaster) {
		appMasterService.saveAppMaster(appMaster);
		return HttpStatus.CREATED;
	}
	
	@PostMapping(value = "/restcontroller-app-master-data-saveall")
	public HttpStatusCode AppMasterInsterAll(@RequestBody List<AppMaster> appMasterList) {
		appMasterService.saveAppMasters(appMasterList);
		return HttpStatus.CREATED;

	}

//	@DeleteMapping(value = "/restcontroller-app-master-data-delete/{itapid}")
//	public String AppMasterDelete(@PathVariable String itapid) {
//
//		return appMasterService.deleteAppMasterByItapID(itapid);
//	}
	
   
	
	@PostMapping(value="/restcontroller-app-master-data-based-on-search")
	public SearchResponse GetAppMasterDataBySearch(@RequestBody SearchRequest searchRequest) {
		return appMasterService.getAppMasterBySearch(searchRequest);
	}
	
	@PostMapping(value="/restcontroller-app-master-data-based-on-Filter")
	public SearchReponseWithFilter GetAppMasterDataByFilter(@RequestBody SearchRequest searchRequest) {
		return appMasterService.getAppMasterByFilter(searchRequest);
	}
	
	@GetMapping(value="/loginPage")
	public String LoginMessage() throws Exception
	{
//			  Desktop desktop = java.awt.Desktop.getDesktop();
//			  URI oURL = new URI("http://www.google.com");
//			  desktop.browse(oURL);
        return "SucceddfulLogin";
	}
	
	
	@PostMapping(value="/addAppIdToFavorite")
	public FavoriteRequest AddAppIdToFavorite(@RequestBody FavoriteRequest favoriteRequest) {
		return appMasterService.addAppIdToFavorite(favoriteRequest);
	}

	@GetMapping(value= "/getFavoriteAppsByAttId/{att_id}")
	public List<Integer> getAllFavoriteApps(@PathVariable String att_id){
		return appMasterService.getFavoriteAppByUserId(att_id);
	}


	@GetMapping(value = "/getFavoriteAppDetailsByAttId/{att_id}")
	public List<AppMasterDetails> getFavoriteAppMasterDetailsByAttId(@PathVariable String att_id){
		return appMasterService.getFavoriteAppMasterDetailsByAttId(att_id);
	}

	@GetMapping(value="/getUserFullName/{appContactId}/{appOwnerId}")
	public List<String> GetUserFullName(@PathVariable String appContactId, @PathVariable String appOwnerId) throws Exception
	{
		List<String> full_name=List.of(this.webRequestUtil.getUserFullNameWithAttId(appContactId),
										this.webRequestUtil.getUserFullNameWithAttId(appOwnerId));
		return full_name;
	}

	@GetMapping(value="/getAllAppContacts")
	public Map<String,String> GetAllAppContactFullName() {
		return this.appMasterService.getLoadedAppContacts();
	}

	@PostMapping(value = "/addAppIdtoRecent")
	public void AddAppIdToRecent(@RequestBody RecentRequest recentRequest) {
		 appMasterService.addAppIdToRecent(recentRequest);
	}

	@GetMapping(value="/getRecentTenAppIds/{user_id}")
	public List<AppMasterDetails> GetRecentTenAppIds(@PathVariable String user_id)
	{

		return appMasterService.getRecentTenAppIds(user_id);
	}


	@GetMapping(value="/getRecentAndFavorite/{user_id}")
	public List<AppMasterDetails> GetRecentAndFavorite(@PathVariable String user_id)
	{

		return appMasterService.getRecentAndFavorite(user_id);
	}


	@PostMapping(value="/updateFavoriteOrder")
	public String updateFavoriteOrder(@RequestBody FavoriteOrderAttId favoriteOrderAttId )
	{

		return appMasterService.updateFavoriteOrder(favoriteOrderAttId);
	}

	@GetMapping(value="/allMyApps/{user_id}")
	public List<AppMasterDetails> getAllMyApps(@PathVariable String user_id )
	{

		return appMasterService.getAllMyApps(user_id);
	}


	@GetMapping(value="/learnMore/{catgeory_id}/{subcatgory_name}")
	public String getLearnMore(@PathVariable int catgeory_id,@PathVariable String subcatgory_name )
	{

		return appMasterService.getLearnMore(catgeory_id,subcatgory_name);
	}







	@GetMapping(value="/getSubCategories/{categor_id}")
	public List<com.att.demo.model.SubCategory> getCategorySubCategory(@PathVariable int categor_id) {
		return appMasterService.getSubCategories(categor_id);
	}

	@GetMapping(value="/getAppNameDropDownData")
	public List<AppNameDropDownData> getAppNameDropDownData() {
		return appMasterService.getAppNameDropDownData();
	}

	@GetMapping(value="/getSubCatogeryId/{subcategoryName}")
	public int getSubCatogeryId(@PathVariable String subcategoryName) {
		return appMasterService.getSubCatogeryId(subcategoryName);
	}

	@GetMapping(value="/allMasterData")
	public Map<String, List> getMasterData() {

		return appMasterService.getMasterDropDownData();

//		return data;
	}

	@PostMapping(value = "/updateKeywords/{app_id}")
	public String updateKeywords(@PathVariable int app_id,@RequestBody List<String> keywords)
	{
		return appMasterService.updateKeywords(app_id,keywords);
	}

	@PostMapping(value="/addNewApplication")
	public String addNewApplication(@RequestBody AppMaster appMasterDetail)
	{

		System.out.println(appMasterDetail);
		return appMasterService.addNewApplication(appMasterDetail);

	}

	@GetMapping(value = "/getAppKeyWords/{app_id}")
	public List<String> getAppKeyWords(@PathVariable int app_id)
	{
		return appMasterService.getAppKeyWords(app_id);
	}

	@GetMapping(value = "/getAppFunctionalMappingIds/{appId}")
	public List<Integer> getAppFunctionalMappingIds(@PathVariable int appId) {
		return appMasterService.getAppFunctionalMappingIds(appId);
	}

	@PostMapping(value = "/tabSwitched")
	public String tabSwitched(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.GAIN_FOCUS, httpServletRequest);
	}

	@PostMapping(value = "/tabClosed")
	public String tabClosed(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.CLOSED, httpServletRequest);
	}

	@PostMapping(value = "/tabLaunched")
	public String tabLaunched(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.LAUNCHED, httpServletRequest);
	}

	@PostMapping(value = "/tabSwitchedDueToTabClosed")
	public String tabSwitchedDueToTabClosed(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.GAIN_FOCUS, httpServletRequest);
	}

	@PostMapping(value = "/tabLaunchedInNewBrowser")
	public String tabLaunchedInNewBrowser(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.LAUNCHED_IN_NEW_BROWSER, httpServletRequest);
	}

	@PostMapping(value = "/tabLostFocus")
	public String tabLostFocus(@RequestBody int app_id, HttpServletRequest httpServletRequest)
	{
		return appMasterService.tabActivity(app_id, AppMasterService.TAB_ACTIVITY.LOST_FOCUS, httpServletRequest);
	}

	@PostMapping(value = "/nlp-keyword-generate")
    public List<String> generateKeywordsNlp(@RequestBody String description) throws IOException {
        return openNLPNounPhraseExtractor.nounPhraseExtractor(description);
    }

	@GetMapping(value = "/getApplicationOwnerFullName/{attid}")
	public List<OwnerRecord> getApplicationOwnerFullName(@PathVariable String attid) throws Exception
	{
		return List.of(new OwnerRecord(attid,this.webRequestUtil.getUserFullNameWithAttId(attid)));
		//return appMasterService.getApplicationOwnerFullName(attid);
	}

	@GetMapping(value = "/getApplicationContactFullName/{attid}")
	public List<OwnerRecord> getApplicationContactFullName(@PathVariable String attid) throws Exception
	{
		return List.of(new OwnerRecord(attid,this.webRequestUtil.getUserFullNameWithAttId(attid)));
		//return appMasterService.getApplicationContactFullName(attid);
	}

	/*
	 * API to upload the Application Thumbnail into file server system
	 * */
	@PostMapping(value="updateExistingApplication", consumes = "multipart/form-data")
	public ResponseEntity<?> uploadAppThumbnail(HttpServletRequest httpServletRequest,
			@RequestParam(value="thumbnail", required=false) MultipartFile thumbnail,
			@RequestParam(value="uploadAppInfo", required=true) String uploadAppInfo,
			@RequestParam(value = "category", required = true) String category,
			@RequestParam(value = "subcategory", required = true) String subcategory,
			@RequestParam(value = "jobAidDocument", required = false) Optional<MultipartFile> jobAidDocument){

		// fetch the parameters from httpServletRequest starting with the "jobAidDocument" prefix
		// jobAidDocuments key: httpParamName, value: MultipartFile
		Map<String, MultipartFile> jobAidDocuments = new HashMap<>();
		if(httpServletRequest instanceof MultipartHttpServletRequest) {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) httpServletRequest;
			for(Map.Entry<String, List<MultipartFile>> entry : multipartRequest.getMultiFileMap().entrySet()) {
				if (entry.getKey().startsWith("jobAidDocument")) {
					jobAidDocuments.put(entry.getKey(), entry.getValue().get(0));
				}
			}
		}

		return this.appMasterService.uploadAppThumbnail(httpServletRequest, thumbnail, uploadAppInfo, category, subcategory, jobAidDocuments);
	}

	/*
	* API for Direct Access URL to Thumbnails which will be consumed by ngINX when the page is served
	* */
	@GetMapping(value="/image")
	public ResponseEntity<?> getAppThumbnail(HttpServletRequest httpServletRequest,
			@RequestParam("category") String category,
			@RequestParam("subcategory") String subcategory,
			@RequestParam("img") String imgName) {
		return this.appMasterService.getAppThumbnail(httpServletRequest, category, subcategory, imgName);
	}

	@GetMapping(value = "/view-more/{categoryId}/{subcategoryId}/{retiredToggle}")
	public ResponseEntity<?> getViewMoreData(@PathVariable int categoryId,@PathVariable int subcategoryId, @PathVariable boolean retiredToggle){
		return appMasterService.getViewMoreData(categoryId, subcategoryId, retiredToggle);
	}

	@GetMapping(value = "/functional-mappings")
	public List<FunctionalMappingTree> getFunctionalMappings(HttpServletRequest request){
		return functionMappingService.getFunctionMappingTree(request);
	}

	@PostMapping(value = "/functional-mappings/{parentId}")
	public FunctionalMappingTree saveFunctionalMappingNode(@PathVariable Integer parentId, @RequestBody String name,
														   @RequestParam("appId") Optional<String> appId,
														   HttpServletRequest httpServletRequest){

		FunctionalMapping newFunctionalMapping = functionMappingService.saveNewFunctionalMapping(parentId, name, appId, httpServletRequest);

		return new FunctionalMappingTree(newFunctionalMapping.getId(),
											newFunctionalMapping.getName(), newFunctionalMapping.getLevel(),
											newFunctionalMapping.getStatus());
	}

	@GetMapping(value="/getFullName/{attId}")
	public String getUserFullName(@PathVariable String attId) throws Exception {
		return this.webRequestUtil.getFullNameFromAttID(attId);
	}

	@ExceptionHandler(org.springframework.web.multipart.MaxUploadSizeExceededException.class)
	public ResponseEntity<ErrorResponse> handleMaximumSizeUploadException(Exception ex) {
		//logger.error("Exception occurred in Feature Request: "+ex.getMessage(), ex);
		ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), "Maximum file size exceeded. Please upload a smaller file.");
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
}
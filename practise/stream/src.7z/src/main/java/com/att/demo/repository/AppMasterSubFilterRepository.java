package com.att.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.AppMaster;
import com.att.demo.entity.AppMasterSubFilter;

@Repository
public interface AppMasterSubFilterRepository extends JpaRepository<AppMasterSubFilter, Integer> {
//	 @Query(nativeQuery = true,value = "select * from app_master where :filterName = :subFilterName")
//	    List<AppMaster> retrieveSubFilters(@Param("filterName") String filterName, @Param("subFilterName") String subFilterName);

}
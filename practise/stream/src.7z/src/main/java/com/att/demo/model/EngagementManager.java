package com.att.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class EngagementManager {

    private Integer id;
    private String attId;
    private String fullName;
    private Long roleId;
    private String market;
    private String avpAttId;
    private String avpFullName;

    public String getUserId() {
        return attId;
    }
}

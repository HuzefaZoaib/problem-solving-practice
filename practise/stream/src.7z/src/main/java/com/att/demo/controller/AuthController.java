package com.att.demo.controller;

import com.att.demo.security.AuthenticationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(HttpServletRequest httpServletRequest) {
        return authenticationService.authenticateUser(httpServletRequest);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logoutUser(final HttpServletResponse response) {
        ResponseCookie responseCookie= ResponseCookie.from("jwt", null)
                .httpOnly(true)
                .secure(true)
                .path("/")
                .maxAge(0)
                .build();

        return ResponseEntity.ok()
                .header("Set-Cookie", responseCookie.toString())
                .build();
    }

    @GetMapping("/validateToken")
    public ResponseEntity<?> validateToken(final HttpServletRequest request){
        return authenticationService.authenticateUserToken(request);
    }
}
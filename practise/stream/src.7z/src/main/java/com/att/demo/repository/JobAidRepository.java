package com.att.demo.repository;

import com.att.demo.entity.JobAid;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JobAidRepository extends JpaRepository<JobAid, Long> {

    // Custom query methods can be defined here if needed
    // For example:
    // List<JobAid> findByAppId(Integer appId);

    List<JobAid> findByAppId(Integer appId);

    void deleteByAppId(Integer appId);
}

package com.att.demo.model;

import lombok.*;

@Getter
@Setter
@ToString
public class AppNameDropDownData {

    private String key;
    private String value;
    private String categoryId;
    private String subCategoryId;

    public AppNameDropDownData(String key, String value, String categoryId, String subCategoryId) {
        this.key = key;
        this.value = value;
        this.categoryId = categoryId;
        this.subCategoryId = subCategoryId;
    }
}

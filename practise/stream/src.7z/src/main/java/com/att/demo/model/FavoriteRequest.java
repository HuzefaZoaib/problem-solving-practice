package com.att.demo.model;

public class FavoriteRequest 
{
	private String att_id;
	private int app_id;
	private boolean insert_delete;
	
	
	public boolean isInsert_delete() {
		return insert_delete;
	}
	public void setInsert_delete(boolean insert_delete) {
		this.insert_delete = insert_delete;
	}
	public String getAtt_id() {
		return att_id;
	}
	public void setAtt_id(String att_id) {
		this.att_id = att_id;
	}
	public int getApp_id() {
		return app_id;
	}
	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}
	
	

}

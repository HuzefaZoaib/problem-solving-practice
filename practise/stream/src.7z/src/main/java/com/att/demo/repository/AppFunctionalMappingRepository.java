package com.att.demo.repository;

import com.att.demo.entity.AppFunctionalMapping;
import com.att.demo.entity.Keyword;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.stream.Collectors;

public interface AppFunctionalMappingRepository extends JpaRepository<AppFunctionalMapping, Integer> {

    List<AppFunctionalMapping> findByAppId(Integer appId);

    List<AppFunctionalMapping> deleteByAppId(Integer appId);

    List<AppFunctionalMapping> findByFunctionalMappingId(Integer functionalMappingId);

    default String getFunctionalMappingByAppId(Integer appId) {
        List<AppFunctionalMapping> keywords = this.findByAppId(appId);
        return keywords.stream().map(e -> String.valueOf(e.getId())).collect(Collectors.joining("|"));
    }
}
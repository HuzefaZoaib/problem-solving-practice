package com.att.demo.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.ColumnDefault;

import java.util.List;

@Table(
        uniqueConstraints = @UniqueConstraint(columnNames={"parent","child"})
)
@Entity
public class FunctionalMapping {

    public enum FunctionalMappingStatus {
        Pending,
        Approved,
        Rejected,
        Deleted;
    };

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;

    @Column(nullable = false, length = 50)
    private String parent;

    @Column(nullable = false, length = 50)
    private String child;

    @Column(nullable = false, length = 99)
    private Integer level;

    @ColumnDefault("true")
    private Boolean active = true;

    @Column(nullable = false, length = 25)
    private String updatedBy;

    @Column(nullable = false, length = 25)
    private String status = FunctionalMappingStatus.Pending.toString();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "functionalMappingId")
    private List<AppFunctionalMapping> appFunctionalMappings;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getChild() {
        return child;
    }

    public void setChild(String child) {
        this.child = child;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public List<AppFunctionalMapping> getAppFunctionalMappings() {
        return appFunctionalMappings;
    }

    public void setAppFunctionalMappings(List<AppFunctionalMapping> appFunctionalMappings) {
        this.appFunctionalMappings = appFunctionalMappings;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setName(String name) {
        this.child = name;
    }

    public String getName() {
        return this.child;
    }

    @Transient
    public void setStatus(FunctionalMappingStatus status) {
        this.status = status.name();
    }

}

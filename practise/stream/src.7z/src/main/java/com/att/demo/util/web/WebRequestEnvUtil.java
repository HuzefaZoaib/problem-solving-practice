package com.att.demo.util.web;

import com.att.demo.entity.AppConfigInDB;
import com.att.demo.model.WebPhone;
import com.att.demo.repository.AppConfigInDBRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.SystemProperties;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Enumeration;

@Profile("!local")
@Component
public class WebRequestEnvUtil implements WebRequestUtil {

    @Value("${proxy.host}")
    private String proxyHost;

    @Value("${proxy.port}")
    private int proxyPort;

    @Value("${api.url}")
    private String apiUrl;

    @Value("${ran_marketplace.apps.thumbnails.path}")
    private String thumbnailPath;

    @Value("${app.base.url}")
    private String appBaseUrl;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private AppConfigInDBRepository appConfigInDBRepository;

    @Override
    public WebPhone getUserByAttId(String attid) {

        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(30 * 1000)
                .setConnectionRequestTimeout(30 * 1000)
                .setSocketTimeout(30 * 1000)
                .build();

        HttpHost proxy = new HttpHost(proxyHost, proxyPort);
        DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);

        try (CloseableHttpClient client = HttpClients.custom()
                .setRoutePlanner(routePlanner)
                .setDefaultRequestConfig(config)
                .build()) {

            String url = apiUrl+attid;
            HttpGet request = new HttpGet(url);
            request.setHeader("Accept", "application/json");
            try (CloseableHttpResponse response = client.execute(request)) {
                String responseBody = EntityUtils.toString(response.getEntity());
                if(responseBody.contains("Handle"))
                {
                    return mapper.readValue(responseBody, WebPhone.class);

                }
                //We dont have a proper API response therefore treating as user does not exist in webphone directory.
                else return null;

            }
            catch(Exception e)
            {
                return null;
            }
        }
        catch(Exception e)
        {
            return null;
        }
    }

    public String getWebJunctionData(HttpServletRequest request) {
        Enumeration<String> headerNames = request.getHeaderNames();
        String loginId = "";
        try {
            while (headerNames.hasMoreElements()) {
                String headerName = (String) headerNames.nextElement();
                if (headerName.toLowerCase().endsWith("iv-user")) {
                    loginId = request.getHeader(headerName);
                    System.out.println("This is web junction login id "+loginId);
                }
            }

            // UnComment these lines while running on local
            if ("".equals(loginId) && null !=
                    SystemProperties.getProperty("local.server.name") &&
                    request.getServerName().contentEquals(SystemProperties.getProperty(
                            "local.server.name"))) { loginId =
                    SystemProperties.getProperty("local.user.id"); }
        } catch (Exception e) {

        }

        String _personaAttUserId = appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.PERSONA_ATT_USER_ID);
        if( _personaAttUserId != null) {
            loginId = _personaAttUserId;
        }

        return loginId;
    }
}

package com.att.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.AppMaster;

import java.util.List;

@Repository
public interface AppMasterRepository extends JpaRepository<AppMaster, Integer> {

    @Query("select app.fullName from AppMaster app where app.id = ?1")
    String getAppName(String appId);

    @Query("select CONCAT(app.name,'-',app.fullName) from AppMaster app where app.id = ?1")
    String getAppNameFullName(Integer appId);

    @Query("select app.category from AppMaster app where app.id = ?1")
    Integer getCategoryId(Integer appId);

    @Query("select app.subcategoryid from AppMaster app where app.id = ?1")
    Integer getSubcategoryId(Integer appId);

    @Query("select app.fullName, app.applicationContact from AppMaster app where app.id = ?1")
    List<String[]> getAppNameAndAppContact(String appId);

}

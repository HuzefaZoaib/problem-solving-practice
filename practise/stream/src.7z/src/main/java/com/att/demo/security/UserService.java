package com.att.demo.security;

import com.att.demo.entity.User;
import com.att.demo.repository.RoleRepository;
import com.att.demo.repository.UserRepository;
import com.att.demo.service.CategoryService;
import com.att.demo.util.web.WebRequestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {

    private static final Logger logger= LoggerFactory.getLogger(UserService.class);

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public User saveOrUpdateUser(String userId) throws Exception {
        User user= userRepository.findByUserId(userId);
        if(null == user){
            //Save user details in USER_LOGIN Table
            user= new User();
            user.setUserId(userId);
            user.setFullName(this.webRequestUtil.getFullNameFromAttID(userId));
            user.setRole(new HashSet<>(Collections.singletonList(roleRepository.findByRoleName("ACE Hub Standard"))));
        }
        //Save the new user details in FN_USER Table
        this.categoryService.checkUserInfo(userId);
        user= userRepository.save(user);
        return user;
    }

    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException{
        User user= userRepository.findByUserId(userId);
        if(null==user){
            throw new UsernameNotFoundException("User not found!");
        }

        return new org.springframework.security.core.userdetails.User( user.getUserId(),
                "",
                user.getRole()
                        .stream()
                        .map(role -> new SimpleGrantedAuthority(role.getRoleName()))
                        .collect(Collectors.toList()));
    }


}

package com.att.demo.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class AppConfigInDB {

    public enum APP_CONFIGS {
        JIRA_CREATE_ISSUE_FLAG,
        PERSONA_ATT_USER_ID,
        DISABLE_EMAIL_NOTIFICATION
    }

    @Id
    @Column(nullable = false, unique = true, length = 100)
    private String key;
    private String value;

}

package com.att.demo.util;

import com.att.demo.exception.SessionExpiredException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class RanMarketPortalUtil {
    public static HttpSession getSession(HttpServletRequest request) throws SessionExpiredException {
        if (request != null) {
            HttpSession session = request.getSession(true);
            if (session == null)
                throw new SessionExpiredException();
            else
                return session;
        } else {
            throw new SessionExpiredException();
        }
    }
}

package com.att.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.demo.model.IntelliSearch;
import com.att.demo.model.SearchRequest;
import com.att.demo.service.AppMasterService;
import com.att.demo.service.IntelliSearchService;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class IntelliSearchController 
{
	@Autowired
	private IntelliSearchService intelliSearchService;
	
	
	@GetMapping(value="/restcontroller-get-intelliSearchList/search={intelliSearchText}/{retiredToggle}")
	public IntelliSearch GetIntelliSearchList(@PathVariable String  intelliSearchText,@PathVariable boolean retiredToggle)
	{
		return intelliSearchService.getIntelliSearchList(intelliSearchText,retiredToggle);
		
	}
	
	@PostMapping(value="/restcontroller-get-intelliSearchList-Based-On-Filter")
	public IntelliSearch GetIntelliSearchListBasedOnFilter(@RequestBody SearchRequest searchRequest)
	{
		return intelliSearchService.getIntelliSearchListBasedOnFilter(searchRequest);
	}

}

package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class FeatureRequestVoting {

    public enum VOTING {
        Up,
        Down,
    }

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;

    @Column(nullable = false, length = 10)
    private String voting;

    @ManyToOne(fetch=FetchType.LAZY)
    private FeatureRequest featureRequest;

    @Column(nullable = false, length = 25)
    private String voteByAttId;
}

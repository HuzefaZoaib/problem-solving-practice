package com.att.demo.service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class ResourceUtilService {

    private static String jiraIssueUrl;

    public static String readFileFromResources(String filePath) throws IOException {
        ClassPathResource resource = new ClassPathResource(filePath);
        try (InputStreamReader reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8)) {
            return FileCopyUtils.copyToString(reader);
        }
    }

    public static String getJiraIssueUrl(String jiraIssueKey) {
        return jiraIssueUrl + jiraIssueKey;
    }

    @Autowired
    public void setJiraIssueUrl(@Value("${jira.issue.url}") String jiraIssueUrl) {
        ResourceUtilService.jiraIssueUrl = jiraIssueUrl;
    }

    public static String uploadDocument(MultipartFile document, String dirPath) throws Exception {

        if(document == null || document.isEmpty()) {
            return null;
        }

        // Create the upload directory if it doesn't exist
        Path uploadPath = Paths.get(dirPath);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Generate a unique file name with the original file extension
        String originalFilename = document.getOriginalFilename();
        String fileExtension = originalFilename != null && originalFilename.contains(".")
                ? originalFilename.substring(originalFilename.lastIndexOf("."))
                : "";
        String localFileName = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + fileExtension;

        // Save the document on server
        Path filePath = Paths.get(dirPath, localFileName);

        Files.copy(document.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        return localFileName;
    }

    public static Resource getFileResouce(String dir, String file) throws Exception {

        Path filePath= Paths.get(dir + File.separator + file);
        Resource resource = new UrlResource(filePath.toUri());
        if(resource.exists() || resource.isReadable()){
            return resource;
        } else {
            return null;
        }
    }
}

package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class JobAid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // default value is 'other'
    @Column(length = 50, nullable = false, columnDefinition = "varchar(50) default 'other'")
    private String category = "other";    // 'requestaccess' | 'userguide' | 'troubleshoot | 'other'

    private String type;        // 'none' | 'url' | 'mailto' | 'upload'
    private String url;
    private String mailto;
    private String upload;
    private String localFileName;
    private Integer appId;

    @Column(name = "description", length = 250)
    private String description;

    @Column(columnDefinition="boolean default false")
    private boolean tagToRequestAccessFlag = false;

    // this httpParamName is used to identify the Uploaded Document association to the Job Aid in HTTP Request from UI
    @Transient
    private String httpParamName;

    public void setServerFileName(String serverFileName) {
        this.localFileName = serverFileName;
    }

    public String getServerFileName() {
        return this.localFileName;
    }
}


package com.att.demo.model;

import com.att.demo.service.ResourceUtilService;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
@Setter
public class FeatureRequestWithCount {

    private int id;

    private String summary;

    private String description;

    private Integer appId;

    private String requestedByAttId;

    private String toolName;

    private Integer categoryId;

    private Integer subCategoryId;

    private Integer voteUpCount = 0;

    private Integer voteDownCount = 0;

    private Integer voteUpByLoggedInUser = 0;

    private Integer voteDownByLoggedInUser = 0;

    private String jiraIssueKey;

    private String status;

    private String updatedByAttId;

    private String updatedAt;

    private String rejectionReason;
    
    private String[] applicationContacts;

    public void setApplicationContactCsv(String applicationContactCsv) {
        if (applicationContactCsv != null && !applicationContactCsv.isBlank()) {
            this.applicationContacts = applicationContactCsv.split(",");
        } else {
            this.applicationContacts = new String[0];
        }
    }

    public String getJiraIssueUrl() {
        if(jiraIssueKey == null || jiraIssueKey.isBlank()) {
            return null;
        }
        return ResourceUtilService.getJiraIssueUrl(jiraIssueKey);
    }
}

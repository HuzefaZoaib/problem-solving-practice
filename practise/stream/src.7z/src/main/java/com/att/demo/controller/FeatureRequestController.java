package com.att.demo.controller;

import com.att.demo.entity.FeatureRequest;
import com.att.demo.exception.ErrorResponse;
import com.att.demo.model.FeatureRequestWithCount;
import com.att.demo.repository.AppMasterRepository;
import com.att.demo.repository.FeatureRequestRepository;
import com.att.demo.service.FeatureRequestService;
import com.att.demo.util.web.WebRequestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/feature-request")
public class FeatureRequestController {

    private static final Logger logger = LoggerFactory.getLogger(FeatureRequestController.class);

    @Autowired
    private FeatureRequestRepository featureRequestRepository;

    @Autowired
    private FeatureRequestService featureRequestService;

    @Autowired
    private AppMasterRepository appMasterRepository;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @GetMapping(value = "/list")
    public List<FeatureRequestWithCount> listAll(@RequestParam("appId") Optional<Integer> appId, @RequestParam("sortOrder") Optional<Integer> sortOrder, @RequestParam("sortColumn") Optional<Integer> sortColumn) {
        String attId = webRequestUtil.getUserAttId();
        List<FeatureRequestWithCount> frs;
        if (appId.isPresent() && appId.get() > 0) {
            frs = patchToolName(featureRequestRepository.findAllForAppWithVotingCounts(appId.get(), attId));
        } else {
            frs = patchToolName(featureRequestRepository.findAllWithVotingCounts(attId));
        }

        // Sort the List of FeatureRequestWithCount by ToolName
        //frs.sort((FeatureRequestWithCount fr1, FeatureRequestWithCount fr2) -> fr1.getToolName().compareTo(fr2.getToolName()));

        return frs;
    }

    @PostMapping
    public FeatureRequestWithCount saveFeatureRequest(@RequestBody FeatureRequest featureRequest) throws Exception {

        String attId = webRequestUtil.getUserAttId();
        FeatureRequest fr = featureRequestService.saveFeatureRequest(featureRequest, attId);
        return patchToolName(featureRequestRepository.findOneWithVotingCounts(fr.getAppId(), attId, fr.getId()));
    }

    @PostMapping(value = "/{id}")
    public FeatureRequestWithCount updateFeatureRequest(@RequestBody FeatureRequest featureRequest, @PathVariable("id") Integer frId) throws Exception {

        String attId = webRequestUtil.getUserAttId();
        FeatureRequest fr = featureRequestService.updateFeatureRequest(featureRequest);
        return patchToolName(featureRequestRepository.findOneWithVotingCounts(fr.getAppId(), attId, fr.getId()));
    }

    @DeleteMapping(value = "/{id}")
    public FeatureRequestWithCount deleteFeatureRequest(@PathVariable("id") Integer frId) throws Exception {

        String attId = webRequestUtil.getUserAttId();
        FeatureRequest fr = featureRequestService.deleteFeatureRequest(frId);
        return patchToolName(featureRequestRepository.findOneWithVotingCounts(fr.getAppId(), attId, fr.getId()));
    }

    @PutMapping(value = "/vote/{featureRequestId}/up")
    public FeatureRequestWithCount voteUp(@PathVariable("featureRequestId") Integer featureRequestId) {
        String attId = webRequestUtil.getUserAttId();
        featureRequestService.voteUp(featureRequestId, attId);
        return patchToolName(featureRequestService.getFeatureRequestWithVotingCounts(featureRequestId, attId));
    }

    @PutMapping(value = "/vote/{featureRequestId}/down")
    public FeatureRequestWithCount voteDown(@PathVariable("featureRequestId") Integer featureRequestId) {

        String attId = webRequestUtil.getUserAttId();
        featureRequestService.voteDown(featureRequestId, attId);
        return patchToolName(featureRequestService.getFeatureRequestWithVotingCounts(featureRequestId, attId));
    }

    public List<FeatureRequestWithCount> patchToolName(List<FeatureRequestWithCount> frs) {

        frs.forEach(this::patchToolName);

        return frs;
    }

    public FeatureRequestWithCount patchToolName(FeatureRequestWithCount fr) {
        if (fr.getAppId() != null && fr.getAppId() > 0) {
            List<String[]> data = appMasterRepository.getAppNameAndAppContact(Integer.toString(fr.getAppId()));
            fr.setToolName(data.get(0)[0]);
            fr.setApplicationContactCsv(data.get(0)[1]);
        } else {
            fr.setToolName("");
            fr.setApplicationContactCsv("");
        }

        return fr;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneralException(Exception ex) {
        logger.error("Exception occurred in Feature Request: {}", ex.getMessage(), ex);
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred");
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/reject/{featureRequestId}")
    public FeatureRequestWithCount rejectFeatureRequest(@PathVariable("featureRequestId") Integer featureRequestId, @RequestBody FeatureRequest featureRequest) throws Exception {
        String attId = webRequestUtil.getUserAttId();
        if (featureRequest.getStatus().equals("Rejected")) {
            featureRequestService.statusEmailToSubmitter(featureRequest);
        }
        FeatureRequest fr = featureRequestService.updateFeatureRequest(featureRequest);
        return patchToolName(featureRequestRepository.findOneWithVotingCounts(fr.getAppId(), attId, fr.getId()));
    }

}

package com.att.demo.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jms.JmsProperties.Template;
import org.springframework.stereotype.Service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.att.demo.model.Filters;
import com.att.demo.model.IntelliSearch;
import com.att.demo.model.SearchRequest;

@Service
public class IntelliSearchServiceImpl implements IntelliSearchService
{

	@Autowired
	@Qualifier("postgresqlJdbcTemplate")
	JdbcTemplate template;
	
	@Override
	public IntelliSearch getIntelliSearchList(String intelliSearchText,boolean retiredToggle) {
		
		
		IntelliSearch intelliSearch = new IntelliSearch();
		
//		select app_word.word from 
//		(select a.name,a.keywords,similarity('5G',a.name) as name_score,similarity('5G',a.keywords) as keyword_score,
//		case 
//		when similarity('5G',a.name)>similarity('5G',a.keywords) then a.name
//		when similarity('5G',a.keywords)>similarity('5G',a.name) then a.keywords
//		end as word
//		from app_master a) app_word
//		where app_word.word!=''
//		order by similarity('5G',app_word.word) desc;
		String similarWordsQuery="";
		
		
		if(retiredToggle)
		{
//			similarWordsQuery="select app_word.word from "
//					+ "(select a.name,a.keywords,similarity('"+intelliSearchText+"',a.name) as name_score,similarity('"+intelliSearchText+"',a.keywords) as keyword_score,"
//					+ "case "
//					+ "when similarity('"+intelliSearchText+"',a.name)>similarity('"+intelliSearchText+"',a.keywords) then a.name "
//					+ "when similarity('"+intelliSearchText+"',a.keywords)>similarity('"+intelliSearchText+"',a.name) then a.keywords "
//					+ "end as word "
//					+ "from app_master a) app_word "
//					+ "where app_word.word!='' and similarity('"+intelliSearchText+"',app_word.word)>0.13 "
//					+ "order by similarity('"+intelliSearchText+"',app_word.word) desc;";
			
//			similarWordsQuery="select keyword from (WITH search_result as ("
//					+ "select keyword,keyword_score from "
//					+ "	(select k.app_id,k.keyword,k.status,similarity('"+intelliSearchText+"',k.keyword)  as keyword_score  "
//					+ "	 from keyword k)A  "
//					+ "	where keyword_score>0.13  "
//					+ "	order by keyword_score desc "
//					+ ") "
//					+ "select distinct( keyword),keyword_score from search_result)B "
//					+ "order by keyword_score desc ";
			
			similarWordsQuery="select similarity_word"
					+ "			from (WITH search_result as ("
					+ "			select A.similarity_word,A.similarity_score from"
					+ "			(select k.keyword_id,k.app_id,k.keyword,k.app_name,k.status,similarity('"+intelliSearchText+"',k.keyword)  as keyword_score,similarity('"+intelliSearchText+"',k.app_name) as app_name_score,"
					+ "			 case "
					+ "		   when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then k.app_name "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then k.keyword "
					+ "		 ELSE k.full_name "
					+ "		 end as similarity_word, "
					+ "		 case "
					+ "		 when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then similarity('"+intelliSearchText+"',k.app_name) "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then similarity('"+intelliSearchText+"',k.keyword) "
					+ "		 ELSE similarity('"+intelliSearchText+"',k.full_name) "
					+ "		 end as similarity_score"
					+ "			from keyword k)A"
					+ "			where A.similarity_word!='' AND similarity_score>0.13"
					+ "			order by similarity_score desc"
					+ "			) "
					+ "			select distinct( search_result.similarity_word ),search_result.similarity_score from search_result)B "
					+ "			order by similarity_score desc ";
			
			
		}
		else
		{
			similarWordsQuery="select similarity_word"
					+ "			from (WITH search_result as ("
					+ "			select A.similarity_word,A.similarity_score from"
					+ "			(select k.keyword_id,k.app_id,k.keyword,k.app_name,k.status,similarity('"+intelliSearchText+"',k.keyword)  as keyword_score,similarity('"+intelliSearchText+"',k.app_name) as app_name_score,"
					+ "			 case "
					+ "		   when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then k.app_name "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then k.keyword "
					+ "		 ELSE k.full_name "
					+ "		 end as similarity_word, "
					+ "		 case "
					+ "		 when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then similarity('"+intelliSearchText+"',k.app_name) "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then similarity('"+intelliSearchText+"',k.keyword) "
					+ "		 ELSE similarity('"+intelliSearchText+"',k.full_name) "
					+ "		 end as similarity_score"
					+ "			from keyword k)A"
					+ "			where A.similarity_word!='' AND similarity_score>0.13 AND status='Active'"
					+ "			order by similarity_score desc"
					+ "			) "
					+ "			select distinct( search_result.similarity_word ),search_result.similarity_score from search_result)B "
					+ "			order by similarity_score desc ";
			
			
		}
		 System.out.println(similarWordsQuery);
		List<String> similarWordsList= template.queryForList(similarWordsQuery,String.class);
		List<String> uniQueWordList = new ArrayList<String>();
		for (String s : similarWordsList) {
			if(!isPresentInList(uniQueWordList, s)) {
				uniQueWordList.add(s);
			}
		}
		intelliSearch.setSearchText(intelliSearchText);
		intelliSearch.setSimilarSearch(uniQueWordList);
		
		
		return intelliSearch;
	}
	private boolean isPresentInList (List<String> list , String txt) {
		
		boolean flag = false;
		
		for(String s: list ) {
			if(s.equalsIgnoreCase(txt)) {
				flag = true;
			}
		}
		
		
		return flag;
	}
	

	@Override
	public IntelliSearch getIntelliSearchListBasedOnFilter(SearchRequest searchRequest) {
		IntelliSearch intelliSearch = new IntelliSearch();
		List<Filters> filters = searchRequest.getFilters();
		String intelliSearchText=searchRequest.getSearchText();
		
		String similarWordsQuery="";
		if(searchRequest.retiredToggle)
		{
		similarWordsQuery="select similarity_word"
				+ "			from (WITH search_result as ("
				+ "			select A.similarity_word,A.similarity_score from"
				+ "			(select k.keyword_id,k.app_id,k.keyword,k.app_name,k.status,similarity('"+intelliSearchText+"',k.keyword)  as keyword_score,similarity('"+intelliSearchText+"',k.app_name) as app_name_score,"
				+ "			 case "
				+ "		   when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then k.app_name "
				+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then k.keyword "
				+ "		 ELSE k.full_name "
				+ "		 end as similarity_word, "
				+ "		 case "
				+ "		 when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then similarity('"+intelliSearchText+"',k.app_name) "
				+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then similarity('"+intelliSearchText+"',k.keyword) "
				+ "		 ELSE similarity('"+intelliSearchText+"',k.full_name) "
				+ "		 end as similarity_score"
				+ "			from keyword k)A"
				+ "			where A.similarity_word!='' AND similarity_score>0.13 and app_id in (select app_id from app_master_sub_filter where app_id in (select app_id from app_master_sub_filter where ";
				int j = 0;
				for (Filters filter : filters) {
					j++;
					similarWordsQuery = similarWordsQuery
							+ "filter_id in (select id from filter where filter_name = '" + filter.getFiltername()
							+ "') and sub_filter_id in (select id from sub_filters where  sub_filter_name in ("
							+ getStringFormat(filter.getFiltervalues()) + ")))";

					if (j != filters.size())
						similarWordsQuery = similarWordsQuery + "and (";
				}
				similarWordsQuery = similarWordsQuery + ")";
				similarWordsQuery = similarWordsQuery+ " order by keyword_score desc "
						+ ") "
						+ "select distinct( search_result.similarity_word ),search_result.similarity_score from search_result)B "
						+ "	order by similarity_score desc ";
		}
		else
		{
			similarWordsQuery="select similarity_word"
					+ "			from (WITH search_result as ("
					+ "			select A.similarity_word,A.similarity_score from"
					+ "			(select k.keyword_id,k.app_id,k.keyword,k.app_name,k.status,similarity('"+intelliSearchText+"',k.keyword)  as keyword_score,similarity('"+intelliSearchText+"',k.app_name) as app_name_score,"
					+ "			 case "
					+ "		   when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then k.app_name "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then k.keyword "
					+ "		 ELSE k.full_name "
					+ "		 end as similarity_word, "
					+ "		 case "
					+ "		 when similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.keyword) AND similarity('"+intelliSearchText+"',k.app_name)>similarity('"+intelliSearchText+"',k.full_name) then similarity('"+intelliSearchText+"',k.app_name) "
					+ "		 when similarity('"+intelliSearchText+"',k.keyword)>similarity('"+intelliSearchText+"',k.full_name)  then similarity('"+intelliSearchText+"',k.keyword) "
					+ "		 ELSE similarity('"+intelliSearchText+"',k.full_name) "
					+ "		 end as similarity_score"
					+ "			from keyword k)A"
					+ "			where A.similarity_word!='' AND similarity_score>0.13 AND status='Active' and app_id in (select app_id from app_master_sub_filter where app_id in (select app_id from app_master_sub_filter where ";
					int j = 0;
					for (Filters filter : filters) {
						j++;
						similarWordsQuery = similarWordsQuery
								+ "filter_id in (select id from filter where filter_name = '" + filter.getFiltername()
								+ "') and sub_filter_id in (select id from sub_filters where  sub_filter_name in ("
								+ getStringFormat(filter.getFiltervalues()) + ")))";

						if (j != filters.size())
							similarWordsQuery = similarWordsQuery + "and (";
					}
					similarWordsQuery = similarWordsQuery + ")";
					similarWordsQuery = similarWordsQuery+ " order by keyword_score desc "
							+ ") "
							+ "select distinct( search_result.similarity_word ),search_result.similarity_score from search_result)B "
							+ "	order by similarity_score desc ";
			
			
		}
		
						System.out.println(similarWordsQuery);
						
						List<String> similarWordsList= template.queryForList(similarWordsQuery,String.class);
						intelliSearch.setSearchText(intelliSearchText);
						intelliSearch.setSimilarSearch(similarWordsList);
		
		return intelliSearch;
	}
	private String getStringFormat(List valueList) {

		// return String.join(", ", valueList);
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < valueList.size(); i++) {
			result.append("'");
			result.append(valueList.get(i));
			result.append("'");

			if (i < valueList.size() - 1) {
				result.append(", ");
			}
		}

		return result.toString();

	}
	
	

}
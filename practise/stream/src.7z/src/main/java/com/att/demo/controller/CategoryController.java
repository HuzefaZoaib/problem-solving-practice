package com.att.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.att.demo.model.*;
import com.att.demo.util.web.WebRequestUtil;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.demo.entity.Category;
import com.att.demo.service.AppMasterService;
import com.att.demo.service.CategoryService;
import com.att.demo.service.CategoryServiceImpl;

@RestController
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private AppMasterService appMasterService;

	@Autowired
	private CategoryServiceImpl cateServiceImpl;

	@Autowired
	private WebRequestUtil webRequestUtil;

	@GetMapping(value = "/restcontroller-get-category-data")
	public List<Category> finaAll() {

		return categoryService.getcategories();
	}

	@GetMapping(value = "/restcontroller-get-category-data-by-id/{id}")
	public Optional<Category> find(@PathVariable int id) {

		return categoryService.getCategoryByID(id);
	}

	@PostMapping(value = "/restcontroller-category-save")
	public HttpStatusCode AppMasterInster(@RequestBody Category category) {
		categoryService.saveCategory(category);

		return HttpStatus.CREATED;

	}

	@DeleteMapping(value = "/restcontroller-category-data-delete/{id}")
	public String AppMasterDelete(@PathVariable int id) {

		return categoryService.deleteCategory(id);

	}
	
	
	@GetMapping(value = "/restcontroller-category-with-count/{retiredToggle}")
	public List<Categories> getAllCategories(@PathVariable boolean retiredToggle,HttpServletRequest request)  {
		String loginId = this.webRequestUtil.getWebJunctionData(request);
		System.out.println("This user login id is: "+loginId);
		String msg=categoryService.insertAuditLog(loginId);
		return categoryService.getcategoriesWithCount(retiredToggle);
	}

	@GetMapping(value = "/restcontroller-getLoginId")
	public String getLoginId(HttpServletRequest request)
	{
		String loginId = this.webRequestUtil.getWebJunctionData(request);
		System.out.println("This user login id in getLoginId Method: "+loginId);
		return loginId;
	}

	@GetMapping(value = "/getAllCategories")
	public List<Category> _getAllCategories()  {
		return categoryService.getAllCategories();
	}
}

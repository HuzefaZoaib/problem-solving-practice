package com.att.demo.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtUtil {
    //This is the temporary secret key. Moving forward create a 64bit or uid to use it as secret key.
    private static final String SECRET_KEY="AccessConstructionAndEngineeringHubWithMarketplaceConsolidation";
    private static final long EXPIRATION_TIME= 24 * 60 * 60 * 1000; // one day in ms
    private final SecretKey key= Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));

    public String generateToken(String userId){
        return Jwts.builder().claims().subject(userId).issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .and()
                .signWith(key)
                .compact();
    }

    public Claims getClaimsFromToken(String token){
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public boolean validateToken(String token, UserDetails userDetails){
        String userId= this.getClaimsFromToken(token).getSubject();
        return userDetails.getUsername().equalsIgnoreCase(userId) && !isTokenExpired(token);
    }

    public boolean isTokenExpired(String token){
        Date expiration= this.getClaimsFromToken(token).getExpiration();
        return expiration.before(new Date());
    }
}

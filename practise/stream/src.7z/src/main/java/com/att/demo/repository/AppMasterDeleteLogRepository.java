package com.att.demo.repository;

import com.att.demo.entity.AppMasterDeleteLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppMasterDeleteLogRepository extends JpaRepository<AppMasterDeleteLog, Integer> {

}

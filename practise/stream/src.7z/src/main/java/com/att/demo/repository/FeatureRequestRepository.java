package com.att.demo.repository;

import com.att.demo.entity.FeatureRequest;
import com.att.demo.model.FeatureRequestWithCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeatureRequestRepository extends JpaRepository<FeatureRequest, Integer> {

    List<FeatureRequest> findByAppId(Integer appId);

    @Query(nativeQuery = true, name = "FeatureRequest.findAllWithVotingCounts")
    List<FeatureRequestWithCount> findAllWithVotingCounts(@Param("voteByAttId") String voteByAttId);

    @Query(nativeQuery = true, name = "FeatureRequest.findAllForAppWithVotingCounts")
    List<FeatureRequestWithCount> findAllForAppWithVotingCounts(@Param("appId") Integer appId, @Param("voteByAttId") String voteByAttId);

    @Query(nativeQuery = true, name = "FeatureRequest.findOneWithVotingCounts")
    FeatureRequestWithCount findOneWithVotingCounts(@Param("appId") Integer appId, @Param("voteByAttId") String voteByAttId, @Param("id") Integer id);

    @Override
    default FeatureRequest getById(Integer id) {
        return this.findById(id).orElseThrow();
    }

    @Query(value = "select application_contact from app_master where id = :appId", nativeQuery = true)
    List<String> fetchAppEmailContacts(@Param("appId") Integer appId);

    @Query(value = "select ul.user_id as admin_user from user_login ul join user_role ur on ul.id = ur.user_id where ur.role_id = 1", nativeQuery = true)
    List<String> fetchAppAdminEmailContacts();
}

package com.att.demo.repository;

import com.att.demo.entity.AppConfigInDB;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppConfigInDBRepository extends CrudRepository<AppConfigInDB, String> {

    AppConfigInDB findByKey(String key);

    default String getValue(AppConfigInDB.APP_CONFIGS key) {
        AppConfigInDB appConfigInDB = findByKey(key.name());
        return appConfigInDB != null ? appConfigInDB.getValue() : null;
    }
}

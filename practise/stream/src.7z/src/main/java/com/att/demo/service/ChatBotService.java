package com.att.demo.service;

import com.att.demo.model.IntelliSearch;

public interface ChatBotService
{
	String getResponse(String request) throws Exception;
	

}

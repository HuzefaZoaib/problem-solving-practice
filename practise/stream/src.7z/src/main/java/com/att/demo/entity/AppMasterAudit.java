package com.att.demo.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "AppMasterAudit")
public class AppMasterAudit
{


    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "AppMasterAuditSeq")
    @SequenceGenerator(name = "AppMasterAuditSeq", sequenceName = "APP_MASTER_AUDIT_ID_SEQ", allocationSize = 1, initialValue=1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "itap_id")
    private String ITAP;

    @Column(name = "name")
    private String name;

    @Column(name = "category_id")
    private int category;

//	@Column(name = "subcategory_id")
//	private int subcategoryid;

    @Column(name = "install_type")
    private String installType;


    @Column(name = "description_one_line")
    private String descriptionOneLine;

    @Column(name = "description")
    private String description;

    @Column(name = "image_url")
    private String imageUrl;


    @Column(name = "application_contact")
    private String applicationContact;

    @Column(name = "onboard_status")
    private boolean onboardStatus;

    @Column(name = "intended_user")
    private String intendedUser;

    @Column(name="UseCases")
    private String UseCases;


    @Column(name="subcategory_id")
    @JoinColumn(name="subcategory_id", nullable=false)
    private int subcategoryid;

    /*@Column(name="Keywords")
    private String Keywords;*/

    @Column(name="ToolProvider")
    private String ToolProvider;

    @Column(name = "app_url")
    private String appUrl;

    @Column(name="ApplicationOwner")
    private String ApplicationOwner;

    @Column(name="ApplicationType")
    private String ApplicationType;

    @Column(name="fullName")
    private String fullName;

    @Column(name = "updatedBy")
    private String updatedBy;

    @Column(name = "updatedDateTime")
    private LocalDateTime updatedDateTime;

    @Column(name="launchStatus")
    private String launchStatus;
    
    @Column(name="snapShotId")
    private Integer snapShotId;

	@Column(name="domain")
	private String domain;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getITAP() {
		return ITAP;
	}

	public void setITAP(String iTAP) {
		ITAP = iTAP;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getInstallType() {
		return installType;
	}

	public void setInstallType(String installType) {
		this.installType = installType;
	}

	public String getDescriptionOneLine() {
		return descriptionOneLine;
	}

	public void setDescriptionOneLine(String descriptionOneLine) {
		this.descriptionOneLine = descriptionOneLine;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getApplicationContact() {
		return applicationContact;
	}

	public void setApplicationContact(String applicationContact) {
		this.applicationContact = applicationContact;
	}

	public boolean isOnboardStatus() {
		return onboardStatus;
	}

	public void setOnboardStatus(boolean onboardStatus) {
		this.onboardStatus = onboardStatus;
	}

	public String getIntendedUser() {
		return intendedUser;
	}

	public void setIntendedUser(String intendedUser) {
		this.intendedUser = intendedUser;
	}

	public String getUseCases() {
		return UseCases;
	}

	public void setUseCases(String useCases) {
		UseCases = useCases;
	}

	public int getSubcategoryid() {
		return subcategoryid;
	}

	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}

	/*public String getKeywords() {
		return Keywords;
	}

	public void setKeywords(String keywords) {
		Keywords = keywords;
	}*/

	public String getToolProvider() {
		return ToolProvider;
	}

	public void setToolProvider(String toolProvider) {
		ToolProvider = toolProvider;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getApplicationOwner() {
		return ApplicationOwner;
	}

	public void setApplicationOwner(String applicationOwner) {
		ApplicationOwner = applicationOwner;
	}

	public String getApplicationType() {
		return ApplicationType;
	}

	public void setApplicationType(String applicationType) {
		ApplicationType = applicationType;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getLaunchStatus() {
		return launchStatus;
	}

	public void setLaunchStatus(String launchStatus) {
		this.launchStatus = launchStatus;
	}

	public Integer getSnapShotId() {
		return snapShotId;
	}

	public void setSnapShotId(Integer snapShotId) {
		this.snapShotId = snapShotId;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "AppMasterAudit [id=" + id + ", ITAP=" + ITAP + ", name=" + name + ", category=" + category
				+ ", installType=" + installType + ", descriptionOneLine=" + descriptionOneLine + ", description="
				+ description + ", imageUrl=" + imageUrl + ", applicationContact=" + applicationContact
				+ ", onboardStatus=" + onboardStatus + ", intendedUser=" + intendedUser + ", UseCases=" + UseCases
				+ ", subcategoryid=" + subcategoryid + /*", Keywords=" + Keywords + */", ToolProvider=" + ToolProvider
				+ ", appUrl=" + appUrl + ", ApplicationOwner=" + ApplicationOwner + ", ApplicationType="
				+ ApplicationType + ", fullName=" + fullName + ", updatedBy=" + updatedBy + ", updatedDateTime="
				+ updatedDateTime + ", launchStatus=" + launchStatus + ", snapShotId=" + snapShotId + "]";
	}

	public AppMasterAudit(String iTAP, String name, int category, String installType,
			String descriptionOneLine, String description, String imageUrl, String applicationContact,
			boolean onboardStatus, String intendedUser, String useCases, int subcategoryid, /*String keywords,*/
			String toolProvider, String appUrl, String applicationOwner, String applicationType, String fullName,
			String updatedBy, LocalDateTime updatedDateTime, Integer snapShotId) {
		super();
		ITAP = iTAP;
		this.name = name;
		this.category = category;
		this.installType = installType;
		this.descriptionOneLine = descriptionOneLine;
		this.description = description;
		this.imageUrl = imageUrl;
		this.applicationContact = applicationContact;
		this.onboardStatus = onboardStatus;
		this.intendedUser = intendedUser;
		UseCases = useCases;
		this.subcategoryid = subcategoryid;
		/*Keywords = keywords;*/
		ToolProvider = toolProvider;
		this.appUrl = appUrl;
		ApplicationOwner = applicationOwner;
		ApplicationType = applicationType;
		this.fullName = fullName;
		this.updatedBy = updatedBy;
		this.updatedDateTime = updatedDateTime;
		this.snapShotId = snapShotId;
	}
	
	
    
    
    

}

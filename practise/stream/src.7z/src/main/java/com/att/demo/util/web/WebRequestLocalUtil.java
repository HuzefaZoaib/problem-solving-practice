package com.att.demo.util.web;

import com.att.demo.entity.AppConfigInDB;
import com.att.demo.model.WebPhone;
import com.att.demo.repository.AppConfigInDBRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Profile("local")
@Component
public class WebRequestLocalUtil implements WebRequestUtil {

    @Value("${app.local.attid}")
    private String attid;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AppConfigInDBRepository appConfigInDBRepository;

    @Override
    public WebPhone getUserByAttId(String attid) {
        String url = "https://cdo.web.att.com/worker/api/" + attid;
        return restTemplate.getForObject(url, WebPhone.class);
    }

    @Override
    public String getWebJunctionData(HttpServletRequest request) {

        String _personaAttUserId = appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.PERSONA_ATT_USER_ID);
        if( _personaAttUserId != null) {
            return _personaAttUserId;
        }

        return attid;
    }
}

package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Role {

    // add method to return role name in the enum
    public enum ACEHUB_ROLES {
        STANDARD("ACE Hub Standard"),
        ADMIN("ACE Hub Admin"),
        ENGAGEMENT_MANAGER("ACE Hub Engagement Manager");

        private final String roleName;

        ACEHUB_ROLES(String roleName) {
            this.roleName = roleName;
        }

        @Override
        public String toString() {
            return roleName;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String roleName;
}
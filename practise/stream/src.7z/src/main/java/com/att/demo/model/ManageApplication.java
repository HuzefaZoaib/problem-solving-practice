package com.att.demo.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Getter
@Setter
public class ManageApplication {

    private int id;

    private String name;

    private String fullName;

    private String descriptionOneLine;

    private String applicationOwner;

    private String applicationContact;

    private boolean retiredFlag;

    private boolean hasFeatureRequest;

    public String getToolName() {
        return (name==null?"":name) +" - " +(fullName==null?"":fullName);
    }

    public boolean getHasFR() {
        return hasFeatureRequest;
    }
}

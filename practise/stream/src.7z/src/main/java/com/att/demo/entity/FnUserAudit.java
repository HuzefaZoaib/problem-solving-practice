package com.att.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "fn_user_audit")
public class FnUserAudit 
{



	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "userAuditSeq")
	@SequenceGenerator(name = "userAuditSeq", sequenceName = "USER_AUDIT_ID", allocationSize = 1)
	@Column(name = "id")
	private Integer id;

	@Column(name="orgId")
	private long orgId;

	@Column(name="attId")
	private String attId;

	@Column(name="accessedDateAndTime")
	private LocalDateTime accessedDateAndTime;

	@Column(name="resource")
	private String resource;




	public LocalDateTime getAccessedDateAndTime() {
		return accessedDateAndTime;
	}

	public void setAccessedDateAndTime(LocalDateTime accessedDateAndTime) {
		this.accessedDateAndTime = accessedDateAndTime;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getAttId() {
		return attId;
	}

	public void setAttId(String attId) {
		this.attId = attId;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	@Override
	public String toString() {
		return "fnUserAudit [id=" + id + ", orgId=" + orgId + ", attId=" + attId + ", resource=" + resource + "]";
	}







}
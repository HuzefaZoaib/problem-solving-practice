package com.att.demo.service;

import com.att.demo.entity.AppMaster;
import com.att.demo.model.IntelliSearch;
import com.att.demo.model.SearchRequest;

public interface IntelliSearchService 
{
	IntelliSearch getIntelliSearchList(String intelliSearchText,boolean retiredToggle);
	IntelliSearch getIntelliSearchListBasedOnFilter(SearchRequest searchRequest);

}

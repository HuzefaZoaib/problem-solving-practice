package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.demo.entity.AppMaster;
import com.att.demo.entity.Favorite;

@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Long>
{

	
	
	
}

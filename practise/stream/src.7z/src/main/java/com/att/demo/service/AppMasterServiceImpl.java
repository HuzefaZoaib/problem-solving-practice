package com.att.demo.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import com.att.demo.security.AuthenticationService;
import org.apache.commons.lang3.StringUtils;
import com.att.demo.entity.*;
import com.att.demo.model.*;
import com.att.demo.model.SubCategory;
import com.att.demo.repository.*;
import com.att.demo.util.web.WebRequestUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class AppMasterServiceImpl implements AppMasterService {

	private static final Logger logger= LoggerFactory.getLogger(AppMasterServiceImpl.class);

	@Autowired
	private AppMasterRepository appMasterRepository;

	@Autowired
	private FavoriteRepository favoriteRepository;

	@Autowired
	private RecentRepository recentRepository;
	
	@Autowired
	private UserTabActivityRepository userTabActivityRepository;

	@Autowired
	private FavoriteOrderRepository favoriteOrderRepository;

	@Autowired
	@Qualifier("postgresqlJdbcTemplate")
	private JdbcTemplate template;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KeywordRepository keywordRepository;

	@Autowired
	private KeywordAuditRepository keywordAuditRepository;

	@Autowired
	private AppMasterAuditRepository appMasterAuditRepository;

	@Autowired
	private AppMasterSubFilterRepository appMasterSubFilterRepository;

	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private AppMasterSubFilterAuditRepository appMasterSubFilterAuditRepository;


	@Value("${proxy.host}")
	private String proxyHost;

	@Value("${proxy.port}")
	private int proxyPort;

	@Value("${api.url}")
	private String apiUrl;

	@Value("${ran_marketplace.apps.thumbnails.path}")
	private String thumbnailPath;

	@Value("${ran_marketplace.apps.jobaid.path}")
	private String jobAidDirPath;

	@Value("${app.base.url}")
	private String appBaseUrl;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private FilterRepository filterRepository;

	@Autowired
	private SubFilterRepository subFilterRepository;

	@Autowired
	private UpdateExistingAppUtilService updateExistingAppUtilService;

	@Autowired
	private AppFunctionalMappingRepository appFunctionalMappingRepository;

	@Autowired
	private FunctionalMappingRepository functionalMappingRepository;
	
	@Autowired
	private WebRequestUtil webRequestUtil;

	@Autowired
	private EmailService emailService;

	@Autowired
	private AuthenticationService authenticateService;

	@Autowired
	private JobAidRepository jobAidRepository;

	public AppMaster saveAppMaster(AppMaster appMaster) {
		return appMasterRepository.save(appMaster);
	}

	public List<AppMaster> saveAppMasters(List<AppMaster> appMasters) {
		return appMasterRepository.saveAll(appMasters);
	}

	public List<AppMaster> getAppMasters() {
		return appMasterRepository.findAll();
	}

	public AppMasterDetails getAppMasterByItapID(String id) {

		if("9999".equals(id) && this.authenticateService.isLoginUserAdmin()) {
			return createDummyApp();
		}

		String AppQuery="SELECT * FROM APP_MASTER WHERE ID="+id;

		AppMasterDetails app = new AppMasterDetails();
		List<AppMasterDetails> results = template.query(AppQuery,
				new RowMapper<AppMasterDetails>() {
					public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {

						app.setName(rs.getString("name"));
						int categoryId = rs.getInt("category_id");
						String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
						String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
						app.setCategory(categoryName);
						int subcategoryId = rs.getInt("subcategory_id");
						String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
						String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
								subcategoryId);
						app.setSubcategory(subcategoryName);
						app.setId(rs.getInt("id"));

						app.setDescription(rs.getString("description"));
						app.setDescriptionOneLine(rs.getString("description_one_line"));
						app.setImageUrl(rs.getString("image_url"));
						app.setInstallType(rs.getString("install_type"));

						String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
								+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
								+ " and filter_id=2)";
						List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
						app.setIntendedUser(String.join(", ", IntendedUserList));
						// app.setIntendedUser(rs.getString("intended_user"));
						app.setITAP(rs.getString("itap_id"));

						final String keywords = keywordRepository.getKeywordsByAppId(rs.getInt("id"));
						app.setKeywords(keywords);
						app.setOnboardStatus(rs.getBoolean("onboard_status"));
						app.setToolProvider(rs.getString("tool_provider"));
						app.setUseCases(rs.getString("use_cases"));
						app.setDomain(rs.getString("domain"));
						app.setApplicationContact(rs.getString("application_contact"));
						app.setAppUrl(rs.getString("app_url"));
						app.setApplicationOwner(rs.getString("application_owner"));
						app.setApplicationType(rs.getString("application_type"));
						app.setFullName(rs.getString("full_name"));
						app.setLaunchStatus(rs.getString("launch_status"));
						return app;

					}

				});


		return app;
	}

	private AppMasterDetails createDummyApp() {

		String idQuery = "select nextval('app_master_seq')";
		Integer id = template.queryForObject(idQuery, Integer.class);

		AppMasterDetails app = new AppMasterDetails();
		app.setAppUrl("");
		app.setApplicationContact("");
		app.setId(id);
		app.setCategory("");
		app.setDomain("");
		app.setDescription("");
		app.setDescriptionOneLine("");
		app.setFullName("");
		app.setFunctionalMappings("");
		app.setImageUrl("");
		app.setInstallType("");
		app.setIntendedUser("");
		app.setITAP("");
		app.setKeywords("");
		app.setLaunchStatus("");
		app.setName("");
		app.setOnboardStatus(true);
		app.setSubcategory("");
		app.setToolProvider("");
		app.setUseCases("");
		app.setAddNewApplication(true);

		return app;
	}

	@Override
	public SearchResponse getAppMasterBySearch(SearchRequest searchRequest) {
		SearchResponse searchResponse = new SearchResponse();

		if (searchRequest.getFilters().isEmpty()) {
			String searchText = "%" + searchRequest.getSearchText() + "%";
			String queryWithSearchOnly = "";
			if (searchRequest.retiredToggle) {

				queryWithSearchOnly = "SELECT *, "
						+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
						+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
						+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
						+ "FROM v_app_master a "
						+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) "
						+ "ORDER BY score DESC";
				System.out.println("queryWithSearchOnly:" + queryWithSearchOnly);

			} else {
				queryWithSearchOnly = "SELECT *, "
						+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
						+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
						+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
						+ "FROM v_app_master a "
						+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) and install_type!='Retired'"
						+ " ORDER BY score DESC";
				System.out.println("queryWithSearchOnly:" + queryWithSearchOnly);
			}
			

			List<AppMasterDetails> apps = new ArrayList<>();
			@SuppressWarnings("deprecation")
			List<AppMasterDetails> results = template.query(queryWithSearchOnly,
					new Object[] { searchText, searchText, searchText, searchText, searchText,searchText },
					new RowMapper<AppMasterDetails>() {
						public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {

							AppMasterDetails app = new AppMasterDetails();
							app.setName(rs.getString("name"));
							int categoryId = rs.getInt("category_id");
							String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
							String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
							app.setCategory(categoryName);
							int subcategoryId = rs.getInt("subcategory_id");
							String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
							String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
									subcategoryId);
							app.setSubcategory(subcategoryName);
							app.setId(rs.getInt("id"));

							app.setDescription(rs.getString("description"));
							app.setDescriptionOneLine(rs.getString("description_one_line"));
							app.setImageUrl(rs.getString("image_url"));
							app.setInstallType(rs.getString("install_type"));

							String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
									+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
									+ " and filter_id=2)";
							List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
							app.setIntendedUser(String.join(", ", IntendedUserList));
							// app.setIntendedUser(rs.getString("intended_user"));
							app.setITAP(rs.getString("itap_id"));
							app.setKeywords(rs.getString("keywords"));
							app.setOnboardStatus(rs.getBoolean("onboard_status"));
							app.setToolProvider(rs.getString("tool_provider"));
							app.setUseCases(rs.getString("use_cases"));
							app.setDomain(rs.getString("domain"));
							app.setApplicationContact(rs.getString("application_contact"));
							app.setAppUrl(rs.getString("app_url"));
							app.setApplicationOwner(rs.getString("application_owner"));
							app.setApplicationType(rs.getString("application_type"));
							app.setFullName(rs.getString("full_name"));
							app.setLaunchStatus(rs.getString("launch_status"));

							apps.add(app);
							return app;

						}

					});
			
			if(apps.size()==0)
			{
				
					searchResponse.setSimilarSearchFlag(true);
					String similarWordsQuery="select app_word.word from "
							+ "(select a.name,a.keywords,similarity('"+searchRequest.getSearchText()+"',a.name) as name_score,similarity('"+searchRequest.getSearchText()+"',a.keywords) as keyword_score,"
							+ "case "
							+ "when similarity('"+searchRequest.getSearchText()+"',a.name)>similarity('"+searchRequest.getSearchText()+"',a.keywords) then a.name "
							+ "when similarity('"+searchRequest.getSearchText()+"',a.keywords)>similarity('"+searchRequest.getSearchText()+"',a.name) then a.keywords "
							+ "end as word "
							+ "from v_app_master a) app_word "
							+ "where app_word.word!='' and similarity('"+searchRequest.getSearchText()+"',app_word.word)>0.13 "
							+ "order by similarity('"+searchRequest.getSearchText()+"',app_word.word) desc;";
					System.out.println(similarWordsQuery+"similarWordsQuery");
					
					
					List<String> similarWordsList= template.queryForList(similarWordsQuery,String.class);
					if(!similarWordsList.isEmpty())
					{
						
					for(String similarWord:similarWordsList)
					{
						
					
					searchText="%"+similarWord+"%";
					
					String queryWithSearchOnlyWithSimilarSearch = "";
					if (searchRequest.retiredToggle) {

						queryWithSearchOnlyWithSimilarSearch = "SELECT *, "
								+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
								+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
								+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
								+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
								+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
								+ "FROM v_app_master a "
								+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) "
								+ "ORDER BY score DESC";
						System.out.println("queryWithSearchOnlyWithSimilarSearch:" + queryWithSearchOnlyWithSimilarSearch);

					} else {
						queryWithSearchOnlyWithSimilarSearch = "SELECT *, "
								+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
								+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
								+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
								+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
								+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
								+ "FROM v_app_master a "
								+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) and install_type!='Retired'"
								+ " ORDER BY score DESC";
						System.out.println("queryWithSearchOnlyWithSimilarSearch:" + queryWithSearchOnlyWithSimilarSearch);
					}
					//
					
					@SuppressWarnings("deprecation")
					List<AppMasterDetails> resultsWithSimilarSearch = template.query(queryWithSearchOnlyWithSimilarSearch,
							new Object[] { searchText, searchText, searchText, searchText, searchText, searchText },
							new RowMapper<AppMasterDetails>() {
								public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {

									AppMasterDetails app = new AppMasterDetails();
									app.setName(rs.getString("name"));
									int categoryId = rs.getInt("category_id");
									String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
									String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
									app.setCategory(categoryName);
									int subcategoryId = rs.getInt("subcategory_id");
									String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
									String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
											subcategoryId);
									app.setSubcategory(subcategoryName);
									app.setId(rs.getInt("id"));

									app.setDescription(rs.getString("description"));
									app.setDescriptionOneLine(rs.getString("description_one_line"));
									app.setImageUrl(rs.getString("image_url"));
									app.setInstallType(rs.getString("install_type"));

									String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
											+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
											+ " and filter_id=2)";
									List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
									app.setIntendedUser(String.join(", ", IntendedUserList));
									// app.setIntendedUser(rs.getString("intended_user"));
									app.setITAP(rs.getString("itap_id"));
									app.setKeywords(rs.getString("keywords"));
									app.setOnboardStatus(rs.getBoolean("onboard_status"));
									app.setToolProvider(rs.getString("tool_provider"));
									app.setUseCases(rs.getString("use_cases"));
									app.setDomain(rs.getString("domain"));
									app.setApplicationContact(rs.getString("application_contact"));
									app.setAppUrl(rs.getString("app_url"));
									app.setApplicationOwner(rs.getString("application_owner"));
									app.setApplicationType(rs.getString("application_type"));
									app.setFullName(rs.getString("full_name"));
									app.setLaunchStatus(rs.getString("launch_status"));

									apps.add(app);
									return app;

								}

							});
					}
					
					}
					
			}

			searchResponse.setAppMasterDetails(apps);
			List<Filter> filterParentList = filterRepository.findAllByOrderByIdAsc();
			List<ResponseFilter> filters = new ArrayList<>();
			for (Filter filter : filterParentList) {
				ResponseFilter responseFilter = new ResponseFilter();
				Integer filterParentCount = 0;
				responseFilter.setFiltername(filter.getFilterName());
				List<FilterValues> filterValuesList = new ArrayList<>();
				List<SubFilters> subFilterList = subFilterRepository
						.findByFilterIdOrderBySubFilterNameAsc(filter.getId());
				for (SubFilters subFilters : subFilterList) {
					FilterValues filterValues = new FilterValues();
					filterValues.setFilterValueName(subFilters.getSubFilterName());
					int filterCount = getFilterCount(apps, filter.getFilterName(), subFilters.getSubFilterName());
					filterParentCount = filterCount + filterParentCount;
					filterValues.setFilterValueCount(filterCount + "");
					filterValuesList.add(filterValues);
				}
				responseFilter.setFiltervalues(filterValuesList);

				int index = -1;
				for (int i = 0; i < filterValuesList.size(); i++) {
					if (filterValuesList.get(i).getFilterValueName().equals("Unknown")) {
						index = i;
						break;
					}
				}
				FilterValues unknownFilterValues = null;
				if (index != -1) {
					unknownFilterValues = filterValuesList.get(index);
					filterValuesList.remove(index);
				}

				if (unknownFilterValues != null) {
					filterValuesList.add(unknownFilterValues);
				}

				responseFilter.setFiltervalues(filterValuesList);

				responseFilter.setFilterNameCount(apps.size());
				filters.add(responseFilter);
			}
			searchResponse.setResponseFilter(filters);
			List<String> categoryNames = Arrays.asList("Plan", "Design", "Build", "Operate");
			searchResponse.setCategoryNames(categoryNames);
			searchResponse.setSearchText(searchText.substring(1,searchText.length()-1));
			return searchResponse;
		}

		else {
			String searchText = "%" + searchRequest.getSearchText() + "%";

			List<Filters> filters = searchRequest.getFilters();
			System.out.println(filters);
			String querywithSearchAndFilter="";
			if(searchRequest.retiredToggle)
			{
				querywithSearchAndFilter = "SELECT *, "
						+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
						+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
						+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
						+ "FROM v_app_master a "
						+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) "
						+ " AND a.id in (select app_id from app_master_sub_filter where  app_id in ";
			}
			else {
				querywithSearchAndFilter = "SELECT *, "
						+ "(ts_rank(to_tsvector('english', a.name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.full_name), plainto_tsquery('english', ?)) * 0.27 + "
						+ "ts_rank(to_tsvector('english', a.description_one_line), plainto_tsquery('english', ?)) * 0.16 + "
						+ "ts_rank(to_tsvector('english', a.description), plainto_tsquery('english', ?)) * 0.05 + "
						+ "ts_rank(to_tsvector('english', a.keywords), plainto_tsquery('english', ?)) * 0.25) AS score "
						+ "FROM v_app_master a "
						+ "WHERE to_tsvector('english', a.name || ' ' || a.description_one_line || ' ' || a.description || ' ' || a.keywords || ' ' || a.full_name) @@ plainto_tsquery('english', ?) and install_type!='Retired' "
						+ " AND a.id in (select app_id from app_master_sub_filter where  app_id in ";
			}
			

			int i = 0;
			StringBuilder queryBuilder = new StringBuilder();
			for (Filters filter : filters) {
				String filterName = filter.getFiltername();
				List<String> filterValues = filter.getFiltervalues();
				queryBuilder.append("(select app_id from app_master_sub_filter where filter_id in ")
						.append("(select id from filter where filter_name = '").append(filterName).append("')")
						.append(" and sub_filter_id in (select id from sub_filters where sub_filter_name in (");
				Iterator<String> valuesIterator = filterValues.iterator();
				while (valuesIterator.hasNext()) {
					queryBuilder.append("'").append(valuesIterator.next()).append("'");
					if (valuesIterator.hasNext()) {
						queryBuilder.append(",");
					}
				}
				queryBuilder.append("))) intersect ");
			}
			queryBuilder.setLength(queryBuilder.length() - " intersect ".length()); 
			// Remove last "intersect"
			 queryBuilder.append(")");
			 System.out.println("------Start-----");
			  System.out.println(queryBuilder.toString());
			  System.out.println("-----End------");

			querywithSearchAndFilter = querywithSearchAndFilter +queryBuilder.toString()+ "ORDER BY score DESC ";
			System.out.println(querywithSearchAndFilter + "querywithSearchAndFilter");
			List<AppMasterDetails> apps = new ArrayList<>();
			@SuppressWarnings("deprecation")
			List<AppMasterDetails> results = template.query(querywithSearchAndFilter,
					new Object[] { searchText, searchText, searchText, searchText, searchText, searchText },
					new RowMapper<AppMasterDetails>() {
						public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {

							AppMasterDetails app = new AppMasterDetails();
							app.setName(rs.getString("name"));
							int categoryId = rs.getInt("category_id");
							String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
							String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
							app.setCategory(categoryName);
							int subcategoryId = rs.getInt("subcategory_id");
							String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
							String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
									subcategoryId);
							app.setSubcategory(subcategoryName);
							app.setId(rs.getInt("id"));
							app.setDescription(rs.getString("description"));
							app.setDescriptionOneLine(rs.getString("description_one_line"));
							app.setImageUrl(rs.getString("image_url"));
							app.setInstallType(rs.getString("install_type"));

							String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
									+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
									+ " and filter_id=2)";
							List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
							app.setIntendedUser(String.join(", ", IntendedUserList));
							// app.setIntendedUser(rs.getString("intended_user"));
							app.setITAP(rs.getString("itap_id"));

							final String keywords = keywordRepository.getKeywordsByAppId(rs.getInt("id"));
							app.setKeywords(keywords);
							app.setOnboardStatus(rs.getBoolean("onboard_status"));
							app.setToolProvider(rs.getString("tool_provider"));
							app.setUseCases(rs.getString("use_cases"));
							app.setDomain(rs.getString("domain"));
							app.setApplicationContact(rs.getString("application_contact"));
							app.setAppUrl(rs.getString("app_url"));
							app.setApplicationOwner(rs.getString("application_owner"));
							app.setApplicationType(rs.getString("application_type"));
							app.setFullName(rs.getString("full_name"));
							app.setLaunchStatus(rs.getString("launch_status"));

							apps.add(app);
							return app;
						}
					});

			List<Filter> filterParentList = filterRepository.findAllByOrderByIdAsc();
			List<ResponseFilter> filters1 = new ArrayList<>();
			for (Filter filter : filterParentList) {
				ResponseFilter responseFilter = new ResponseFilter();
				Integer filterParentCount = 0;
				responseFilter.setFiltername(filter.getFilterName());
				List<FilterValues> filterValuesList = new ArrayList<>();
				List<SubFilters> subFilterList = subFilterRepository
						.findByFilterIdOrderBySubFilterNameAsc(filter.getId());
				for (SubFilters subFilters : subFilterList) {
					FilterValues filterValues = new FilterValues();
					filterValues.setFilterValueName(subFilters.getSubFilterName());
					int filterCount = getFilterCount(apps, filter.getFilterName(), subFilters.getSubFilterName());
					filterParentCount = filterCount + filterParentCount;
					filterValues.setFilterValueCount(filterCount + "");
					filterValuesList.add(filterValues);
				}

				String unknownQuery = "select count(*) from app_master " + "where " + filter.getFilterName()
						+ " in ('',null,'N/A')";
				System.out.println(unknownQuery);

				int index = -1;
				for (int j = 0; j < filterValuesList.size(); j++) {
					if (filterValuesList.get(j).getFilterValueName().equals("Unknown")) {
						index = j;
						break;
					}
				}
				FilterValues unknownFilterValues = null;
				if (index != -1) {
					unknownFilterValues = filterValuesList.get(index);
					filterValuesList.remove(index);
				}

				if (unknownFilterValues != null) {
					filterValuesList.add(unknownFilterValues);
				}

				// filterValuesList.add(new FilterValues("Unknown", unknowncount + ""));
				responseFilter.setFiltervalues(filterValuesList);

				responseFilter.setFilterNameCount(apps.size());
				filters1.add(responseFilter);
			}
			searchResponse.setResponseFilter(filters1);
			searchResponse.setAppMasterDetails(apps);
			List<String> categoryNames = Arrays.asList("Plan", "Design", "Build", "Operate");
			searchResponse.setCategoryNames(categoryNames);

			return searchResponse;
		}
	}

	private Integer getFilterCount(List<AppMasterDetails> apps, String filterName, String subFilter) {
		// TODO Auto-generated method stub
		int count = 0;
		for (AppMasterDetails app : apps) {

			int app_id = app.getId();

			String recursiveSubFilter = "select count(*) from app_master_sub_filter" + " where  app_id=" + app_id
					+ " and sub_filter_id in(select id from sub_filters" + " where sub_filter_name= '" + subFilter
					+ "')" + "and  filter_id in(select id from filter where filter_name='" + filterName + "')";

			int recursiveSubFilterCount = template.queryForObject(recursiveSubFilter, Integer.class);

			if (recursiveSubFilterCount > 0) {
				count++;
			}
		}

		System.out.println(count + " -  " + filterName + " - " + subFilter);
		return count;
	}

	private String getStringFormat(List valueList) {

		// return String.join(", ", valueList);
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < valueList.size(); i++) {
			result.append("'");
			result.append(valueList.get(i));
			result.append("'");

			if (i < valueList.size() - 1) {
				result.append(", ");
			}
		}

		return result.toString();

	}

	@Override
	public SearchReponseWithFilter getAppMasterByFilter(SearchRequest searchRequest) {

		SearchReponseWithFilter searchResponseWithFilter = new SearchReponseWithFilter();

		List<Filters> filters = searchRequest.getFilters();
//		for (Filters filter : filters) {
//			if (filter.getFiltervalues().contains("Unknown")) {
//				filter.getFiltervalues().remove("Unknown");
//				filter.getFiltervalues().add(null);
//				filter.getFiltervalues().add("");
//				filter.getFiltervalues().add("N/A");
//			}
//		}
//		System.out.println(filters);

		//{"searchText":"","filters":[{"filtername":"Install Type","filtervalues":["Cloud","Desktop"]},{"filtername":"Intended User","filtervalues":["ATS","C&E","C&E PMs"]}],"retiredToggle":false}

//		select * from app_master where id in (select app_id from app_master_sub_filter where app_id in
//				(select app_id from app_master_sub_filter where filter_id = 1 and sub_filter_id in (2,3))
//													  and (filter_id=3 and sub_filter_id in (19,20)));
		String querywithFilterOnly = "SELECT * from app_master where id in (select app_id "
				+ "from app_master_sub_filter "
				+ "where sub_filter_id in (select id from sub_filters where sub_filter_name in ( ";
		int i = 0;
		for (Filters filter : filters) {
			i++;

			querywithFilterOnly = querywithFilterOnly + getStringFormat(filter.getFiltervalues());
			if (i != filters.size())
				querywithFilterOnly = querywithFilterOnly + ",";
		}

		querywithFilterOnly = querywithFilterOnly + ")))";
//
//

//select * from app_master where id in (select app_id from app_master_sub_filter where app_id in
//(select app_id from app_master_sub_filter where
// filter_id in (select id from filter where filter_name = 'tool_provider') and sub_filter_id in
// (select id from sub_filters where  sub_filter_name='AT&T LABS'))
//		and
//	(filter_id in (select id from filter where filter_name = 'install_type')
//		and sub_filter_id in (select id from sub_filters where sub_filter_name='Cloud')));


		//{"searchText":"","filters":[{"filtername":"Install Type","filtervalues":["Cloud","Desktop"]},{"filtername":"Intended User","filtervalues":["ATS","C&E","C&E PMs"]}],"retiredToggle":false}

//select * from app_master where id in
//((select app_id from app_master_sub_filter where filter_id in
//			(select id from filter where filter_name = 'install_type')
//			and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('Desktop','Cloud')))
//intersect
//(select app_id from app_master_sub_filter where filter_id in
//			(select id from filter where filter_name = 'tool_provider')
//			and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('AT&T RAN')))
//intersect
//(select app_id from app_master_sub_filter where filter_id in
//			(select id from filter where filter_name = 'use_cases')
//			and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('Regulatory'))))
//


		StringBuilder queryBuilder = new StringBuilder("select * from app_master where id in (");
		for (Filters filter : filters)  {
			String filterName = filter.getFiltername();
			List<String> filterValues = filter.getFiltervalues();
			queryBuilder.append("(select app_id from app_master_sub_filter where filter_id in ")
					.append("(select id from filter where filter_name = '").append(filterName).append("')")
					.append(" and sub_filter_id in (select id from sub_filters where sub_filter_name in (");
			Iterator<String> valuesIterator = filterValues.iterator();
			while (valuesIterator.hasNext()) {
				queryBuilder.append("'").append(valuesIterator.next()).append("'");
				if (valuesIterator.hasNext()) {
					queryBuilder.append(",");
				}
			}
			queryBuilder.append("))) intersect ");
		}
		queryBuilder.setLength(queryBuilder.length() - " intersect ".length()); 
		// Remove last "intersect"
		 queryBuilder.append(")");
		 System.out.println("------Start-----");
		  System.out.println(queryBuilder.toString());
		  System.out.println("-----End------");
		String querywithFilterOnly1 = "";
		if (searchRequest.retiredToggle) {
			if (searchRequest.getFilters().isEmpty()) {
				querywithFilterOnly1 = "select * from app_master";

			} else {
				querywithFilterOnly1 = queryBuilder.toString();

			}

//			System.out.println("querywithFilterOnly1:" + querywithFilterOnly1);

		} else {
			if (searchRequest.getFilters().isEmpty()) {
				querywithFilterOnly1 = "select * from app_master where install_type!='Retired'";
			} else {

				StringBuilder qb = new StringBuilder("select * from app_master where install_type!='Retired' and id in (");
				for (Filters filter : filters)  {
					String filterName = filter.getFiltername();
					List<String> filterValues = filter.getFiltervalues();
					qb.append("(select app_id from app_master_sub_filter where filter_id in ")
							.append("(select id from filter where filter_name = '").append(filterName).append("')")
							.append(" and sub_filter_id in (select id from sub_filters where sub_filter_name in (");
					Iterator<String> valuesIterator = filterValues.iterator();
					while (valuesIterator.hasNext()) {
						qb.append("'").append(valuesIterator.next()).append("'");
						if (valuesIterator.hasNext()) {
							qb.append(",");
						}
					}
					qb.append("))) intersect ");
				}
				qb.setLength(qb.length() - " intersect ".length());
				qb.append(")");
				querywithFilterOnly1 = qb.toString();
				System.out.println(querywithFilterOnly1+"querywithFilterOnly1");


			}

//			System.out.println("querywithFilterOnly1:" + querywithFilterOnly1);

		}

		List<Categories> results = new ArrayList<>();

		template.query(querywithFilterOnly1, new RowMapper<Object>() {

			@Override
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				int categoryId1 = resultSet.getInt("category_id");
				String categoryQuery1 = "SELECT category_name FROM category WHERE category_id = ?";
				String categoryName1 = template.queryForObject(categoryQuery1, String.class, categoryId1);
				Categories category = null;

				for (Categories existingCategory : results) {
					if (existingCategory.getName().equals(categoryName1)) {
						category = existingCategory;
						break;
					}
				}
//				List<SubCategories> subcategories = null;
				if (category == null) {
					category = new Categories();
					category.setName(categoryName1);
					category.setSubCategories(new ArrayList<>());
					results.add(category);
				}

				Subcategories subcategory = new Subcategories();
				int subcategoryId = resultSet.getInt("subcategory_id");
				String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
				String subcategoryName = template.queryForObject(subcategoryQuery, String.class, subcategoryId);

				subcategory.setName(subcategoryName);

				List<AppMasterDetails> apps = new ArrayList<>();
				AppMasterDetails app = new AppMasterDetails();
				app.setId(resultSet.getInt("id"));
				app.setName(resultSet.getString("name"));
				app.setCategory(categoryName1);
				app.setSubcategory(subcategoryName);
				app.setDescription(resultSet.getString("description"));
				app.setDescriptionOneLine(resultSet.getString("description_one_line"));
				app.setImageUrl(resultSet.getString("image_url"));
				app.setInstallType(resultSet.getString("install_type"));

				String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
						+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
						+ " and filter_id=2)";
				List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
				app.setIntendedUser(String.join(", ", IntendedUserList));

				// app.setIntendedUser(resultSet.getString("intended_user"));
				app.setITAP(resultSet.getString("itap_id"));

				final String keywords = keywordRepository.getKeywordsByAppId(resultSet.getInt("id"));
				app.setKeywords(keywords);
				app.setOnboardStatus(resultSet.getBoolean("onboard_status"));
				app.setToolProvider(resultSet.getString("tool_provider"));
				app.setUseCases(resultSet.getString("use_cases"));
				app.setDomain(resultSet.getString("domain"));
				app.setApplicationContact(resultSet.getString("application_contact"));
				app.setAppUrl(resultSet.getString("app_url"));
				app.setApplicationOwner(resultSet.getString("application_owner"));
				app.setApplicationType(resultSet.getString("application_type"));
				app.setFullName(resultSet.getString("full_name"));
				app.setLaunchStatus(resultSet.getString("launch_status"));

				apps.add(app);
				subcategory.setApps(apps);
				category.getSubcategories().add(subcategory);
				category.setCount(category.getSubcategories().size());
				return null;
			}

		});
		// Adding other categories which are not present in results

		String allCategoriesQuery = "SELECT category_name FROM category ";
		List<String> allCategories = template.queryForList(allCategoriesQuery, String.class);
		List<String> categoriesInResult = new ArrayList<>();
		for (Categories category : results) {
			categoriesInResult.add(category.getName());

		}
		allCategories.removeAll(categoriesInResult);
//		System.out.println("allCategories:" + allCategories);
		for (String categoryNotPresent : allCategories) {
			results.add(new Categories(categoryNotPresent, 0, new ArrayList<Subcategories>()));
		}

		// To group the result based on subcategory
		List<Categories> formattedResult = new ArrayList<>();

		for (Categories category : results) {

			List<Subcategories> formattedSubCatList = new ArrayList<>();

			for (Subcategories subCat : category.getSubcategories()) {

				boolean addSubCat = true;
				for (Subcategories existingSubCategory : formattedSubCatList) {

					if (existingSubCategory.getName().equals(subCat.getName())) {
						existingSubCategory.getApps().addAll(subCat.getApps());
						addSubCat = false;
						break;
					}

				}
				if (addSubCat) {

					formattedSubCatList.add(subCat);

				}
				category.setSubCategories(formattedSubCatList);

			}
			formattedResult.add(category);
		}

		for (int index = 0; index < formattedResult.size(); index++) {
			int count = 0;
			for (int y = 0; y < formattedResult.get(index).getSubcategories().size(); y++) {
				count = count + formattedResult.get(index).getSubcategories().get(y).getApps().size();
			}
			formattedResult.get(index).setCount(count);
		}
		List<Categories> formattedOrderList = new ArrayList<Categories>();
		formattedOrderList.add(getCategoryByName("Plan", formattedResult));
		formattedOrderList.add(getCategoryByName("Design", formattedResult));
		formattedOrderList.add(getCategoryByName("Build", formattedResult));
		formattedOrderList.add(getCategoryByName("Operate", formattedResult));

		searchResponseWithFilter.setCategories(formattedOrderList);
		List<ResponseFilter> responseFilters1 = createFilter(results, searchRequest);

		searchResponseWithFilter.setResponseFilter(responseFilters1);

		return searchResponseWithFilter;
	}

	private Categories getCategoryByName(String name, List<Categories> formattedList) {
		Categories c = new Categories();
		for (Categories cat : formattedList) {
			if (cat.getName().equals(name)) {
				c = cat;
			}

		}

		return c;

	}

	private List<ResponseFilter> createFilter(List<Categories> categories, SearchRequest searchRequest) {
		List<Filter> filterParentList = filterRepository.findAllByOrderByIdAsc();
		List<ResponseFilter> responsefilters = new ArrayList<>();

		List<Filters> filters = searchRequest.getFilters();
		String querywithFilterOnly1 = "";
		StringBuilder queryBuilder = new StringBuilder("select id from app_master where id in (");
		for (Filters filter : filters)  {
			String filterName = filter.getFiltername();
			List<String> filterValues = filter.getFiltervalues();
			queryBuilder.append("(select app_id from app_master_sub_filter where filter_id in ")
					.append("(select id from filter where filter_name = '").append(filterName).append("')")
					.append(" and sub_filter_id in (select id from sub_filters where sub_filter_name in (");
			Iterator<String> valuesIterator = filterValues.iterator();
			while (valuesIterator.hasNext()) {
				queryBuilder.append("'").append(valuesIterator.next()).append("'");
				if (valuesIterator.hasNext()) {
					queryBuilder.append(",");
				}
			}
			queryBuilder.append("))) intersect ");
		}
		queryBuilder.setLength(queryBuilder.length() - " intersect ".length());
		// Remove last "intersect"
		queryBuilder.append(")");
		System.out.println("------Start-----");
		System.out.println(queryBuilder.toString());
		System.out.println("-----End------");

		if (searchRequest.retiredToggle) {
			if (searchRequest.getFilters().isEmpty()) {
				querywithFilterOnly1 = "select id from app_master";

			} else {
				querywithFilterOnly1 = queryBuilder.toString();

			}

//			System.out.println("querywithFilterOnly1:" + querywithFilterOnly1);

		} else {
			if (searchRequest.getFilters().isEmpty()) {
				querywithFilterOnly1 = "select id from app_master where install_type!='Retired'";
			} else {

				StringBuilder qb = new StringBuilder("select id from app_master where install_type!='Retired' and id in (");
				for (Filters filter : filters)  {
					String filterName = filter.getFiltername();
					List<String> filterValues = filter.getFiltervalues();
					qb.append("(select app_id from app_master_sub_filter where filter_id in ")
							.append("(select id from filter where filter_name = '").append(filterName).append("')")
							.append(" and sub_filter_id in (select id from sub_filters where sub_filter_name in (");
					Iterator<String> valuesIterator = filterValues.iterator();
					while (valuesIterator.hasNext()) {
						qb.append("'").append(valuesIterator.next()).append("'");
						if (valuesIterator.hasNext()) {
							qb.append(",");
						}
					}
					qb.append("))) intersect ");
				}
				qb.setLength(qb.length() - " intersect ".length());
				qb.append(")");
				querywithFilterOnly1 = qb.toString();
				System.out.println(querywithFilterOnly1+"querywithFilterOnly1");


			}

			System.out.println("querywithFilterOnly1 in create filter:" + querywithFilterOnly1);

		}

		List<Integer> app_ids = template.queryForList(querywithFilterOnly1, Integer.class);

		for (Filter filter : filterParentList) {
			ResponseFilter responseFilter = new ResponseFilter();
			responseFilter.setFiltername(filter.getFilterName());
			Integer filterParentCount = 0;
			List<FilterValues> filterValuesList = new ArrayList<>();

			for (SubFilters subFilters : subFilterRepository.findByFilterIdOrderBySubFilterNameAsc(filter.getId())) {
				FilterValues filterValues = new FilterValues();
				String subfiltername = subFilters.getSubFilterName();
				filterValues.setFilterValueName(subfiltername);
				int count = 0;

//				for (Categories category : categories) {
//					for (Subcategories subCategory : category.getSubcategories()) {
//						for (AppMasterDetails app : subCategory.getApps()) {
//							int app_id=app.getId();
//							String subFilterName=subfiltername;
//						 select * from app_master_sub_filter where  id=87
//					 and sub_filter_id in(select id from sub_filters
//							 where sub_filter_name='Cloud');

//				for (int app_id : app_ids) {
				String recursiveSubFilter = "";
				if (searchRequest.retiredToggle) {

					recursiveSubFilter = "select count(*) from app_master_sub_filter" + " where  app_id in ("
							+ querywithFilterOnly1 + " ) and sub_filter_id in(select id from sub_filters"
							+ " where sub_filter_name= '" + subfiltername + "')"
							+ "and  filter_id in(select id from filter where filter_name='"
							+ filter.getFilterName() + "')";



				} else {

					recursiveSubFilter = "select count(*) from app_master_sub_filter"
							+ " where sub_filter_id!=182 and app_id in (" +querywithFilterOnly1
							+ " ) and sub_filter_id in(select id from sub_filters" + " where sub_filter_name= '"
							+ subfiltername + "')"
							+ "and  filter_id in(select id from filter where filter_name='"
							+ filter.getFilterName() + "')";



				}
				System.out.println(recursiveSubFilter+":recursiveSubFilter");


				int recursiveSubFilterCount = template.queryForObject(recursiveSubFilter, Integer.class);
				System.out.println(recursiveSubFilterCount);
//					if (recursiveSubFilterCount > 0) {
//						count++;
//					}
//				}

				filterValues.setFilterValueCount(Integer.toString(recursiveSubFilterCount));
				filterValuesList.add(filterValues);
				filterParentCount = recursiveSubFilterCount; // Accumulate count for the filter
			}
//			int unknowncount = 0;
//			for (Categories category : categories) {
//				for (Subcategories subCategory : category.getSubcategories()) {
//					for (AppMasterDetails app : subCategory.getApps()) {
//						if (filter.getFilterName().equals("tool_provider")) {
//							if (app.getToolProvider().equals("") || app.getToolProvider() == null
//									|| app.getToolProvider().equals("N/A") || app.getToolProvider().equals("Unknown")) {
//								unknowncount++;
//							}
//						}
//						if (filter.getFilterName().equals("application_contact")) {
//							if (app.getApplicationContact().equals("") || app.getApplicationContact() == null
//									|| app.getApplicationContact().equals("N/A")
//									|| app.getApplicationContact().equals("Unknown")) {
//								unknowncount++;
//							}
//						}
//						if (filter.getFilterName().equals("use_cases")) {
//							if (app.getUseCases().equals("") || app.getUseCases() == null
//									|| app.getUseCases().equals("N/A") || app.getUseCases().equals("Unknown")) {
//								unknowncount++;
//							}
//						}
//						if (filter.getFilterName().equals("install_type")) {
//							if (app.getInstallType().equals("") || app.getInstallType() == null
//									|| app.getInstallType().equals("N/A") || app.getInstallType().equals("Unknown")) {
//								unknowncount++;
//							}
//						}
//						if (filter.getFilterName().equals("intended_user")) {
//							if (app.getIntendedUser() == null || app.getIntendedUser().equals("")
//									|| app.getIntendedUser().equals("N/A") || app.getIntendedUser().equals("Unknown")) {
//								unknowncount++;
//							}
//						}
//					}
//				}
//			}
////
			int index = -1;
			for (int i = 0; i < filterValuesList.size(); i++) {
				if (filterValuesList.get(i).getFilterValueName().equals("Unknown")) {
					index = i;
					break;
				}
			}
			FilterValues unknownFilterValues = null;
			if (index != -1) {
				unknownFilterValues = filterValuesList.get(index);
				filterValuesList.remove(index);
			}

			if (unknownFilterValues != null) {
				filterValuesList.add(unknownFilterValues);
			}

			responseFilter.setFiltervalues(filterValuesList);

			responseFilter.setFilterNameCount(app_ids.size());

			responsefilters.add(responseFilter);

		}
		if (searchRequest.getFilters().size() == 1) {

			int parentCount = 0;
			String filterName = searchRequest.getFilters().get(0).getFiltername();
			List<FilterValues> filterValues = new LinkedList<>();
			Filter filterObject = filterRepository.findByFilterNameOrderByIdAsc(filterName);
			List<SubFilters> subFilterList = subFilterRepository
					.findByFilterIdOrderBySubFilterNameAsc(filterObject.getId());
			for (SubFilters subFilterForCount : subFilterList) {
				FilterValues filterValue = new FilterValues();

//				select * from app_master_sub_filter where sub_filter_id in
//				(select id from sub_filters where sub_filter_name='ATS')
				String filterQuery="";
				if(searchRequest.retiredToggle)
				{
					filterQuery = "SELECT COUNT(*) FROM APP_MASTER_SUB_FILTER WHERE app_id in"
							+ "  (select id from APP_MASTER ) and sub_filter_id in"
							+ "( select id from sub_filters where sub_filter_name = '"
							+ subFilterForCount.getSubFilterName() + "') and "
							+ "filter_id in (select id from filter where filter_name = '"
							+ searchRequest.getFilters().get(0).getFiltername() + "')";


				}
				else
				{
					filterQuery = "SELECT COUNT(*) FROM APP_MASTER_SUB_FILTER WHERE app_id in "
							+ "  (select id from APP_MASTER where install_type!='Retired') and sub_filter_id in"
							+ "( select id from sub_filters where sub_filter_name = '"
							+ subFilterForCount.getSubFilterName() + "') and "
							+ "filter_id in (select id from filter where filter_name = '"
							+ searchRequest.getFilters().get(0).getFiltername() + "')";

				}


//				System.out.println("filterQuery-" + filterQuery);
				int count = template.queryForObject(filterQuery, Integer.class);
				filterValue.setFilterValueName(subFilterForCount.getSubFilterName());
				filterValue.setFilterValueCount(Integer.toString(count));
				filterValues.add(filterValue);
				parentCount = parentCount + count;

//				System.out.println("count-" + count + "-" + subFilterForCount.getSubFilterName());

			}

			int index = -1;
			for (int i = 0; i < filterValues.size(); i++) {
				if (filterValues.get(i).getFilterValueName().equals("Unknown")) {
					index = i;
					break;
				}
			}
			FilterValues unknownFilterValues = null;
			if (index != -1) {
				unknownFilterValues = filterValues.get(index);
				filterValues.remove(index);
			}

			if (unknownFilterValues != null) {
				filterValues.add(unknownFilterValues);
			}

			String filterCountQuery="";

			if(searchRequest.retiredToggle)
			{
				filterCountQuery = "select count(*) from (SELECT distinct app_id FROM APP_MASTER_SUB_FILTER WHERE sub_filter_id in"
						+ "( select id from sub_filters where sub_filter_name in ( "
						+ getStringFormat(searchRequest.getFilters().get(0).getFiltervalues()) + ")) and "
						+ "filter_id in (select id from filter where filter_name = '"
						+ searchRequest.getFilters().get(0).getFiltername() + "')) as innerquery";


			}
			else
			{
				filterCountQuery = "select count(*) from (SELECT distinct app_id FROM APP_MASTER_SUB_FILTER WHERE app_id in (select id from APP_MASTER where install_type!='Retired') and sub_filter_id in"
						+ "( select id from sub_filters where sub_filter_name in ( "
						+ getStringFormat(searchRequest.getFilters().get(0).getFiltervalues()) + ")) and "
						+ "filter_id in (select id from filter where filter_name = '"
						+ searchRequest.getFilters().get(0).getFiltername() + "')) as innerquery";




			}

			int newParentCount = template.queryForObject(filterCountQuery, Integer.class);
//			System.out.println("filterCountQuery-" + filterCountQuery);
//			System.out.println("newParentCount-" + newParentCount);
			for (ResponseFilter finalResponseFilter : responsefilters) {

				if (finalResponseFilter.getFiltername().equals(setFiltername(filterName))) {
					finalResponseFilter.removeSubFilter(finalResponseFilter.getFiltername());
					finalResponseFilter.setFiltervalues(filterValues);
					finalResponseFilter.setFilterNameCount(newParentCount);
				}
			}
		}

		return responsefilters;
	}

	public String setFiltername(String filtername) {
		filtername = filtername.replace('_', ' ');
		String[] SplittedFilterName = filtername.split(" ");
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < SplittedFilterName.length; i++) {
			String word = SplittedFilterName[i];
			SplittedFilterName[i] = SplittedFilterName[i].substring(0, 1).toUpperCase()
					+ SplittedFilterName[i].substring(1);
			sb.append(SplittedFilterName[i]);
			if (i < 1)
				sb.append(" ");
		}
		return sb.toString();
	}

	@Override
	public FavoriteRequest addAppIdToFavorite(FavoriteRequest favoriteRequest) {


		String att_id=favoriteRequest.getAtt_id();
		int app_id=favoriteRequest.getApp_id();
		String appOrderQuery = "SELECT favorder from favorite_order where att_id = '"+att_id+"'";
		List<String> favOrderList = template.queryForList(appOrderQuery, String.class);

		String favOrder = "";
		if(favOrderList.size() > 0) {
			favOrder = favOrderList.get(0);
		}
		FavoriteRequest favoriteResponse = new FavoriteRequest();
		favoriteResponse.setApp_id(app_id);
		favoriteResponse.setAtt_id(att_id);
		Favorite favorite = new Favorite();
		LocalDateTime localDateTime = LocalDateTime.now();
		favorite.setInserted_date_time(localDateTime);
		favorite.setApp_id(app_id);
		favorite.setAtt_id(att_id);
		if(favoriteRequest.isInsert_delete())
		{
			favoriteRepository.save(favorite);
			favoriteResponse.setInsert_delete(true);

			// Logic to update the order
			String newOrder = "";
			if (favOrder == "" ) {
				newOrder = app_id+"";
			} else {
				newOrder = app_id+"|"+favOrder;
			}

			FavoriteOrder favoriteOrder = new FavoriteOrder(att_id,newOrder);
			favoriteOrderRepository.save(favoriteOrder);


			return favoriteResponse;
		}
		else
		{
			String deleteFromFavorite = "DELETE FROM FAVORITE WHERE APP_ID = "+app_id+" AND ATT_ID = '"+att_id+"'";
			System.out.println(deleteFromFavorite);
			template.execute(deleteFromFavorite);
			favoriteResponse.setInsert_delete(false);
			// Logic to update the order
			String newfavOrder = removeNumberFromString(favOrder, app_id + "");
			FavoriteOrder favoriteOrder = new FavoriteOrder(att_id, newfavOrder);
			favoriteOrderRepository.save(favoriteOrder);
			return favoriteResponse;
		}


	}

	public static String removeNumberFromString(String s, String number) {
		// Use a regex to replace the number with an empty string
		String regex = "\\b" + number + "\\b\\|?|\\|?\\b" + number + "\\b";
		return s.replaceAll(regex, "").replaceAll("^\\||\\|$", "");
	}
	public List<Integer> getFavoriteAppByUserId (String userId){
		String query = "SELECT distinct(app_id) FROM FAVORITE WHERE ATT_ID = '"+userId+"'";
		return template.queryForList(query,Integer.class);
	}

	@Override
	public List<AppMasterDetails> getFavoriteAppMasterDetailsByAttId(String attId) {
		// TODO Auto-generated method stub

		String favAppOrder = "select favorder from favorite_order where att_id ='"+attId+"'";

		List<String> favAppList = template.queryForList(favAppOrder,String.class);

		String AppQuery = "select app_id from favorite where att_id = '" + attId + "' order by inserted_date_time desc";

		List<Integer> listOfRecIds = template.queryForList(AppQuery, Integer.class);

		List<AppMasterDetails> results = new ArrayList<>();

		for (int k : listOfRecIds) {
			AppMasterDetails RecAppDetails = getAppMasterByItapID(Integer.toString(k));
			results.add(RecAppDetails);
		}

		if(favAppList.size()>=1) {
			String [] arr = favAppList.get(0).split("\\|");
			List<String> appIdList = Arrays.asList(arr);
			List<AppMasterDetails> orderdApps = new ArrayList<>();

			for(String appId : appIdList) {
				for (AppMasterDetails app : results) {
					if(app.getId() == Integer.parseInt(appId)) {
						orderdApps.add(app);
					}
				}
			}
			return orderdApps;
		}

		return results;



	}


	@Override
	public String getLoginUserFullName(String LoginId) {
		String getUserFirstNameData="select first_name from fn_user where org_user_id='"+LoginId+"'";
//		String firstName=template.queryForObject(getUserFirstNameData, String.class, user_id);
		List<String> firstNameList = template.queryForList(getUserFirstNameData, String.class);
		String getUserLastNameData="select last_name from fn_user where org_user_id='"+LoginId+"'";
		List<String> lastNameList = template.queryForList(getUserLastNameData, String.class);
		String fullName = LoginId;
		if(!firstNameList.isEmpty() && ! lastNameList.isEmpty()) {
			fullName	=firstNameList.get(0)+" "+lastNameList.get(0);
		}else if(!firstNameList.isEmpty() && lastNameList.isEmpty()) {
			fullName	=firstNameList.get(0);
		}else if(firstNameList.isEmpty() && !lastNameList.isEmpty()) {
			fullName	=lastNameList.get(0);
		}

		return fullName;
	}

	@Override
	public void addAppIdToRecent(RecentRequest recentRequest) {
		// TODO Auto-generated method stub

		Recent recent = new Recent();
		String att_id=recentRequest.getAtt_id();
		recent.setAtt_id(att_id);
		int app_id=recentRequest.getApp_id();
		recent.setApp_id(app_id);
		LocalDateTime localDateTime = LocalDateTime.now();
		recent.setInserted_date_time(localDateTime);

		recentRepository.save(recent);





	}

	/**
	 *
	 */
	@Override
	public List<AppMasterDetails> getRecentTenAppIds(String user_id) {

		String sqlGetAllRecentAppIdsBasedOnAttId="select app_id from recent where att_id='"+user_id+"' order by inserted_date_time desc";
		List<Integer> listOfRecIds=template.queryForList(sqlGetAllRecentAppIdsBasedOnAttId,Integer.class);

		LinkedHashSet<Integer> hs=new LinkedHashSet<Integer>();
		for(int i:listOfRecIds)
		{
			hs.add(i);
		}
		List<AppMasterDetails> results = new ArrayList<>();
		int count=0;
		for(int k:hs)
		{
			if(count<10)
			{
				AppMasterDetails RecAppDetails=getAppMasterByItapID(Integer.toString(k));
				results.add(RecAppDetails);
				count++;

			}

		}
		return results;



	}

	@Override
	public List<AppMasterDetails> getRecentAndFavorite(String user_id) {
		// TODO Auto-generated method stub
		List<AppMasterDetails> apps = new ArrayList<>();
		String sqlRecAndFavAppDetails="select * from app_master where id in( "
				+ "	select app_id from recent where att_id='"+user_id+"' "
				+ "		union "
				+ "	select app_id from favorite where att_id = '"+user_id+"'"
				+ "	)";
		System.out.println(sqlRecAndFavAppDetails);

		List<AppMasterDetails> results = template.query(sqlRecAndFavAppDetails,
				new RowMapper<AppMasterDetails>() {
					public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {
						AppMasterDetails app = new AppMasterDetails();

						app.setName(rs.getString("name"));
						int categoryId = rs.getInt("category_id");
						String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
						String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
						app.setCategory(categoryName);
						int subcategoryId = rs.getInt("subcategory_id");
						String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
						String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
								subcategoryId);
						app.setSubcategory(subcategoryName);
						app.setId(rs.getInt("id"));

						app.setDescription(rs.getString("description"));
						app.setDescriptionOneLine(rs.getString("description_one_line"));
						app.setImageUrl(rs.getString("image_url"));
						app.setInstallType(rs.getString("install_type"));

						String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
								+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
								+ " and filter_id=2)";
						List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
						app.setIntendedUser(String.join(", ", IntendedUserList));
						// app.setIntendedUser(rs.getString("intended_user"));
						app.setITAP(rs.getString("itap_id"));

						final String keywords = keywordRepository.getKeywordsByAppId(rs.getInt("id"));
						app.setKeywords(keywords);
						app.setOnboardStatus(rs.getBoolean("onboard_status"));
						app.setToolProvider(rs.getString("tool_provider"));
						app.setUseCases(rs.getString("use_cases"));
						app.setDomain(rs.getString("domain"));
						app.setApplicationContact(rs.getString("application_contact"));
						app.setAppUrl(rs.getString("app_url"));
						app.setApplicationOwner(rs.getString("application_owner"));
						app.setApplicationType(rs.getString("application_type"));
						app.setFullName(rs.getString("full_name"));
						app.setLaunchStatus(rs.getString("launch_status"));
						apps.add(app);
						return app;

					}

				});
		return apps;
	}

	@Override
	public String updateFavoriteOrder(FavoriteOrderAttId favoriteOrderAttId) {

		try {
			FavoriteOrder favoriteOrder = new FavoriteOrder();
			String att_id=favoriteOrderAttId.getAttId();
			favoriteOrder.setAtt_id(att_id);
			String order=favoriteOrderAttId.getOrder();
			favoriteOrder.setFavorder(order);


			favoriteOrderRepository.save(favoriteOrder);

			return "SUCCESS";


		}
		catch(Exception e){
			return e.getMessage();
		}

	}

	@Override
	public List<AppMasterDetails> getAllMyApps(String user_id) {

		// union will remove duplicates, so we can use it to get unique app ids
		String myAppsQuery = "select id from app_master where application_owner='"+user_id+"' or application_contact='"+user_id+"' " +
						"union " +
						"select app_id from app_master_sub_filter where filter_id=4 and " +
						"sub_filter_id in (select id from sub_filters where sub_filter_name='"+user_id+"')";

		List<Integer> myAppsIdLIst = template.queryForList(myAppsQuery,Integer.class);
		Collections.reverse(myAppsIdLIst);

		Set<Integer> uniqueApps = new LinkedHashSet<Integer>(myAppsIdLIst);
		List<AppMasterDetails> allApps = new ArrayList<>();
		for(int id: uniqueApps) {
			AppMasterDetails app = getAppMasterByItapID(Integer.toString(id));
			allApps.add(app);
		}
		return allApps;
	}

	@Override
	public String getLearnMore(int category_id, String subcatgory_name) {
		// TODO Auto-generated method stub

		String getLearnMoreBasedOnCatSubCat="select learn_more_data from subcategory where category_id= "+category_id+" and subcategory_name= '"+ subcatgory_name+"'";

		String learnData=template.queryForObject(getLearnMoreBasedOnCatSubCat,String.class);
		return learnData;
	}

	@Override
	public List<SubCategory> getSubCategories(int categor_id){
		String categoryQuery = "select * from subcategory where category_id ="+ categor_id;
		List<SubCategory> subCategoryList = template.query(categoryQuery, new RowMapper<SubCategory>() {

			@Override
			public SubCategory mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				SubCategory  sc = new SubCategory(rs.getInt("category_id"), rs.getInt("subcategory_id"), rs.getString("subcategory_name"));
				return sc;
			}

		});

		return subCategoryList;
	}

	public List<AppNameDropDownData> getAppNameDropDownData() {
		String query = "select id, full_name as app_name, category_id, subcategory_id from app_master order by full_name";
		List<AppNameDropDownData> appNames = template.query(query, new RowMapper<AppNameDropDownData>() {

			@Override
			public AppNameDropDownData mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new AppNameDropDownData(
						Integer.toString(rs.getInt("id")),
						rs.getString("app_name"),
						Integer.toString(rs.getInt("category_id")),
						Integer.toString(rs.getInt("subcategory_id"))
				);
			}
		});

		return appNames;
	}


	@Override
	public int getSubCatogeryId(String subcategoryName) {
		// TODO Auto-generated method stub

		String getsubcategoryId="select subcategory_id from subcategory where subcategory_name='"+subcategoryName+"'";

		return template.queryForList(getsubcategoryId,Integer.class).get(0);



	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map<String,List > getMasterDropDownData() {
		@SuppressWarnings("rawtypes")
		Map <String,List> data = new HashMap<>() ;

		String installationTypeQuery = "select sub_filter_name from sub_filters where filter_id=1 order by sub_filter_name";
		List<String> installationTypes = template.queryForList(installationTypeQuery, String.class);
		data.put("InstallationType", installationTypes);

		String applicationTypeQuery = "select distinct application_type from app_master order by application_type";
		List<String> applicationType = template.queryForList(applicationTypeQuery,String.class);
		data.put("ApplicationType", applicationType);


		String intendedUserQuery = "select sub_filter_name from sub_filters where filter_id=2 order by sub_filter_name";
		List<String> intendedUsers = template.queryForList(intendedUserQuery, String.class);
		data.put("IntendedUser", intendedUsers);

		String toolProviderQuery = "select sub_filter_name from sub_filters where filter_id=3 order by sub_filter_name";
		List<String> toolProviders = template.queryForList(toolProviderQuery, String.class);
		data.put("ToolProvider", toolProviders);

		String useCaseQuery = "select sub_filter_name from sub_filters where filter_id=5 order by sub_filter_name";
		List<String> useCases = template.queryForList(useCaseQuery, String.class);
		data.put("UseCase", useCases);

		String domainQuery = "select sub_filter_name from sub_filters where filter_id=6 order by sub_filter_name";
		List<String> domains = template.queryForList(domainQuery, String.class);
		data.put("Domain", domains);

		String appContactQuery = "select sub_filter_name from sub_filters where filter_id=4 order by sub_filter_name";
		List<String> appContacts = template.queryForList(appContactQuery, String.class);
		data.put("AppContacts", appContacts);

		return data;
	}

	@Override
	public String updateKeywords(int app_id, List<String> keywords) {
		String fullNameSQL = "select full_name from app_master where id = "+app_id;
		String fullName = template.queryForList(fullNameSQL, String.class).get(0);

		String appNameSQL = "select name from app_master where id = "+app_id;
		String appName = template.queryForList(appNameSQL, String.class).get(0);

		String deleteExistingKeyword = "delete from keyword where app_id = "+app_id;
		template.execute(deleteExistingKeyword);



		for(String eachkeyword:keywords)
		{
			try {
				Keyword keyword = new Keyword();

				keyword.setAppName(appName);
				keyword.setFullName(fullName);
				keyword.setKeyword(eachkeyword);
				keyword.setAppId(app_id);
				keyword.setStatus("Active");
				keywordRepository.save(keyword);

			}
			catch(Exception e)
			{
				e.printStackTrace();
				return e.toString();

			}


		}


		return "Successfully updated the keywords list";
	}


	@SuppressWarnings("unchecked")
	@Override
	public String addNewApplication(AppMaster appMasterDetail) {
		try {
			appMasterRepository.save(appMasterDetail);

			// getKeywords is not a DB Property,
			// the comma separated value is been set by POST from controller
			String arr [] = appMasterDetail.getKeywords().split(",");
			List<String> keywordList = Arrays.asList(arr);
			updateKeywords(appMasterDetail.getId(),keywordList);

			int app_id=appMasterDetail.getId();
			String[] filters = {"intendedUser","installType","useCases","toolProvider"};
			for(String type:filters)
			{
				String[] filterValues;
				int filterId;
				if(type.equals("intendedUser"))
				{
					filterValues=appMasterDetail.getIntendedUser().split(",");
					filterId = 2;
				}
				else if(type.equals("installType"))
				{
					filterValues=appMasterDetail.getInstallType().split(",");
					filterId = 1;
				}
				else if(type.equals("useCases"))
				{
					filterValues=appMasterDetail.getUseCases().split(",");
					filterId = 5;
				}
				else
				{
					filterValues=appMasterDetail.getToolProvider().split(",");
					filterId = 3;
				}
				for(int i=0;i<filterValues.length;i++)
				{
					String subFilterIdQuery="select id from sub_filters where sub_filter_name ='"+filterValues[i]+"'";
					int subFilterId = template.queryForList(subFilterIdQuery,Integer.class).get(0);

//					useCases filter id =5


					AppMasterSubFilter appMasterSubFilter = new AppMasterSubFilter();

					appMasterSubFilter.setApp_id(appMasterDetail.getId());
					appMasterSubFilter.setFilter_id(filterId);
					appMasterSubFilter.setSub_filter_id(subFilterId);

					appMasterSubFilterRepository.save(appMasterSubFilter);


				}

			}

			return "Save Success";

		} catch (Exception e) {
			e.printStackTrace();
			return "Failure"+ e.getMessage();
		}
	}

	@Override
	public List<String> getAppKeyWords(int app_id) {


		String getAppKeywords = "select distinct keyword from keyword where app_id = "+app_id;

		List<String> keywordsList = template.queryForList(getAppKeywords,String.class);

		keywordsList.sort(Comparator.comparing(String::trim));;

		return keywordsList;
	}

	@Override
	public List<Integer> getAppFunctionalMappingIds(Integer appId) {
		List<AppFunctionalMapping> list = this.appFunctionalMappingRepository.findByAppId(appId);
		return list.stream().map(AppFunctionalMapping::getFunctionalMappingId).collect(Collectors.toList());
	}


	public ResponseEntity<?>  updateExistingApp(AppMasterDetails appMasterDetail, HttpServletRequest httpServletRequest) {
		
		try
		{
			updateExistingAppUtilService.updateExistingAppTransactional(appMasterDetail, httpServletRequest);

			HttpHeaders headers= new HttpHeaders();
			headers.setCacheControl("no-cache");

			return ResponseEntity.ok().headers(headers).body(this.getAppMasterByItapID(String.valueOf(appMasterDetail.getId())));

//			return "Updated app details of application :"+appMasterDetail.getId();


		}
		catch(Exception e)
		{
			e.printStackTrace();
			//return "not updated app details of application :"+appMasterDetail.getId();
			return ResponseEntity.internalServerError().build();
		}

	}



	public record OwnerRecord (String id, String fullName ) {

	}

	@Override
	public ResponseEntity<?> uploadAppThumbnail(HttpServletRequest httpServletRequest,
												MultipartFile thumbnail, String uploadAppInfo,
												String category, String subcategory,
												Map<String,MultipartFile> jobAidDocuments)
		throws org.springframework.web.multipart.MaxUploadSizeExceededException {

		Map<String,String> jobAidDocLocalNames = new HashMap<>();
		jobAidDocuments.entrySet().stream()
			.forEach(entry -> {
				try {
					String jobAidDocLocalName = ResourceUtilService.uploadDocument(entry.getValue(), jobAidDirPath);
					jobAidDocLocalNames.put(entry.getKey(), jobAidDocLocalName);
				} catch(org.springframework.web.multipart.MaxUploadSizeExceededException maxEx) {
					throw maxEx;
				} catch (Exception e) {
					logger.error("Error occurred while persisting Job Aid Document");
					throw new RuntimeException("Error occurred while persisting Job Aid Document", e);
				}
			});

		ResponseEntity<?> responseEntity = this.uploadAppThumbnail(httpServletRequest, thumbnail, uploadAppInfo,
				category, subcategory);


		if(jobAidDocLocalNames.size() > 0 && responseEntity.getBody() instanceof AppMasterDetails appMasterDetails) {
            try {

				List<JobAid> jobAid = jobAidRepository.findByAppId(appMasterDetails.getId());
				jobAid.forEach(_jobAid -> {
					_jobAid.setLocalFileName(jobAidDocLocalNames.get(_jobAid.getHttpParamName()));
					jobAidRepository.save(_jobAid);
				});

			} catch (Exception e) {
				logger.error("Error occurred while creating an URL for Job Aid Document for AppId: " +appMasterDetails.getId() +", Error: " +e.getMessage());
				e.printStackTrace();
			}
		}

		return responseEntity;
	}

	@Override
	public ResponseEntity<?> uploadAppThumbnail(HttpServletRequest httpServletRequest,
												MultipartFile thumbnail, String uploadAppInfo,
												String category, String subcategory) {
		try {
			AppMasterDetails appMasterDetails= mapper.readValue(uploadAppInfo, AppMasterDetails.class);

			if(null!=thumbnail){
				String uploadDirPath= this.thumbnailPath+File.separator+category+File.separator+subcategory;

				// Create the upload directory if it doesn't exist
				Path uploadPath = Paths.get(uploadDirPath);
				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				String thumbnailName= appMasterDetails.getId()+LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))+".png";

				// Save the thumbnail image
				Path filePath = Paths.get(uploadDirPath, thumbnailName);
				try {
					Files.copy(thumbnail.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
					URIBuilder uriBuilder= new URIBuilder(this.appBaseUrl+"image");
					uriBuilder.addParameter("category", category);
					uriBuilder.addParameter("subcategory", subcategory);
					uriBuilder.addParameter("img", thumbnailName);
					appMasterDetails.setImageUrl(uriBuilder.toString());
				}catch(FileAlreadyExistsException fae){
					logger.error(fae.getMessage());
					return new ResponseEntity<String>("Thumbnail already exists with that name", HttpStatus.ALREADY_REPORTED);
				}catch (NullPointerException nullExp){
					logger.error(nullExp.getMessage());
					return new ResponseEntity<String>("Provided File path is either empty or invalid!", HttpStatus.NOT_FOUND);
				}
			}

			return this.updateExistingApp(appMasterDetails, httpServletRequest);
		}catch (JsonProcessingException e) {
			logger.error(e.getMessage());
			return new ResponseEntity<String>("Unable to parse the Thumbnail MetaInfo!"+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}catch (IOException io) {
			logger.error(io.getMessage());
			return new ResponseEntity<String>("Unable to Copy the file!"+io.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}catch(Exception exp){
			logger.error(exp.getMessage());
			return new ResponseEntity<String>("Invalid App Meta Info", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> getAppThumbnail(HttpServletRequest httpServletRequest, String category, String subcategory, String imgName) {
		
        try {
			Path filePath= Paths.get(this.thumbnailPath+ File.separator + category+ File.separator+ subcategory+ File.separator+ imgName);
			Resource resource= new UrlResource(filePath.toUri());
			if(resource.exists() || resource.isReadable()){
				return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(resource);
			}else{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public String tabActivity(int app_id, TAB_ACTIVITY tabActivity, HttpServletRequest httpServletRequest) {

		String loginId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
		UserActivity userTabActivity = new UserActivity(app_id, loginId,tabActivity.getId(), LocalDateTime.now());
		
		this.userTabActivityRepository.save(userTabActivity);
		return null;
	}

	@Override
	public ResponseEntity<?> getViewMoreData(int categoryId, int subcategoryId, boolean retiredToggle) {
		try{
			String getViewMoreAppsQuery = "";
			if(!retiredToggle){
				getViewMoreAppsQuery= "select * from app_master where category_id = "+categoryId+" and subcategory_id ="+subcategoryId+ " and install_type<>'Retired'";
			}else{
				getViewMoreAppsQuery= "select * from app_master where category_id = "+categoryId+" and subcategory_id ="+subcategoryId;
			}


			List<AppMasterDetails> apps = new ArrayList<>();
			@SuppressWarnings("deprecation")
			List<AppMasterDetails> results = template.query(getViewMoreAppsQuery,
					new RowMapper<AppMasterDetails>() {
						public AppMasterDetails mapRow(ResultSet rs, int rownumber) throws SQLException {
							AppMasterDetails app = new AppMasterDetails();
							app.setName(rs.getString("name"));
							int categoryId = rs.getInt("category_id");
							String categoryQuery = "SELECT category_name FROM category WHERE category_id = ?";
							String categoryName = template.queryForObject(categoryQuery, String.class, categoryId);
							app.setCategory(categoryName);
							int subcategoryId = rs.getInt("subcategory_id");
							String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
							String subcategoryName = template.queryForObject(subcategoryQuery, String.class,
									subcategoryId);
							app.setSubcategory(subcategoryName);
							app.setId(rs.getInt("id"));
							app.setDescription(rs.getString("description"));
							app.setDescriptionOneLine(rs.getString("description_one_line"));
							app.setImageUrl(rs.getString("image_url"));
							app.setInstallType(rs.getString("install_type"));
							String intendedUserQuery = "select sub_filter_name from sub_filters where id in"
									+ "(select sub_filter_id from app_master_sub_filter where app_id= " + app.getId()
									+ " and filter_id=2)";
							List<String> IntendedUserList = template.queryForList(intendedUserQuery, String.class);
							app.setIntendedUser(String.join(", ", IntendedUserList));
							// app.setIntendedUser(rs.getString("intended_user"));
							app.setITAP(rs.getString("itap_id"));

							final String keywords = keywordRepository.getKeywordsByAppId(rs.getInt("id"));
							app.setKeywords(keywords);
							app.setOnboardStatus(rs.getBoolean("onboard_status"));
							app.setToolProvider(rs.getString("tool_provider"));
							app.setUseCases(rs.getString("use_cases"));
							app.setDomain(rs.getString("domain"));
							app.setApplicationContact(rs.getString("application_contact"));
							app.setAppUrl(rs.getString("app_url"));
							app.setApplicationOwner(rs.getString("application_owner"));
							app.setApplicationType(rs.getString("application_type"));
							app.setFullName(rs.getString("full_name"));
							app.setLaunchStatus(rs.getString("launch_status"));
							apps.add(app);
							return app;
						}

					});
			String query= "select subcategory_name from subcategory where subcategory_id = "+subcategoryId;
			String subcategoryName= template.queryForObject(query,String.class);

			Map<String, Object> resultMap= new HashMap<>();
			resultMap.put("subcategoryName", subcategoryName);
			resultMap.put("apps", apps);
			ObjectMapper objectMapper= new ObjectMapper();
			return ResponseEntity.ok(objectMapper.writeValueAsString(resultMap));
		}catch(Exception e){
			logger.error(e.getMessage());
			return ResponseEntity.notFound().build();
		}
	}

	public void loadAppContacts() {
		logger.info("Loading application contacts - Started");

		int count = 0;
		String sql = "SELECT DISTINCT application_contact FROM app_master " +
				"union " +
				"SELECT DISTINCT application_owner FROM app_master " +
				"union " +
				"SELECT DISTINCT att_id FROM engagement_manager_market " +
				"union " +
				"SELECT DISTINCT avp_att_id FROM engagement_manager_market ";

		List<String> appContacts = template.queryForList(sql, String.class);

		for (String appContact : appContacts) {
			try {
				if(StringUtils.isAllBlank(appContact)) {
					continue;
				}

				// just calling it will cache the full name with att id
				this.webRequestUtil.getUserFullNameWithAttId(appContact);
				count++;
			} catch (Exception e) {
				System.out.println("Error fetching user details for App Contact: " + appContact);
			}
		}

		logger.info("Loading application contacts - Ended: Loaded: " +count+" App Contacts");
	}

	public Map<String,String> getLoadedAppContacts() {
		return WebRequestUtil.CACHED_FULL_NAME_WITH_ATT_ID;
	}
}

package com.att.demo.exception;

public class SessionExpiredException extends Exception{
    public static final String MESSAGE = "Your session has expired. Please login again.";

    public SessionExpiredException() {
        super(MESSAGE);
    }
}

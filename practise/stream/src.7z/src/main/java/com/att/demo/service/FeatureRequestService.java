package com.att.demo.service;

import com.att.demo.entity.*;
import com.att.demo.model.FeatureRequestWithCount;
import com.att.demo.repository.*;
import com.att.demo.util.web.WebRequestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class FeatureRequestService {

    private static final Logger logger = LoggerFactory.getLogger(FeatureRequestService.class);

    @Autowired
    private FeatureRequestRepository featureRequestRepository;

    @Autowired
    private FeatureRequestVotingRepository featureRequestVotingRepository;

    @Autowired
    private JiraClientService jiraClientService;

    @Autowired
    private AppMasterRepository appMasterRepository;

    @Autowired
    private AppConfigInDBRepository appConfigInDBRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private SubCategoryRepository subCategoryRepository;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private EmailService emailService;

    @Value("${application.detail.page.url}")
    private String APPLICATION_DETAIL_PAGE_URL;

    @Value("${application.catalog.page.url}")
    private String APPLICATION_CATALOG_PAGE_URL;

    @Value("${application.detail.page.approval.url}")
    private String APPLICATION_NEW_FEATURE_APPROVAL_PAGE_URL;

    @Value("${user.email.domain}")
    private String userEmailDomain;

    @Value("${jira.assignee}")
    private String JIRA_ASSIGNEE;

    public void vote(Integer featureRequestId, String userId, FeatureRequestVoting.VOTING vote) {

        List<FeatureRequestVoting> votings = featureRequestVotingRepository.findByFeatureRequestIdAndVoteByAttId(
                featureRequestId,
                userId);

        // Whether user has already voted up
        if (votings.isEmpty()) {
            this.saveVote(featureRequestId, userId, vote);
        } else {
            // reset the previous voting
            final FeatureRequestVoting.VOTING previousVoting = FeatureRequestVoting.VOTING.valueOf(votings.get(0).getVoting());
            votings.forEach(voting -> this.resetVote(voting));  // ideally there should be only one voting, but because return type is List therefore Iterating

            // If previous voting is different from current voting
            // then user is trying to change the vote, otherwise only reverting its vote
            if (previousVoting != vote) {
                this.saveVote(featureRequestId, userId, vote);
            }
        }
    }

    public void voteUp(Integer featureRequestId, String userId) {

        this.vote(featureRequestId, userId, FeatureRequestVoting.VOTING.Up);
    }

    public void voteDown(Integer featureRequestId, String userId) {

        this.vote(featureRequestId, userId, FeatureRequestVoting.VOTING.Down);
    }

    private FeatureRequestVoting saveVote(Integer featureRequestId, String userId, FeatureRequestVoting.VOTING voting) {

        FeatureRequestVoting featureRequestVoting = new FeatureRequestVoting();
        featureRequestVoting.setVoting(voting.name());
        featureRequestVoting.setVoteByAttId(userId);
        featureRequestVoting.setFeatureRequest(
                featureRequestRepository.getById(featureRequestId));

        return featureRequestVotingRepository.save(featureRequestVoting);
    }

    private void resetVote(FeatureRequestVoting featureRequestVoting) {
        featureRequestVotingRepository.delete(featureRequestVoting);
    }

    public FeatureRequestWithCount getFeatureRequestWithVotingCounts(Integer featureRequestId, String voteByAttId) {

        FeatureRequest fr = featureRequestRepository.getById(featureRequestId);
        return featureRequestRepository.findOneWithVotingCounts(fr.getAppId(), voteByAttId, featureRequestId);
    }

    @Transactional
    public FeatureRequest saveFeatureRequest(FeatureRequest fr, String attId) throws Exception {

        fr.setRequestedByAttId(attId);
        if (fr.getAppId() != null && fr.getAppId() > 0) {
            fr.setCategoryId(this.appMasterRepository.getCategoryId(fr.getAppId()));
            fr.setSubCategoryId(this.appMasterRepository.getSubcategoryId(fr.getAppId()));
        }

        fr = featureRequestRepository.save(fr);

        if ("Submit".equalsIgnoreCase(fr.getStatus())) {
            sendEmailsToAppContactsAdmin(fr);
        } else if ("Acknowledged".equalsIgnoreCase(fr.getStatus())) {
            // Create Issue in JIRA can be enabled or disabled from DB
            if ("true".equalsIgnoreCase(
                    appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.JIRA_CREATE_ISSUE_FLAG))) {

                List<String> appContacts = this.getAppContacts(fr.getAppId());
                appContacts.add(JIRA_ASSIGNEE);

                for(Iterator<String> itr = appContacts.iterator(); itr.hasNext();) {
                    try {
                        String issueKey = jiraClientService.createIssue(
                                formatSummary(fr.getSummary()),
                                formatDescription(fr),
                                itr.next());

                        fr.setJiraIssueKey(issueKey);
                    } catch (JiraClientService.AssigneeNotFoundException ex) {
                        // if it has assignee not found exception then we will try with another this assignee in the list
                        logger.error("JIRA cannot be assigned to Application Contact:{}", ex.getAssignee());
                        continue;
                    }

                    break;
                }

                featureRequestRepository.save(fr);
                statusEmailToSubmitter(fr);
            } else {
                logger.info("JIRA Issue Creation is disabled.");
            }
        }

        return fr;
    }

    @Transactional
    public FeatureRequest updateFeatureRequest(FeatureRequest fr) throws Exception {

        FeatureRequest dbFr = featureRequestRepository.getById(fr.getId());
        dbFr.setAppId(fr.getAppId());
        dbFr.setCategoryId(fr.getCategoryId());
        dbFr.setSubCategoryId(fr.getSubCategoryId());
        dbFr.setSummary(fr.getSummary());
        dbFr.setStatus(fr.getStatus());
        dbFr.setDescription(fr.getDescription());
        dbFr.setUpdatedAt(new Date());
        dbFr.setRejectionReason(fr.getRejectionReason());
        dbFr.setUpdatedByAttId(this.webRequestUtil.getUserAttId());

        // Create Issue in JIRA can be enabled or disabled from DB
        String jiraEnable = appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.JIRA_CREATE_ISSUE_FLAG);
        if ("true".equalsIgnoreCase(jiraEnable)
                && dbFr.getJiraIssueKey() != null && fr.getStatus() != "Completed") {

            jiraClientService.updateIssue(
                    dbFr.getJiraIssueKey(),
                    formatSummary(dbFr.getSummary()),
                    formatDescription(dbFr));

        } else {
            logger.info("JIRA is disabled, or Feature Request do not have JIRA Assigned(fr.id={}, JIRA_ENABLE:{}, IssueKey:{}).", fr.getId(), jiraEnable, dbFr.getJiraIssueKey());
        }

        featureRequestRepository.save(dbFr);

        return dbFr;
    }

    @Transactional
    public FeatureRequest deleteFeatureRequest(Integer frId) throws Exception {

        FeatureRequest dbFr = featureRequestRepository.getById(frId);
        dbFr.setDeleted(true);
        dbFr.setUpdatedAt(new Date());
        dbFr.setUpdatedByAttId(this.webRequestUtil.getUserAttId());

        // Create Issue in JIRA can be enabled or disabled from DB
        if ("true".equalsIgnoreCase(
                appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.JIRA_CREATE_ISSUE_FLAG))
                && dbFr.getJiraIssueKey() != null) {

            jiraClientService.cancelIssue(
                    dbFr.getJiraIssueKey());

        } else {
            logger.info("JIRA is disabled.");
        }

        // Save, once JIRA Issue is updated
        featureRequestRepository.save(dbFr);

        return dbFr;
    }

    private String formatSummary(String summary) throws Exception {

        String template = ResourceUtilService.readFileFromResources("jira-request/issue-summary.txt");
        template = template.replace("####0", summary);
        template = template.trim();

        return template;
    }

    private String formatDescription(FeatureRequest fr) throws Exception {

        if (fr.getAppId() == 0) {
            return formatDescriptionWithoutApp(fr);
        }

        AppMaster appMaster = appMasterRepository.findById(fr.getAppId()).orElse(new AppMaster());
        String template = ResourceUtilService.readFileFromResources("jira-request/issue-description.txt");
        template = template.replace("####0", fr.getRequestedByAttId());
        template = template.replace("####1", appMaster.getName());
        template = template.replace("####2", appMaster.getFullName());
        template = template.replace("####3", APPLICATION_DETAIL_PAGE_URL + fr.getAppId());
        template = template.replace("####4", fr.getDescription());
        template = template.trim();

        return template;
    }

    private String formatDescriptionWithoutApp(FeatureRequest fr) throws Exception {

        String template = ResourceUtilService.readFileFromResources("jira-request/issue-description-without-app.txt");

        template = template.replace("####0", fr.getRequestedByAttId());
        template = template.replace("####1", APPLICATION_CATALOG_PAGE_URL);
        template = template.replace("####2", categoryRepository.getName(fr.getCategoryId()));
        template = template.replace("####3", subCategoryRepository.getName(fr.getSubCategoryId()));
        template = template.replace("####4", fr.getDescription());
        template = template.trim();

        return template;
    }

    public void sendEmailsToAppContactsAdmin(FeatureRequest featureRequest) throws Exception {

        Map<String, List<String>> contacts = getAppContactForNotificationEmail(featureRequest.getAppId());
        String[] toList = contacts.get("to").toArray(new String[0]);
        String[] ccList = contacts.get("cc").toArray(new String[0]);

        if (toList.length == 0) {
            logger.warn("No email contacts found for the feature request with ID: {}, Summary: {}, Description: {}", featureRequest.getId(), featureRequest.getSummary(), featureRequest.getDescription());
            return;
        }

        AppMaster appMaster = appMasterRepository.findById(featureRequest.getAppId()).orElse(null);
        String toolName = (appMaster != null && appMaster.getFullName() != null) ? appMaster.getFullName() : "-";

        String navigateUrl = buildFeatureRequestUrl(featureRequest);
        String subject = "ACE Hub - New Feature Request has been Submitted";
        String body = "<div style='width:100%;display:flex;'>"
                + "<div style='margin:auto;'>"
                + "<h2>ACE Hub New Feature Request Details</h2>"
                + "<table style='margin:auto;padding:8px 0; border-collapse:collapse;'>"
                + "<tr><th align='left' style='padding:8px 16px;'>Tool Name</th><td style='padding:8px 16px;'>" + toolName + "</td></tr>"
                + "<tr><th align='left' style='padding:8px 16px;'>Summary</th><td style='padding:8px 16px;'>" + (featureRequest.getSummary() != null ? featureRequest.getSummary() : "-") + "</td></tr>"
                + "<tr><th align='left' style='padding:8px 16px;'>Description</th><td style='padding:8px 16px;'>" + (featureRequest.getDescription() != null ? featureRequest.getDescription() : "-") + "</td></tr>"
                + "<tr><th align='left' style='padding:8px 16px;'>Category</th><td style='padding:8px 16px;'>" + this.categoryService.getCategoryName(featureRequest.getCategoryId(), Optional.of("-")) + "</td></tr>"
                + "<tr><th align='left' style='padding:8px 16px;'>Sub-Category</th><td style='padding:8px 16px;'>" + this.categoryService.getSubCategoryName(featureRequest.getSubCategoryId(), Optional.of("-")) + "</td></tr>"
                + "<tr><th align='left' style='padding:8px 16px;'>Requested By</th><td style='padding:8px 16px;'>" + this.webRequestUtil.getUserFullNameWithAttId(featureRequest.getRequestedByAttId()) + "</td></tr>"
                + "</table><br/>"
                + "<a href='" + navigateUrl + "' style='display:inline-block;padding:12px 28px;text-decoration:none;border-radius:4px;font-size:16px;font-weight:500;'>Click here to Review</a>"
                + "</div></div>";

        emailService.emailSimpleMessage(subject, body, toList, null);

        logger.info("Feature request email send successfully");
    }

    /**
     * This method is to fetch application contacts and admin contacts from database that is used for sending emails
     *
     * @param appId
     * @return
     */
    public Map<String, List<String>> getAppContactForNotificationEmail(Integer appId) {

        List<String> appContactEmails = transformAttIdsToEmails(featureRequestRepository.fetchAppEmailContacts(appId));
        List<String> adminEmails = transformAttIdsToEmails(featureRequestRepository.fetchAppAdminEmailContacts());

        Map<String, List<String>> map = new HashMap<>();
        map.put("to", appContactEmails);
        map.put("cc", adminEmails);

        // if tool/application is not selected for the feature request then Admin will come into To emails
        if (appId == null || appId <= 0) {
            map.put("to", adminEmails);
            map.put("cc", Collections.emptyList());
        }

        return map;
    }

    public List<String> getAppContacts(Integer appId) {

        // if tool/application is not selected for the feature request then Admin will come into To emails
        if(appId == null || appId <= 0) {
            return new ArrayList<>();
        }

        List<String> appContactCsv = featureRequestRepository.fetchAppEmailContacts(appId);
        Set<String> _appContacts = new LinkedHashSet<>();
        for (String attId : appContactCsv) {
            String[] splitContacts = attId.split(",");
            for (String contact : splitContacts) {
                _appContacts.add(contact.trim());
            }
        }

        return new ArrayList<String>(_appContacts);
    }

    public String buildFeatureRequestUrl(FeatureRequest featureRequest) {
        String baseUrl = APPLICATION_NEW_FEATURE_APPROVAL_PAGE_URL;
        if (baseUrl != null && baseUrl.contains("://www.")) {
            baseUrl = baseUrl.replace("://www.", "://");
        }
        String url = baseUrl + URLEncoder.encode(String.valueOf(featureRequest.getId()), StandardCharsets.UTF_8) +
                "/" + URLEncoder.encode(String.valueOf(featureRequest.getAppId()), StandardCharsets.UTF_8);
        return url;
    }

    public void statusEmailToSubmitter(FeatureRequest featureRequest) {
        try {
            String submitterEmail = featureRequest.getRequestedByAttId();
            AppMaster appMaster = appMasterRepository.findById(featureRequest.getAppId()).orElse(null);
            String toolName = (appMaster != null && appMaster.getFullName() != null) ? appMaster.getFullName() : "-";
            if (submitterEmail != null && !submitterEmail.contains("@")) {
                submitterEmail = submitterEmail + userEmailDomain;
            }

            String jiraLink = featureRequest.getJiraIssueKey() != null
                    ? "<a href='https://itrack.web.att.com/browse/" + featureRequest.getJiraIssueKey() + "' target='_blank'>Click here for further communication in Ticket</a>"
                    : "Jira ticket will be available after review.";

            String subject = "ACE Hub - New Feature Request has been " + (featureRequest.getStatus() != null ? featureRequest.getStatus() : "-");
            StringBuilder body = new StringBuilder();
            body.append("<div style='width:100%;display:flex;'>")
                    .append("<div style='margin:auto;'>")
                    .append("<h3>New Feature Request Details</h3>")
                    .append("<table style='margin:auto;padding:8px 0; border-collapse:collapse;'>")
                    .append("<tr><th align='left' style='padding:8px 16px;'>Tool Name</th><td style='padding:8px 16px;'>")
                    .append(toolName)
                    .append("</td></tr>")
                    .append("<tr><th align='left' style='padding:8px 16px;'>Summary</th><td style='padding:8px 16px;'>")
                    .append(featureRequest.getSummary() != null ? featureRequest.getSummary() : "-")
                    .append("</td></tr>")
                    .append("<tr><th align='left' style='padding:8px 16px;'>Description</th><td style='padding:8px 16px;'>")
                    .append(featureRequest.getDescription() != null ? featureRequest.getDescription() : "-")
                    .append("</td></tr>")
                    .append("<tr><th align='left' style='padding:8px 16px;'>Ticket</th><td style='padding:8px 16px;'>")
                    .append(jiraLink)
                    .append("</td></tr>");

            String status = featureRequest.getStatus() != null ? featureRequest.getStatus() : "-";
            String updatedBy = this.webRequestUtil.getUserFullNameWithAttId(featureRequest.getUpdatedByAttId());
            String updatedAt = featureRequest.getUpdatedAt() != null ? featureRequest.getUpdatedAt().toString() : "-";
            String rejectionReason = featureRequest.getRejectionReason() != null && !featureRequest.getRejectionReason().isEmpty() ? featureRequest.getRejectionReason() : "-";

            switch (status) {
                case "Under Review":
                    body.append("<tr><th align='left' style='padding:8px 16px;'>Acknowledged By</th><td style='padding:8px 16px;'>")
                            .append(updatedBy)
                            .append("</td></tr>");
                    break;
                case "Rejected":
                    body.append("<tr><th align='left' style='padding:8px 16px;'>Rejected Reason</th><td style='padding:8px 16px;'>")
                            .append(rejectionReason)
                            .append("</td></tr>")
                            .append("<tr><th align='left' style='padding:8px 16px;'>Rejected By</th><td style='padding:8px 16px;'>")
                            .append(updatedBy)
                            .append("</td></tr>")
                            .append("<tr><th align='left' style='padding:8px 16px;'>Rejected Date</th><td style='padding:8px 16px;'>")
                            .append(updatedAt)
                            .append("</td></tr>");
                    break;
                case "Completed":
                    body.append("<tr><th align='left' style='padding:8px 16px;'>Last Updated By</th><td style='padding:8px 16px;'>")
                            .append(updatedBy)
                            .append("</td></tr>");
                    break;
                case "Acknowledged":
                    body.append("<tr><th align='left' style='padding:8px 16px;'>Acknowledged By</th><td style='padding:8px 16px;'>")
                            .append(updatedBy)
                            .append("</td></tr>");
                    break;
                case "On Hold":
                    body.append("<tr><th align='left' style='padding:8px 16px;'>On Hold By</th><td style='padding:8px 16px;'>")
                            .append(updatedBy)
                            .append("</td></tr>")
                            .append("<tr><th align='left' style='padding:8px 16px;'>On Hold Date</th><td style='padding:8px 16px;'>")
                            .append(updatedAt)
                            .append("</td></tr>");
                    break;
                default:

                    break;
            }

            body.append("</table><br/>")
                    .append("</div></div>");
            emailService.emailSimpleMessage(subject, body.toString(), submitterEmail, null);
            logger.info("Email sent to submitter: {}", submitterEmail);
        } catch (Exception e) {
            logger.error("Failed to send email to submitter", e);
        }
    }

    public FeatureRequest getAppDetails(Integer Id) {
        if (Id == null) {
            return null;
        }
        return featureRequestRepository.getById(Id);
    }

    private List<String> transformAttIdsToEmails(List<String> attIds) {

        // If attIds is null or empty, return an empty list
        if (attIds == null || attIds.isEmpty()) {
            return Collections.emptyList();
        }

        // individual contacts can be a csv value, so we need to split them
        // LinkedHashSet to keep the order, and Set to avoid duplicates
        Set<String> contacts = new LinkedHashSet<>();

        // Iterate through each contact in the applicationContacts list
        for (String attId : attIds) {
            String[] splitContacts = attId.split(",");

            // Add each contact to the set, trimming whitespace
            // to ensure no leading/trailing spaces
            contacts.addAll(Arrays.stream(splitContacts)
                    .map(String::trim)    // Trim each contact
                    .filter(c -> !c.isEmpty()) // Filter out empty contacts
                    .toList());
        }

        // convert it to email address
        return contacts.stream()
                .map(contact -> contact + userEmailDomain)
                .toList();
    }
}

package com.att.demo.model;

import com.att.demo.entity.FunctionalMapping;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FunctionalMappingTree {

    private Integer id;
    private String name = "";
    private Integer level = 0;
    private String status;
    private List<FunctionalMappingTree> children = new ArrayList<>();

    public FunctionalMappingTree(Integer id, String name, Integer level, String status) {
        this.id = id;
        this.name = name;
        this.level = level;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getLevel() {
        return level;
    }

    public String getStatus() {
        return status;
    }

    public List<FunctionalMappingTree> getChildren() {
        return children;
    }
}

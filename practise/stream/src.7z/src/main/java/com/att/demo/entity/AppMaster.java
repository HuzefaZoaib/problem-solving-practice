package com.att.demo.entity;

import jakarta.persistence.*;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "app_master")
public class AppMaster 
{

	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	
	
	@Column(name = "itap_id")
	private String ITAP;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "category_id")
	private int category;
	
//	@Column(name = "subcategory_id")
//	private int subcategoryid;
	
	@Column(name = "install_type")
	private String installType;
	

	@Column(name = "description_one_line")
	private String descriptionOneLine;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "image_url")
	private String imageUrl;
	
	
	@Column(name = "application_contact")
	private String applicationContact;
	
	@Column(name = "onboard_status")
	private Boolean onboardStatus;
	
	@Column(name = "intended_user")
	private String intendedUser;
	
	@Column(name="UseCases")
	private String UseCases;
	

	@Column(name="subcategory_id")
	@JoinColumn(name="subcategory_id", nullable=false)
	private int subcategoryid;
	
	//@Column(name="Keywords")
	@Transient
	private String Keywords;
	
	@Column(name="ToolProvider")
	private String ToolProvider;
	
	@Column(name = "app_url")
    private String appUrl;
	
	@Column(name="ApplicationOwner")
	private String ApplicationOwner;
	
	@Column(name="ApplicationType")
	private String ApplicationType;
	
	@Column(name="fullName")
	private String fullName;

	@Column(name="domain", length = 100)
	private String domain;

	@OneToMany(mappedBy = "app_id")
	private List<AppMasterSubFilter> appMasterSubFilters;

	@OneToMany(mappedBy = "appId")
	private List<Keyword> keywordList;

	@OneToMany(mappedBy = "appId")
	private List<AppFunctionalMapping> functionalMappings;

	@OneToMany(mappedBy = "appId")
	private List<FeatureRequest> featureRequests;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	@Column(name="launchStatus")
	private String launchStatus;

	public String getApplicationOwner() {
		return ApplicationOwner;
	}

	public void setApplicationOwner(String applicationOwner) {
		ApplicationOwner = applicationOwner;
	}

	public String getApplicationType() {
		return ApplicationType;
	}

	public void setApplicationType(String applicationType) {
		ApplicationType = applicationType;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getToolProvider() {
		return ToolProvider;
	}

	public void setToolProvider(String toolProvider) {
		ToolProvider = toolProvider;
	}

	public String getKeywords() {

		// To keep-up with the Legacy Implementation
		// HTTP POST data is translated to AppMaster, which is this class
		if(StringUtils.hasLength(Keywords)) {
			return Keywords;
		}

		// To load the keywords from the Keywords table
		if(this.keywordList != null) {
			return this.keywordList.stream()
					.map(Keyword::getKeyword)
					.collect(Collectors.joining("|"));
		}

		return "";
	}

	// This property is being at Controller.
	// HTTP POST data is translated to AppMaster, which is this class
	public void setKeywords(String keywords) {
		Keywords = keywords;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIntendedUser() {
		return intendedUser;
	}

	public void setIntendedUser(String intendedUser) {
		this.intendedUser = intendedUser;
	}

	public String getUseCases() {
		return UseCases;
	}

	public void setUseCases(String useCases) {
		UseCases = useCases;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getITAP() {
		return ITAP;
	}

	public void setITAP(String iTAP) {
		ITAP = iTAP;
	}



	public String getInstallType() {
		return installType;
	}

	public void setInstallType(String installType) {
		this.installType = installType;
	}


	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public int getSubcategoryid() {
		return subcategoryid;
	}

	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}



	public String getDescriptionOneLine() {
		return descriptionOneLine;
	}

	public void setDescriptionOneLine(String descriptionOneLine) {
		this.descriptionOneLine = descriptionOneLine;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getApplicationContact() {
		return applicationContact;
	}

	public void setApplicationContact(String applicationContact) {
		this.applicationContact = applicationContact;
	}

	public Boolean isOnboardStatus() {
		return onboardStatus;
	}

	public void setOnboardStatus(Boolean onboardStatus) {
		this.onboardStatus = onboardStatus;
	}

	public String getLaunchStatus() {
		return launchStatus;
	}

	public void setLaunchStatus(String launchStatus) {
		this.launchStatus = launchStatus;
	}

	public List<AppMasterSubFilter> getAppMasterSubFilters() {
		return appMasterSubFilters;
	}

	public void setAppMasterSubFilters(List<AppMasterSubFilter> appMasterSubFilters) {
		this.appMasterSubFilters = appMasterSubFilters;
	}

	// KeywordList to Load Keywords by Hibernate
	public List<Keyword> getKeywordList() {
		return keywordList;
	}

	public void setKeywordList(List<Keyword> keywordList) {
		this.keywordList = keywordList;
	}

	public List<AppFunctionalMapping> getFunctionalMappings() {
		return functionalMappings;
	}

	public void setFunctionalMappings(List<AppFunctionalMapping> functionalMappings) {
		this.functionalMappings = functionalMappings;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public List<FeatureRequest> getFeatureRequests() {
		return featureRequests;
	}

	public void setFeatureRequests(List<FeatureRequest> featureRequests) {
		this.featureRequests = featureRequests;
	}

	@Override
	public String toString() {
		return "AppMaster [id=" + id + ", ITAP=" + ITAP + ", name=" + name + ", category=" + category + ", installType="
				+ installType + ", descriptionOneLine=" + descriptionOneLine + ", description=" + description
				+ ", imageUrl=" + imageUrl + ", applicationContact=" + applicationContact + ", onboardStatus="
				+ onboardStatus + ", intendedUser=" + intendedUser + ", UseCases=" + UseCases + ", subcategoryid="
				+ subcategoryid + /*", Keywords=" + Keywords +*/ ", ToolProvider=" + ToolProvider + ", appUrl=" + appUrl
				+ ", ApplicationOwner=" + ApplicationOwner + ", ApplicationType=" + ApplicationType + ", fullName="
				+ fullName + ", launchStatus=" + launchStatus + ", getFullName()=" + getFullName()
				+ ", getApplicationOwner()=" + getApplicationOwner() + ", getApplicationType()=" + getApplicationType()
				+ ", getAppUrl()=" + getAppUrl() + ", getToolProvider()=" + getToolProvider() +/* ", getKeywords()="
				+ getKeywords() + */", getId()=" + getId() + ", getIntendedUser()=" + getIntendedUser()
				+ ", getUseCases()=" + getUseCases() + ", getName()=" + getName() + ", getITAP()=" + getITAP()
				+ ", getInstallType()=" + getInstallType() + ", getCategory()=" + getCategory()
				+ ", getSubcategoryid()=" + getSubcategoryid() + ", getDescriptionOneLine()=" + getDescriptionOneLine()
				+ ", getDescription()=" + getDescription() + ", getImageUrl()=" + getImageUrl()
				+ ", getApplicationContact()=" + getApplicationContact() + ", isOnboardStatus()=" + isOnboardStatus()
				+ ", getLaunchStatus()=" + getLaunchStatus() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}



}

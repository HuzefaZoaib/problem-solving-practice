package com.att.demo.model;

import java.util.List;
import java.util.Map;

public class SearchRequest {
	private String searchText;
	private List<Filters> filters;
	public boolean retiredToggle;
	
	
	
	
	public boolean isRetiredToggle() {
		return retiredToggle;
	}


	public void setRetiredToggle(boolean retiredToggle) {
		this.retiredToggle = retiredToggle;
	}


	public String getSearchText() {
		return searchText;
	}
	
	
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	
	public List<Filters> getFilters() {
		return filters;
	}
	public void setFilters(List<Filters> filters) {
		this.filters = filters;
	}
	
	@Override
	public String toString() {
		return "SearchRequest [searchText=" + searchText + ", filters=" + filters + "]";
	}
	
	
	
	


	
	

}

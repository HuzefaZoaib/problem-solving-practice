package com.att.demo.entity.deletelog;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Getter
@Setter
public class AppMasterSubFilterDeleteLog implements Serializable {

    //
    // This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
    // and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
    // is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
    //
    // Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
    // I could face issue because of the mismatched property names from the original entity.
    //

    private Integer id;
    private Integer app_id;
    private Integer sub_filter_id;
    private Integer filter_id;

}
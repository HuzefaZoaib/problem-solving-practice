package com.att.demo.controller;

import com.att.demo.model.ResponseFilter;
import com.att.demo.service.FilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/filter")
public class FilterController {

 @Autowired
    FilterService filterService;

 @GetMapping("initial-count/{retiredToggle}")
    public List<ResponseFilter> getInitialFilterCount(@PathVariable boolean retiredToggle) {
        return filterService.getInitialFiltersCount(retiredToggle);
 }
}

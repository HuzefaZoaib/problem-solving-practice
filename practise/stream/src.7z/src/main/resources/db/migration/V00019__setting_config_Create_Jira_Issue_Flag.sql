--
-- Configuration: Create Jira Issue Flag
--
insert into app_config_indb(key,value) values('JIRA_CREATE_ISSUE_FLAG','true');

--
-- Ericsson in Tool Provider
--

insert into sub_filters(id,filter_id,sub_filter_name) values(NEXTVAL('sub_filters_id_seq'),3,'Ericsson');

--
-- User Login of the Engagement Manager so that
-- Engagement Manager Role can be assigned
--

-- Create the user_login for these att_ids, and Assign the Engagement Role to the user_login
-- -- mc0733
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'CAMACHO, MARVIN', 'mc0733'
where not exists(select 1 from user_login where user_id='mc0733');

-- -- nh3786
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'HILL, NEVILLE', 'nh3786'
where not exists(select 1 from user_login where user_id='nh3786');

-- -- ed4802
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'DEMIRCAN, EMRE', 'ed4802'
where not exists(select 1 from user_login where user_id='ed4802');

-- -- dm0487
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'MALLMA, DAVID', 'dm0487'
where not exists(select 1 from user_login where user_id='dm0487');

-- -- ss367y
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'SHI, ALLEN', 'ss367y'
where not exists(select 1 from user_login where user_id='ss367y');

-- -- rd117g
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'DURAL, ROGEL', 'rd117g'
where not exists(select 1 from user_login where user_id='rd117g');

-- -- ct2621
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'TAYLOR, CHRISTOPHER', 'ct2621'
where not exists(select 1 from user_login where user_id='ct2621');

-- -- CP2626
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'PATEL, CHETAN', 'CP2626'
where not exists(select 1 from user_login where user_id='CP2626');

-- -- ws2779
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'SPARKS, WILLIAM', 'ws2779'
where not exists(select 1 from user_login where user_id='ws2779');

-- -- ml264h
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'LAMSAL, MURARI', 'ml264h'
where not exists(select 1 from user_login where user_id='ml264h');

-- -- nc0055
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'CLEMENSEN, NICOLE L', 'nc0055'
where not exists(select 1 from user_login where user_id='nc0055');

-- -- am912q
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'MARNO, AGUS', 'am912q'
where not exists(select 1 from user_login where user_id='am912q');

-- -- mc9758
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'CABADIN, MARK', 'mc9758'
where not exists(select 1 from user_login where user_id='mc9758');

-- -- am3501
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'MACAYAN, ALBERT', 'am3501'
where not exists(select 1 from user_login where user_id='am3501');

-- -- mt761s
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'TERRELL, MARK', 'mt761s'
where not exists(select 1 from user_login where user_id='mt761s');

-- -- lw4124
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'WANG, LEI', 'lw4124'
where not exists(select 1 from user_login where user_id='lw4124');

-- -- de9178
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'ENNIS, DANIEL', 'de9178'
where not exists(select 1 from user_login where user_id='de9178');

-- -- cw259y
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'WELSH, CAMERON', 'cw259y'
where not exists(select 1 from user_login where user_id='cw259y');

-- -- cl104c
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'LUGOS, CHRIS', 'cl104c'
where not exists(select 1 from user_login where user_id='cl104c');

-- -- ej4175
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'JAKOET, EBRAHIM', 'ej4175'
where not exists(select 1 from user_login where user_id='ej4175');

-- -- mr1908
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'ROMERO, ANGEL', 'mr1908'
where not exists(select 1 from user_login where user_id='mr1908');

-- -- kl5503
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'LOEBSACK, KIEL', 'kl5503'
where not exists(select 1 from user_login where user_id='kl5503');

-- -- jp7353
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'PINTO, JOAO', 'jp7353'
where not exists(select 1 from user_login where user_id='jp7353');

-- -- db6421
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'BALAN, DANIEL', 'db6421'
where not exists(select 1 from user_login where user_id='db6421');

-- -- sd001s
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'DHANDAPANI, SENTHIL', 'sd001s'
where not exists(select 1 from user_login where user_id='sd001s');

-- -- cd1782
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'DINGES, CHRIS', 'cd1782'
where not exists(select 1 from user_login where user_id='cd1782');

-- -- jg686w
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'GIBBS, JASON', 'jg686w'
where not exists(select 1 from user_login where user_id='jg686w');

-- -- ah7369
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'HASSIBA, ABED', 'ah7369'
where not exists(select 1 from user_login where user_id='ah7369');

-- -- ar620m
insert into user_login(id,full_name,user_id)
select nextval('user_login_id_seq'), 'RODRIGUEZ, ALVIN', 'ar620m'
where not exists(select 1 from user_login where user_id='ar620m');

--
-- Engagement Manager Role Assignments
--

-- Create the user_login for these att_ids, and Assign the Engagement Role to the user_login
-- -- mc0733
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='mc0733'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- nh3786
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='nh3786'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ed4802
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ed4802'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- dm0487
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='dm0487'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ss367y
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ss367y'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- rd117g
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='rd117g'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ct2621
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ct2621'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- CP2626
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='CP2626'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ws2779
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ws2779'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ml264h
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ml264h'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- nc0055
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='nc0055'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- am912q
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='am912q'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- mc9758
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='mc9758'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- am3501
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='am3501'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- mt761s
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='mt761s'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- lw4124
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='lw4124'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- de9178
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='de9178'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- cw259y
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='cw259y'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- cl104c
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='cl104c'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ej4175
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ej4175'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- mr1908
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='mr1908'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- kl5503
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='kl5503'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- jp7353
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='jp7353'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- db6421
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='db6421'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- sd001s
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='sd001s'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- cd1782
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='cd1782'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- jg686w
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='jg686w'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ah7369
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ah7369'
and not exists(select 1 from user_role where user_id=id and role_id=3);

-- -- ar620m
insert into user_role(user_id,role_id)
select id, 3 from user_login where user_id='ar620m'
and not exists(select 1 from user_role where user_id=id and role_id=3);

--
-- Standard User Role Assignments
--

-- Create the user_login for these att_ids, and Assign the Engagement Role to the user_login
-- -- mc0733
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='mc0733'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- nh3786
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='nh3786'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ed4802
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ed4802'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- dm0487
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='dm0487'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ss367y
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ss367y'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- rd117g
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='rd117g'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ct2621
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ct2621'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- CP2626
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='CP2626'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ws2779
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ws2779'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ml264h
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ml264h'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- nc0055
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='nc0055'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- am912q
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='am912q'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- mc9758
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='mc9758'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- am3501
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='am3501'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- mt761s
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='mt761s'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- lw4124
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='lw4124'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- de9178
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='de9178'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- cw259y
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='cw259y'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- cl104c
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='cl104c'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ej4175
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ej4175'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- mr1908
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='mr1908'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- kl5503
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='kl5503'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- jp7353
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='jp7353'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- db6421
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='db6421'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- sd001s
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='sd001s'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- cd1782
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='cd1782'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- jg686w
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='jg686w'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ah7369
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ah7369'
and not exists(select 1 from user_role where user_id=id and role_id=2);

-- -- ar620m
insert into user_role(user_id,role_id)
select id, 2 from user_login where user_id='ar620m'
and not exists(select 1 from user_role where user_id=id and role_id=2);



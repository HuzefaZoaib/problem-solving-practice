package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.AppMasterSubFilterAudit;
import com.att.demo.entity.UserActivity;


public interface UserTabActivityRepository extends JpaRepository<UserActivity, Integer>{

}

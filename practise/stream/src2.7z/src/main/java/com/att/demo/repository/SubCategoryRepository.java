package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.SubCategory;

import java.util.Optional;

@Repository
public interface SubCategoryRepository extends JpaRepository<SubCategory, Integer> {

    default String getName(Integer id) {
        if(id == null) {
            return "";
        }

        Optional<SubCategory> subCategory = findById(id);
        if(!subCategory.isPresent()) {
            return "";
        }

        return subCategory.get().getName();
    }
}

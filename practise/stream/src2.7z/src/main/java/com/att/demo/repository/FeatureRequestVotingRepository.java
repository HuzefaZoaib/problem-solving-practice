package com.att.demo.repository;

import com.att.demo.entity.FeatureRequestVoting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeatureRequestVotingRepository extends JpaRepository<FeatureRequestVoting, Integer> {

    List<FeatureRequestVoting> findByFeatureRequestIdAndVotingAndVoteByAttId(Integer featureRequestId, String voting, String voteByAttId);

    List<FeatureRequestVoting> findByFeatureRequestIdAndVoteByAttId(Integer featureRequestId, String voteByAttId);
}

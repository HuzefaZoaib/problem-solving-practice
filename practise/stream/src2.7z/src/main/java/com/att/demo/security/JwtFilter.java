package com.att.demo.security;

import com.att.demo.model.WebPhone;
import com.att.demo.util.web.WebRequestUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException{
        String path= request.getRequestURI();
        return path.startsWith("/api/auth");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        Cookie[] cookies= request.getCookies();
        String userId="";
        if(cookies!=null){
            for(Cookie cookie: cookies){
                if("jwt".equalsIgnoreCase(cookie.getName())){
                    String token= cookie.getValue();
                    try{
                        Claims claims= jwtUtil.getClaimsFromToken(token);
                        userId= claims.getSubject();
                    } catch (Exception e) {
                        e.printStackTrace();
                        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        return;
                    }
                    if(userId!=null && SecurityContextHolder.getContext().getAuthentication() == null){
                        UserDetails userDetails= this.userService.loadUserByUsername(userId);

                        if(jwtUtil.validateToken(token, userDetails)){
                            UsernamePasswordAuthenticationToken authenticationToken=
                                    new UsernamePasswordAuthenticationToken(
                                            userDetails,
                                            null,
                                            userDetails.getAuthorities()
                                    );
                            authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                            SecurityContextHolder.getContext().setAuthentication(authenticationToken);

                            //Attach employee/contractor flag attribute to request and response headers
                            try {
                                WebPhone webPhone= webRequestUtil.getUserByAttId(userId);
                                if(null!=webPhone && null!=webPhone.getContractorFlag()){
                                    response.addHeader("User-Flag", webPhone.getContractorFlag());
                                }else{
                                    response.addHeader("User-Flag", "");
                                }
                                response.addHeader("Access-Control-Expose-Headers", "User-Flag");
                            } catch (Exception e) {
                                logger.error(Arrays.toString(e.getStackTrace()));
                                return;
                            }
                        }else{
                            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                            response.getWriter().write("Token Expired!");
                            response.getWriter().flush();
                            return;
                        }
                    }
                }
            }
        }
        filterChain.doFilter(request, response);
    }

    /*
    * You can access authenticated user details globally using the following approach:
    * Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
    * String userId= authentication.getName();
    * Collection<? extends GrantedAuthority> roles= authentication.getAuthorities();
    */
}

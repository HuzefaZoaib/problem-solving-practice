package com.att.demo.repository;

import com.att.demo.entity.KeywordForAudit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KeywordAuditRepository extends JpaRepository<KeywordForAudit, Integer> {
}

package com.att.demo.model;

public class FavoriteOrderAttId
{

	private String attId;

	private String order;

	public String getAttId() {
		return attId;
	}

	public void setAttId(String attId) {
		this.attId = attId;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public FavoriteOrderAttId(String attId, String order) {
		super();
		this.attId = attId;
		this.order = order;
	}

	@Override
	public String toString() {
		return "FavoriteOrderAttId [attId=" + attId + ", order=" + order + "]";
	}
	
	

}

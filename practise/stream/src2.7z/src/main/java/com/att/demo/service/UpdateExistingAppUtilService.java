package com.att.demo.service;

import com.att.demo.entity.*;
import com.att.demo.model.AppMasterDetails;
import com.att.demo.repository.*;
import com.att.demo.security.AuthenticationService;
import com.att.demo.util.web.WebRequestUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import opennlp.tools.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
@Slf4j
public class UpdateExistingAppUtilService {

    @Autowired
    private AppMasterSubFilterAuditRepository appMasterSubFilterAuditRepository;

    @Autowired
    @Qualifier("postgresqlJdbcTemplate")
    private JdbcTemplate template;

    @Autowired
    private AppMasterAuditRepository appMasterAuditRepository;

    @Autowired
    private AppMasterSubFilterRepository appMasterSubFilterRepository;

    @Autowired
    private KeywordAuditRepository keywordAuditRepository;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private KeywordRepository keywordRepository;

    @Autowired
    private AppFunctionalMappingRepository appFunctionalMappingRepository;
    
    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private JobAidRepository jobAidRepository;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    void updateExistingAppTransactional(AppMasterDetails appMasterDetail, HttpServletRequest httpServletRequest) {

        // Get the attId from the request
        String attId = this.webRequestUtil.getWebJunctionData(httpServletRequest);

        // Get the AppMaster object based on id
        String query = "select id from app_master where id = ?";
        List<Integer> appMasterId = template.queryForList(query, Integer.class, appMasterDetail.getId());
        if(appMasterId.isEmpty() && authenticationService.isLoginUserAdmin()) {
            // Insert the appMasterDetail into the database
            String insertQuery = "insert into app_master (id) values (?)";
            template.update(insertQuery, appMasterDetail.getId());
        }

        String snapShotIdQuery = "select nextval('snapshotId')";
        Integer snapShotId = template.queryForObject(snapShotIdQuery, Integer.class);

        String updateApp="update app_master set" +
                //" description = '"+appMasterDetail.getDescription()+"' "+
                //", description_one_line = '"+appMasterDetail.getDescriptionOneLine()+"' "+
                //", name = '"+appMasterDetail.getName()+"' "+
                " intended_user = '"+appMasterDetail.getIntendedUser()+"' "+
                ", install_type = '"+appMasterDetail.getInstallType()+"' "+
                ", application_owner = '"+appMasterDetail.getApplicationOwner()+"' "+
                ", application_contact = '"+appMasterDetail.getApplicationContact()+"' "+
                ", use_cases = '"+appMasterDetail.getUseCases()+"' "+
                ", domain = '"+appMasterDetail.getDomain()+"' "+
                /*", keywords = '"+appMasterDetail.getKeywords()+"' "+*/
                ", tool_provider = '"+appMasterDetail.getToolProvider()+"' "+
                ", application_type = '"+appMasterDetail.getApplicationType()+"' "+
                //", full_name = '"+appMasterDetail.getFullName()+"' "+
                ", category_id = "+Integer.parseInt(appMasterDetail.getCategory())+" "+
                ", subcategory_id = "+Integer.parseInt(appMasterDetail.getSubcategory())+" "+
                ", app_url = '"+appMasterDetail.getAppUrl()+"' ";

        if(null!=appMasterDetail.getImageUrl() && !StringUtil.isEmpty(appMasterDetail.getImageUrl())){
            updateApp= updateApp.concat(", image_url = '"+ appMasterDetail.getImageUrl()+"' ");
        }
        updateApp = updateApp.concat("where id="+appMasterDetail.getId());
        System.out.println(updateApp);
        template.execute(updateApp);

        // Update Description and Name, Fix for single quote and could be other escape literals
        updateApp="update app_master set" +
                " description = ?"+
                ", description_one_line = ?"+
                ", name = ?"+
                ", full_name = ?"+
                " where id=?";
        template.update(updateApp,
                appMasterDetail.getDescription(), appMasterDetail.getDescriptionOneLine(),
                appMasterDetail.getName(), appMasterDetail.getFullName(),
                appMasterDetail.getId());

        String[] arr = appMasterDetail.getKeywords().split("\\|");
        List<String> keywordList = Arrays.asList(arr);
        updateKeywords(appMasterDetail.getId(),keywordList);

        arr = appMasterDetail.getFunctionalMappings().split("\\|");
        List<String> appFunctionalMappings =
                appMasterDetail.getFunctionalMappings().isBlank() ? Collections.EMPTY_LIST : Arrays.asList(arr);
        updateFunctionalMappings(appMasterDetail.getId(),appFunctionalMappings);

        // Update filter table for edit
        int app_id=appMasterDetail.getId();

        String deleteExistingFilterQuery  = "delete from app_master_sub_filter where app_id = "+app_id;
        template.execute(deleteExistingFilterQuery);


        String[] filters = {"intendedUser","installType","useCases","toolProvider","domain","application_contact"};
        for(String type:filters)
        {
            String[] filterValues;
            int filterId=0;
            if(type.equals("intendedUser"))
            {
                if(appMasterDetail.getIntendedUser().equals("N/A") )
                {
                    filterValues = new String[]{"Unknown"};
                    filterId = 2;
                }
                else
                {
                    filterValues=appMasterDetail.getIntendedUser().split(",");
                    filterId = 2;

                }

            }
            else if(type.equals("installType"))
            {
                filterValues=appMasterDetail.getInstallType().split(",");
                filterId = 1;
            }
            else if(type.equals("useCases"))
            {
                if(appMasterDetail.getUseCases().equals("N/A") )
                {
                    filterValues = new String[]{"Unknown"};
                    filterId = 5;
                }
                else
                {
                    filterValues=appMasterDetail.getUseCases().split(",");
                    filterId = 5;
                }
            }
            else if(type.equals("domain"))
            {
                if(appMasterDetail.getDomain().equals("N/A") )
                {
                    filterValues = new String[]{"Unknown"};
                    filterId = 6;
                }
                else
                {
                    filterValues=appMasterDetail.getDomain().split(",");
                    filterId = 6;
                }
            }
            else if(type.equals("application_contact"))
            {
                if(appMasterDetail.getApplicationContact().equals("N/A") )
                {
                    filterValues = new String[]{"Unknown"};
                    filterId = 4;
                }
                else
                {
                    filterValues=appMasterDetail.getApplicationContact().split(",");
                    filterId = 4;
                }
            }
            else
            {
                filterValues=appMasterDetail.getToolProvider().split(",");
                filterId = 3;
            }

            for(int i=0;i<filterValues.length;i++)
            {
                String subFilterIdQuery="select id from sub_filters where sub_filter_name ='"+filterValues[i]+"' and filter_id = "+filterId;
                List<Integer> subFilterIds= template.queryForList(subFilterIdQuery,Integer.class);
                int subFilterId = -1;
                if(!subFilterIds.isEmpty()){
                    subFilterId = subFilterIds.get(0);
                    AppMasterSubFilter appMasterSubFilter = new AppMasterSubFilter();

                    appMasterSubFilter.setApp_id(appMasterDetail.getId());
                    appMasterSubFilter.setFilter_id(filterId);
                    appMasterSubFilter.setSub_filter_id(subFilterId);

                    this.appMasterSubFilterAudit(appMasterDetail.getId(), subFilterId, filterId, httpServletRequest, snapShotId);

                    appMasterSubFilterRepository.save(appMasterSubFilter);
                } else {
                    String insertSubFilterQuery = "insert into sub_filters(id,filter_id,sub_filter_name,app_id,updated_by) values(NEXTVAL('sub_filters_id_seq'),?,?,?,?)";
                    template.update(insertSubFilterQuery, filterId, filterValues[i], app_id, attId);
                    // decrease the index to map the sub filter id to the App Master
                    i--;
                }
            }
        }

        // Delete and Save Job Aids
        jobAidRepository.deleteByAppId(appMasterDetail.getId());
        appMasterDetail.getJobAids().forEach( _jobAid -> {
            _jobAid.setAppId(appMasterDetail.getId());
            jobAidRepository.save(_jobAid);
        });


        this.applicationAuditLog(appMasterDetail, httpServletRequest, snapShotId);
    }

    private void applicationAuditLog(AppMasterDetails appMasterDetails, HttpServletRequest httpServletRequest, int snapshotId) {

        AppMasterAudit appMasterAudit= new AppMasterAudit(appMasterDetails.getITAP(), appMasterDetails.getName(), Integer.parseInt(appMasterDetails.getCategory()), appMasterDetails.getInstallType(), appMasterDetails.getDescriptionOneLine(),
                appMasterDetails.getDescription(), appMasterDetails.getImageUrl(), appMasterDetails.getApplicationContact(), false, appMasterDetails.getIntendedUser(), appMasterDetails.getUseCases(),
                Integer.parseInt(appMasterDetails.getSubcategory()), /*appMasterDetails.getKeywords(),*/ appMasterDetails.getToolProvider(), appMasterDetails.getAppUrl(),
                appMasterDetails.getApplicationOwner(), appMasterDetails.getApplicationType(), appMasterDetails.getFullName(), this.webRequestUtil.getWebJunctionData(httpServletRequest),
                LocalDateTime.now(),snapshotId);

        this.appMasterAuditRepository.save(appMasterAudit);

        String[] arr = appMasterDetails.getKeywords().split("\\|");
        List<String> keywordList = Arrays.asList(arr);
        this.appKeywordsAuditLog (appMasterDetails.getId(),keywordList, httpServletRequest, snapshotId);
    }

    private void appKeywordsAuditLog(int app_id, List<String> keywords, HttpServletRequest httpServletRequest, int snapShotId) {
        String fullNameSQL = "select full_name from app_master where id = "+app_id;
        String fullName = template.queryForList(fullNameSQL, String.class).get(0);

        String appNameSQL = "select name from app_master where id = "+app_id;
        String appName = template.queryForList(appNameSQL, String.class).get(0);

        for(String eachKeyword: keywords)
        {
            KeywordForAudit keywordForAudit = new KeywordForAudit(eachKeyword, app_id, appName, fullName,
                    this.webRequestUtil.getWebJunctionData(httpServletRequest),"Active", LocalDateTime.now(), snapShotId);
            keywordAuditRepository.save(keywordForAudit);
        }
    }

    private void appMasterSubFilterAudit(int app_id, int sub_filter_id, int filter_id, HttpServletRequest httpServletRequest, int snapshotId) {

        AppMasterSubFilterAudit appMasterSubFilterAudit = new AppMasterSubFilterAudit(app_id,sub_filter_id,filter_id,this.webRequestUtil.getWebJunctionData(httpServletRequest), LocalDateTime.now(),snapshotId);

        this.appMasterSubFilterAuditRepository.save(appMasterSubFilterAudit);
    }

    private void updateKeywords(int app_id, List<String> keywords) {

        String fullNameSQL = "select full_name from app_master where id = " + app_id;
        String fullName = template.queryForList(fullNameSQL, String.class).get(0);

        String appNameSQL = "select name from app_master where id = " + app_id;
        String appName = template.queryForList(appNameSQL, String.class).get(0);

        String deleteExistingKeyword = "delete from keyword where app_id = " + app_id;
        template.execute(deleteExistingKeyword);

        for (String eachkeyword : keywords) {

            Keyword keyword = new Keyword();

            keyword.setAppName(appName);
            keyword.setFullName(fullName);
            keyword.setKeyword(eachkeyword);
            keyword.setAppId(app_id);
            keyword.setStatus("Active");
            keywordRepository.save(keyword);
        }
    }

    private void updateFunctionalMappings(int appId, List<String> functionalMappings) {

        String fullNameSQL = "select full_name from app_master where id = " + appId;
        String fullName = template.queryForList(fullNameSQL, String.class).get(0);

        String appNameSQL = "select name from app_master where id = " + appId;
        String appName = template.queryForList(appNameSQL, String.class).get(0);

        appFunctionalMappingRepository.deleteByAppId(appId);

        for (String mappingId : functionalMappings) {

            AppFunctionalMapping mapping = new AppFunctionalMapping();

            mapping.setAppName(appName);
            mapping.setFullName(fullName);
            mapping.setFunctionalMappingId(Integer.valueOf(mappingId));
            mapping.setAppId(appId);

            appFunctionalMappingRepository.save(mapping);
        }
    }

}

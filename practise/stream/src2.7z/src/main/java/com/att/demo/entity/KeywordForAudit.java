package com.att.demo.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "KeywordForAudit")
public class KeywordForAudit
{
    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "KeywordAuditSeq")
    @SequenceGenerator(name = "KeywordAuditSeq", sequenceName = "KEYWORD_AUDIT_ID_SEQ", allocationSize = 1, initialValue=0)
    @Column(name = "keywordId")
    private int keywordId;

    @Column(name = "keyword")
    private String keyword ;

    @Column(name = "appId")
    private int appId ;

    @Column(name="appName")
    private String appName;

    @Column(name="fullName")
    private String fullName;

    @Column(name="updatedBy")
    private String updatedBy;

    @Column(name = "status")
    private String status ;

    
    @Column(name = "updatedDateTime")
    private LocalDateTime updatedDateTime;
    
    
    @Column(name = "snapShotId")
    private Integer snapShotId;

	public int getKeywordId() {
		return keywordId;
	}

	public void setKeywordId(int keywordId) {
		this.keywordId = keywordId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public Integer getSnapShotId() {
		return snapShotId;
	}

	public void setSnapShotId(Integer snapShotId) {
		this.snapShotId = snapShotId;
	}
	
	public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	@Override
	public String toString() {
		return "KeywordForAudit [keywordId=" + keywordId + ", keyword=" + keyword + ", appId=" + appId + ", appName="
				+ appName + ", fullName=" + fullName + ", updatedBy=" + updatedBy + ", status=" + status
				+ ", updatedDateTime=" + updatedDateTime + ", snapShotId=" + snapShotId + "]";
	}

	public KeywordForAudit(String keyword, int appId, String appName, String fullName, String updatedBy,
			String status, LocalDateTime updatedDateTime, Integer snapShotId) {
		super();
		this.keyword = keyword;
		this.appId = appId;
		this.appName = appName;
		this.fullName = fullName;
		this.updatedBy = updatedBy;
		this.status = status;
		this.updatedDateTime = updatedDateTime;
		this.snapShotId = snapShotId;
	}

	
    
    

   
}
package com.att.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.demo.entity.SubCategory;
import com.att.demo.repository.SubCategoryRepository;


@Service
public class SubCategoryService {
	

	@Autowired
	private SubCategoryRepository subcategoryRepository;
	
	public SubCategory saveSubCategory(SubCategory subcategory)
	{
		return subcategoryRepository.save(subcategory);
	}
	
	public List<SubCategory> saveSubCategories(List<SubCategory> subcategories)
	{
		return subcategoryRepository.saveAll(subcategories);
	}
	
	public List<SubCategory> getsubcategories()
	{
		return subcategoryRepository.findAll();
	}
	
	public Optional<SubCategory> getSubCategoryByID(int subcategoryid)
	{
		return subcategoryRepository.findById(subcategoryid);
	}
	
	public String deleteSubCategory(int subcategoryid)
	{
		subcategoryRepository.deleteById(subcategoryid);
		return "AppMaster Removed";
		
	}

}

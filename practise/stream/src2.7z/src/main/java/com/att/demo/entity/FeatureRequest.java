package com.att.demo.entity;

import com.att.demo.model.FeatureRequestWithCount;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


@SqlResultSetMapping(name = "FeatureRequestWithCount",
        classes = @ConstructorResult(
                targetClass = FeatureRequestWithCount.class,
                columns = {
                        @ColumnResult(name = "id", type = Integer.class),
                        @ColumnResult(name = "summary", type = String.class),
                        @ColumnResult(name = "status", type = String.class),
                        @ColumnResult(name = "description", type = String.class),
                        @ColumnResult(name = "appId", type = Integer.class),
                        @ColumnResult(name = "requestedByAttId", type = String.class),
                        @ColumnResult(name = "categoryId", type = Integer.class),
                        @ColumnResult(name = "subCategoryId", type = Integer.class),
                        @ColumnResult(name = "jiraIssueKey", type = String.class),
                        @ColumnResult(name = "voteUpCount", type = Integer.class),
                        @ColumnResult(name = "voteDownCount", type = Integer.class),
                        @ColumnResult(name = "voteUpByLoggedInUser", type = Integer.class),
                        @ColumnResult(name = "voteDownByLoggedInUser", type = Integer.class),
                        @ColumnResult(name = "updatedAt", type = String.class),
                        @ColumnResult(name = "updatedByAttId", type = String.class),
                        @ColumnResult(name = "rejectionReason", type = String.class)
                }
        )
)
@NamedNativeQuery(name = "FeatureRequest.findAllWithVotingCounts",
        query = "select id, summary, status, description, updated_at as updatedAt, updated_by_att_id as updatedByAttId, app_id as appId, requested_by_att_id as requestedByAttId, jira_issue_key as jiraIssueKey, \n" +
                "category_id as categoryId, sub_category_id as subCategoryId, rejection_reason as rejectionReason, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up') as voteUpCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down') as voteDownCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up' and vote_by_att_id=:voteByAttId) as voteUpByLoggedInUser, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down' and vote_by_att_id=:voteByAttId) as voteDownByLoggedInUser \n" +
                "from feature_request fr\n" +
                "where (deleted is null or deleted <> true)\n" +
                "order by voteUpCount desc, id desc\n",
        resultSetMapping = "FeatureRequestWithCount")
@NamedNativeQuery(name = "FeatureRequest.findAllForAppWithVotingCounts",
        query = "select id, summary, status, description, updated_at as updatedAt, updated_by_att_id as updatedByAttId, app_id as appId, requested_by_att_id as requestedByAttId, jira_issue_key as jiraIssueKey, \n" +
                "category_id as categoryId, sub_category_id as subCategoryId, rejection_reason as rejectionReason, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up') as voteUpCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down') as voteDownCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up' and vote_by_att_id=:voteByAttId) as voteUpByLoggedInUser, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down' and vote_by_att_id=:voteByAttId) as voteDownByLoggedInUser \n" +
                "from feature_request fr\n" +
                "where app_id = :appId\n" +
                "and (deleted is null or deleted <> true)\n" +
                "order by voteUpCount desc, id desc\n",
        resultSetMapping = "FeatureRequestWithCount")
@NamedNativeQuery(name = "FeatureRequest.findOneWithVotingCounts",
        query = "select id, summary, status, description, updated_at as updatedAt, updated_by_att_id as updatedByAttId, app_id as appId, requested_by_att_id as requestedByAttId, jira_issue_key as jiraIssueKey, \n" +
                "category_id as categoryId, sub_category_id as subCategoryId, rejection_reason as rejectionReason, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up') as voteUpCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down') as voteDownCount, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Up' and vote_by_att_id=:voteByAttId) as voteUpByLoggedInUser, \n" +
                "(select count(1) from feature_request_voting where feature_request_id = fr.id and voting = 'Down' and vote_by_att_id=:voteByAttId) as voteDownByLoggedInUser \n" +
                "from feature_request fr\n" +
                "where app_id = :appId and fr.id=:id\n",
        resultSetMapping = "FeatureRequestWithCount")
@Entity
@Getter
@Setter
@NoArgsConstructor
public class FeatureRequest {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;

    @Column(nullable = false, length = 50)
    private String summary;

    @Column(nullable = false, length = 500)
    private String description;

    @Column(nullable = true)
    private Integer appId;

    @Column(nullable = false, length = 25)
    private String requestedByAttId;

    @Column(nullable = true, length = 25)
    private String jiraIssueKey;

    @Column(nullable = true)
    private Integer categoryId;

    @Column(nullable = true)
    private Integer subCategoryId;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "id")
    private List<FeatureRequestVoting> featureRequestVotings;

    @Column(nullable = true)
    private Boolean deleted;

    @Column(nullable = true, length = 15)
    private String status;

    @Column(nullable = true, length = 200)
    private String rejectionReason;

    // An updatedAt and updatedByAttId will capture the Delete operation also.
    // Delete will also be considered as an update operation.
    // However, at the time of create these fields will be null,
    // and so it doesn't represent the CreateAt.
    // On the other hand, requestedByAttId will capture the CreatedByAttId operation.
    @Column(nullable = true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(nullable = true)
    private String updatedByAttId;

    // The following column is for creating a Reference only. By the way, we are already using appId for actual mapping.
    //@ManyToOne(fetch=FetchType.LAZY)
    //@JoinColumn(name="appId", referencedColumnName="id", insertable=false, updatable=false)
    //private AppMaster appMaster;

    @Transient
    private Integer voteUpCount = 0;

    @Transient
    private Integer voteDownCount = 0;

    @Transient
    private Integer voteUpByLoggedInUser = 0;

    @Transient
    private Integer voteDownByLoggedInUser = 0;

    public boolean isDeleted() {
        return deleted != null && deleted;
    }

    @Getter
    @Setter
    public class FeatureRequestDeleteLog implements Serializable {

        //
        // This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
        // and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
        // is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
        //
        // Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
        // I could face issue because of the mismatched property names from the original entity.
        //

        private int id;
        private String summary;
        private String description;
        private Integer appId;
        private String requestedByAttId;
        private String jiraIssueKey;
        private String status;
        private Integer categoryId;
        private Integer subCategoryId;
        private Boolean deleted;
        private Date updatedAt;
        private String updatedByAttId;
    }
}

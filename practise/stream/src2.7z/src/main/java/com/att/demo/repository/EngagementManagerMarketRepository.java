package com.att.demo.repository;

import com.att.demo.entity.EngagementManagerMarket;
import com.att.demo.model.EngagementManager;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EngagementManagerMarketRepository extends JpaRepository<EngagementManagerMarket, Long> {

    @Query(nativeQuery = true, name = "EngagementManagerMarket.findAllWithMarketCsv")
    List<EngagementManager> findAllWithMarketCsv();

    @Query(nativeQuery = true, name = "EngagementManagerMarket.findForSpecificAttIdWithMarketCsv")
    EngagementManager findForSpecificAttIdWithMarketCsv(@Param("attId") String attId);

    @Modifying
    @Query(value = "delete from engagement_manager_market e where e.att_id = :attId", nativeQuery = true)
    void deleteByAttId(@Param("attId") String attId);
}

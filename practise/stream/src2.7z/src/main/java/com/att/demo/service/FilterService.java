package com.att.demo.service;

import com.att.demo.entity.AppMaster;
import com.att.demo.entity.Filter;
import com.att.demo.entity.SubFilters;
import com.att.demo.model.FilterValues;
import com.att.demo.model.ResponseFilter;
import com.att.demo.repository.AppMasterRepository;
import com.att.demo.repository.FilterRepository;
import com.att.demo.repository.SubFilterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Service
public class FilterService {

	@Autowired
	FilterRepository filterRepository;
	@Autowired
	SubFilterRepository subFilterRepository;
	@Autowired
	@Qualifier("postgresqlJdbcTemplate")
	JdbcTemplate template;
	@Autowired
	AppMasterRepository appMasterRepository;

	public List<ResponseFilter> getInitialFiltersCount(boolean retiredToggle) {
        List<Filter> filterParentList = filterRepository.findAllByOrderByIdAsc();
        List<ResponseFilter> filters = new ArrayList<>();
        for(Filter filter: filterParentList) {
            ResponseFilter responseFilter = new ResponseFilter();
            Integer filterParentCount = 0;
            responseFilter.setFiltername(filter.getFilterName());
            List<FilterValues> filterValuesList = new ArrayList<>();
            HashSet<String> listOfDistinctApps = new HashSet<String>();
            List<SubFilters> subFilterList = subFilterRepository.findByFilterIdOrderBySubFilterNameAsc(filter.getId());
                for(SubFilters subFilters: subFilterList) {
                    FilterValues filterValues = new FilterValues();
                    //String filterQuery = "SELECT COUNT(*) FROM APP_MASTER WHERE "+filter.getFilterName() +" = '"+ subFilters.getSubFilterName()+"'" ;
                    
					String filterQuery = "select count(app_id) from app_master_sub_filter where filter_id in "
							+ "(select id from filter where filter_name = '" + filter.getFilterName() + "') "
							+ "and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('"
							+ subFilters.getSubFilterName() + "')) and"
							+ " app_id not in (select app_id from app_master_sub_filter where filter_id in "
							+ "	(select id from filter where filter_name = 'install_type') and sub_filter_id in "
							+ "	(select id from sub_filters where  sub_filter_name in ('Retired')))";
					if(retiredToggle)
					{
						filterQuery = "select count(app_id) from app_master_sub_filter where filter_id in "
								+ "(select id from filter where filter_name = '" + filter.getFilterName() + "') "
								+ "and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('"
								+ subFilters.getSubFilterName() + "'))";
						
					}
                    int count = template.queryForObject(filterQuery, Integer.class);
                    System.out.println(filterQuery);
                    filterValues.setFilterValueName(subFilters.getSubFilterName());
                    filterValues.setFilterValueCount(String.valueOf(count));
                    filterValuesList.add(filterValues);
                    
            		//Use a hashSet for parent filter count	as it could be duplicates.

                    String subFilterAppIds= "select app_id from app_master_sub_filter where filter_id in "
                    		+ "(select id from filter where filter_name = '"+filter.getFilterName()+"') "
                    		+ "and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('"+subFilters.getSubFilterName()+"'))"
                    				+ "and app_id not in (select app_id from app_master_sub_filter where filter_id in "
                    				+ "	(select id from filter where filter_name = 'install_type') and sub_filter_id in "
                    				+ "	(select id from sub_filters where  sub_filter_name in ('Retired'))) ";
                    if(retiredToggle)
                    {

                        subFilterAppIds= "select app_id from app_master_sub_filter where filter_id in "
                        		+ "(select id from filter where filter_name = '"+filter.getFilterName()+"') "
                        		+ "and sub_filter_id in (select id from sub_filters where  sub_filter_name in ('"+subFilters.getSubFilterName()+"'))";
                    	
                    }
            		List<String> subFilterAppIdsList = template.queryForList(subFilterAppIds, String.class);
                    
            		listOfDistinctApps.addAll(subFilterAppIdsList);
                }

                filterParentCount = filterParentCount + listOfDistinctApps.size();
                
                
                
                
                int index = -1;
				for (int i = 0; i < filterValuesList.size(); i++) {
					if (filterValuesList.get(i).getFilterValueName().equals("Unknown")) {
						index = i;
						break;
					}
				}
				FilterValues unknownFilterValues=null;
				if (index != -1) {
					unknownFilterValues=filterValuesList.get(index);
					filterValuesList.remove(index);
				}
				
				if(unknownFilterValues!=null)
				{
					filterValuesList.add(unknownFilterValues);
				}
                
                String unknownQuery="select count(*) from app_master "
    					+ "where "+filter.getFilterName()+" in ('',null,'N/A')";
    			System.out.println(unknownQuery);
    			int unknowncount = template.queryForObject(unknownQuery, Integer.class);
    			//filterValuesList.add(new FilterValues("Unknown", unknowncount+""));
    			
    			responseFilter.setFiltervalues(filterValuesList);
    			responseFilter.setFilterNameCount(filterParentCount);
                    responseFilter.setFiltervalues(filterValuesList);
                    responseFilter.setFilterNameCount(filterParentCount);
                    filters.add(responseFilter);
        }return filters;
}}

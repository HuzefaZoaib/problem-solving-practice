package com.att.demo.controller;

import com.att.demo.entity.JobAid;
import com.att.demo.exception.ErrorResponse;
import com.att.demo.repository.AppMasterRepository;
import com.att.demo.repository.JobAidRepository;
import com.att.demo.service.ResourceUtilService;
import com.att.demo.util.web.WebRequestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/job-aid")
public class JobAidController {

    private static final Logger logger= LoggerFactory.getLogger(JobAidController.class);

    @Autowired
    private JobAidRepository jobAidRepository;

    @Autowired
    private AppMasterRepository appMasterRepository;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @GetMapping(value = "/{appId}")
    public List<JobAid> getJobAid(@PathVariable("appId") Integer appId) {
        String attId = webRequestUtil.getUserAttId();
        return jobAidRepository.findByAppId(appId);
    }

    @Value("${ran_marketplace.apps.jobaid.path}")
    private String jobAidDirPath;

    @GetMapping(value = "/download/{jobAidId}")
    public ResponseEntity download(@PathVariable ("jobAidId") Long jobAidId) throws Exception {

        JobAid jobAid = jobAidRepository.findById(jobAidId)
                .orElseThrow(() -> new Exception("Job Aid not found with ID: " + jobAidId));

        String jobAidFile = jobAid.getLocalFileName();
        org.springframework.core.io.Resource resource = ResourceUtilService.getFileResouce(jobAidDirPath, jobAidFile);
        if(resource != null){

            ResponseEntity.BodyBuilder responseBuilder = ResponseEntity.ok();

            if (jobAidFile.toLowerCase().endsWith(".pdf")) {
                responseBuilder = responseBuilder.contentType(MediaType.APPLICATION_PDF)
                        .header("Content-Disposition", "inline; filename=\"" + jobAid.getUpload() + "\"");
            } else if (jobAidFile.toLowerCase().endsWith(".jpg") || jobAidFile.toLowerCase().endsWith(".jpeg")) {
                responseBuilder = responseBuilder.contentType(MediaType.IMAGE_JPEG)
                        .header("Content-Disposition", "inline; filename=\"" + jobAid.getUpload() + "\"");
            } else if (jobAidFile.toLowerCase().endsWith(".png")) {
                responseBuilder = responseBuilder.contentType(MediaType.IMAGE_PNG)
                        .header("Content-Disposition", "inline; filename=\"" + jobAid.getUpload() + "\"");
            } else {
                responseBuilder = responseBuilder.contentType(MediaType.APPLICATION_OCTET_STREAM)
                        .header("Content-Disposition", "attachment; filename=\"" + jobAid.getUpload() + "\"");
            }

            return responseBuilder.body(resource);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneralException(Exception ex) {
        logger.error("Exception occurred in Job Aid/Request Access: "+ex.getMessage(), ex);
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred");
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

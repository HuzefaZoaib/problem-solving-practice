package com.att.demo.repository;

import com.att.demo.entity.FunctionalMapping;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FunctionalMappingRepository extends JpaRepository<FunctionalMapping, Integer> {

    @Query("select m from FunctionalMapping m where m.status='Approved' and m.active=:active order by child")
    List<FunctionalMapping> findByActiveAndStatusApproved(boolean active);

    @Query("select m from FunctionalMapping m where m.status='Pending' and m.active=:active and m.updatedBy=:updatedBy order by child")
    List<FunctionalMapping> findByActiveAndUpdatedByAndStatusPending(boolean active, String updatedBy);

    List<FunctionalMapping> findByActive(boolean active, Sort sort);

    List<FunctionalMapping> findByParent(String parent, Sort sort);

    default List<FunctionalMapping> findByActive(boolean active) {
        return this.findByActive(active, Sort.by("child").ascending());
    }

    default List<FunctionalMapping> findByParent(String parent) {
        return this.findByParent(parent, Sort.by("child").ascending());
    }
}
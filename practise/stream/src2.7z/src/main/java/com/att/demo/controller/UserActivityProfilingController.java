package com.att.demo.controller;

import com.att.demo.model.WeeklyAppUsage;
import com.att.demo.model.WeeklyTrafficUsage;
import com.att.demo.service.UserActivityProfilingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/app-stat")
@CrossOrigin(origins = "*")
public class UserActivityProfilingController
{
	@Autowired
	private UserActivityProfilingService userActivityProfilingService;
	
	@GetMapping(value = "/listTop10App")
	public Map<String, Integer> listTop10App() {
		return userActivityProfilingService.findTop10Applications();
	}

	@GetMapping(value = "/listAppActiveDuration")
	public Map<String, BigDecimal> listAppActiveDuration() {
		return userActivityProfilingService.findAppActiveDuration();
	}

	@GetMapping(value = "/listTabAppGroupingDuration")
	public Map<String, BigDecimal> listTabAppGroupingDuration() {
		return userActivityProfilingService.findTabAppGroupingDuration();
	}

	@GetMapping(value = "/listWeeklyTrafficUsage")
	public List<WeeklyTrafficUsage> listWeeklyTrafficUsage() {
		return userActivityProfilingService.findWeeklyTrafficUsage();
	}

	@GetMapping(value = "/listWeeklyAppUsage")
	public List<WeeklyAppUsage> listWeeklyAppUsage() {
		return userActivityProfilingService.findWeeklyAppUsage();
	}

	@GetMapping(value = "/acehub/trafficusage/defaultminmaxdate")
	public List<String> trafficUsageDefaultMinMaxDate() {
		return userActivityProfilingService.findAceHubTrafficUsageDefaultMinMaxDate();
	}

	@PostMapping(value = "/listWeeklyTrafficUsage")
	public List<WeeklyTrafficUsage> listWeeklyTrafficUsage(@RequestBody Map<String, String> params) {
		if("weekly".equals(params.get("period"))) {
			return userActivityProfilingService.findWeeklyTrafficUsage(params);
		} else if("monthly".equals(params.get("period"))) {
			return userActivityProfilingService.findMonthlyTrafficUsage(params);
		}

		return List.of();
	}
}

package com.att.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class WebPhone {

    @JsonProperty("Country code")
    private String countryCode;

    @JsonProperty("Dept ID (orgcode)")
    private String deptId;

    @JsonProperty("Dept Name")
    private String deptName;

    @JsonProperty("Business Group ID")
    private String businessGroupId;

    @JsonProperty("Business Group Name")
    private String businessGroupName;

    @JsonProperty("Business Subgroup (orgid)")
    private String businessSubgroupId;

    @JsonProperty("Business Subgroup Name (orgdesc)")
    private String businessSubgroupName;

    @JsonProperty("Business Unit")
    private String businessUnit;

    @JsonProperty("Business Unit Name")
    private String businessUnitName;

    @JsonProperty("VP Org")
    private String vpOrg;

    @JsonProperty("VP Org Name")
    private String vpOrgName;

    @JsonProperty("Cell")
    private String cell;

    @JsonProperty("City")
    private String city;

    @JsonProperty("CountryDesc")
    private String countryDesc;

    @JsonProperty("E-Mail")
    private String email;

    @JsonProperty("FAX")
    private String fax;

    @JsonProperty("Phone Extension")
    private String phoneExtension;

    @JsonProperty("First Name")
    private String firstName;

    @JsonProperty("Handle")
    private String handle;

    @JsonProperty("HRID")
    private String hrid;

    @JsonProperty("Job Title Code")
    private String jobTitleCode;

    @JsonProperty("Job Title Name")
    private String jobTitleName;

    @JsonProperty("Last Name")
    private String lastName;

    @JsonProperty("Location (CLLI) Code")
    private String locationCode;

    @JsonProperty("Middle Name")
    private String middleName;

    @JsonProperty("Cost Center")
    private String costCenter;

    @JsonProperty("Pager")
    private String pager;

    @JsonProperty("Pager PIN")
    private String pagerPin;

    @JsonProperty("Preferred Name")
    private String preferredName;

    @JsonProperty("Prefix Name")
    private String prefixName;

    @JsonProperty("Room Number")
    private String roomNumber;

    @JsonProperty("State")
    private String state;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("Address")
    private String address;

    @JsonProperty("Name Suffix")
    private String nameSuffix;

    @JsonProperty("Telephone Number")
    private String telephoneNumber;

    @JsonProperty("Level")
    private String level;

    @JsonProperty("Title Name")
    private String titleName;

    @JsonProperty("Zip")
    private String zip;

    @JsonProperty("Supervisor ATTUID")
    private String supervisorAttuid;

    @JsonProperty("a1 (sbcuid, attuid)")
    private String a1;

    @JsonProperty("COGS - Common Org Grouping Sys (a2)")
    private String cogs;

    @JsonProperty("Silo")
    private String silo;

    @JsonProperty("Direct,TotalReports (a4)")
    private String directTotalReports;

    @JsonProperty("Bellsouth UID (uuid2)")
    private String bellsouthUid;

    @JsonProperty("Cingular CUID (uuid3)")
    private String cingularCuid;

    @JsonProperty("Financial Loc Code")
    private String financialLocCode;

    @JsonProperty("E-mail Alias")
    private String emailAlias;

    @JsonProperty("Payroll ID")
    private String payrollId;

    @JsonProperty("Consulting Company")
    private String consultingCompany;

    @JsonProperty("Management Level Indicator")
    private String managementLevelIndicator;

    @JsonProperty("Occupancy Indicator")
    private String occupancyIndicator;

    @JsonProperty("Primary GTR")
    private String primaryGtr;

    @JsonProperty("Secondary GTR")
    private String secondaryGtr;

    @JsonProperty("CPID Record Indicator (Y/N)")
    private String cpidRecordIndicator;

    @JsonProperty("Geographic Location Code")
    private String geographicLocationCode;

    @JsonProperty("Architectural Object ID")
    private String architecturalObjectId;

    @JsonProperty("Company Code")
    private String companyCode;

    @JsonProperty("Payroll Company/Company Description")
    private String payrollCompanyDescription;

    @JsonProperty("Contractor Flag (Y/N)")
    private String contractorFlag;

    @JsonProperty("Preferred Mailing Address")
    private String preferredMailingAddress;

    @JsonProperty("JFC/Activity Origin")
    private String jfcActivityOrigin;

    @JsonProperty("Primary Email Address")
    private String primaryEmailAddress;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getBusinessGroupId() {
		return businessGroupId;
	}

	public void setBusinessGroupId(String businessGroupId) {
		this.businessGroupId = businessGroupId;
	}

	public String getBusinessGroupName() {
		return businessGroupName;
	}

	public void setBusinessGroupName(String businessGroupName) {
		this.businessGroupName = businessGroupName;
	}

	public String getBusinessSubgroupId() {
		return businessSubgroupId;
	}

	public void setBusinessSubgroupId(String businessSubgroupId) {
		this.businessSubgroupId = businessSubgroupId;
	}

	public String getBusinessSubgroupName() {
		return businessSubgroupName;
	}

	public void setBusinessSubgroupName(String businessSubgroupName) {
		this.businessSubgroupName = businessSubgroupName;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getBusinessUnitName() {
		return businessUnitName;
	}

	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}

	public String getVpOrg() {
		return vpOrg;
	}

	public void setVpOrg(String vpOrg) {
		this.vpOrg = vpOrg;
	}

	public String getVpOrgName() {
		return vpOrgName;
	}

	public void setVpOrgName(String vpOrgName) {
		this.vpOrgName = vpOrgName;
	}

	public String getCell() {
		return cell;
	}

	public void setCell(String cell) {
		this.cell = cell;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountryDesc() {
		return countryDesc;
	}

	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getHandle() {
		return handle;
	}

	public void setHandle(String handle) {
		this.handle = handle;
	}

	public String getHrid() {
		return hrid;
	}

	public void setHrid(String hrid) {
		this.hrid = hrid;
	}

	public String getJobTitleCode() {
		return jobTitleCode;
	}

	public void setJobTitleCode(String jobTitleCode) {
		this.jobTitleCode = jobTitleCode;
	}

	public String getJobTitleName() {
		return jobTitleName;
	}

	public void setJobTitleName(String jobTitleName) {
		this.jobTitleName = jobTitleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getPager() {
		return pager;
	}

	public void setPager(String pager) {
		this.pager = pager;
	}

	public String getPagerPin() {
		return pagerPin;
	}

	public void setPagerPin(String pagerPin) {
		this.pagerPin = pagerPin;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public String getPrefixName() {
		return prefixName;
	}

	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNameSuffix() {
		return nameSuffix;
	}

	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getSupervisorAttuid() {
		return supervisorAttuid;
	}

	public void setSupervisorAttuid(String supervisorAttuid) {
		this.supervisorAttuid = supervisorAttuid;
	}

	public String getA1() {
		return a1;
	}

	public void setA1(String a1) {
		this.a1 = a1;
	}

	public String getCogs() {
		return cogs;
	}

	public void setCogs(String cogs) {
		this.cogs = cogs;
	}

	public String getSilo() {
		return silo;
	}

	public void setSilo(String silo) {
		this.silo = silo;
	}

	public String getDirectTotalReports() {
		return directTotalReports;
	}

	public void setDirectTotalReports(String directTotalReports) {
		this.directTotalReports = directTotalReports;
	}

	public String getBellsouthUid() {
		return bellsouthUid;
	}

	public void setBellsouthUid(String bellsouthUid) {
		this.bellsouthUid = bellsouthUid;
	}

	public String getCingularCuid() {
		return cingularCuid;
	}

	public void setCingularCuid(String cingularCuid) {
		this.cingularCuid = cingularCuid;
	}

	public String getFinancialLocCode() {
		return financialLocCode;
	}

	public void setFinancialLocCode(String financialLocCode) {
		this.financialLocCode = financialLocCode;
	}

	public String getEmailAlias() {
		return emailAlias;
	}

	public void setEmailAlias(String emailAlias) {
		this.emailAlias = emailAlias;
	}

	public String getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(String payrollId) {
		this.payrollId = payrollId;
	}

	public String getConsultingCompany() {
		return consultingCompany;
	}

	public void setConsultingCompany(String consultingCompany) {
		this.consultingCompany = consultingCompany;
	}

	public String getManagementLevelIndicator() {
		return managementLevelIndicator;
	}

	public void setManagementLevelIndicator(String managementLevelIndicator) {
		this.managementLevelIndicator = managementLevelIndicator;
	}

	public String getOccupancyIndicator() {
		return occupancyIndicator;
	}

	public void setOccupancyIndicator(String occupancyIndicator) {
		this.occupancyIndicator = occupancyIndicator;
	}

	public String getPrimaryGtr() {
		return primaryGtr;
	}

	public void setPrimaryGtr(String primaryGtr) {
		this.primaryGtr = primaryGtr;
	}

	public String getSecondaryGtr() {
		return secondaryGtr;
	}

	public void setSecondaryGtr(String secondaryGtr) {
		this.secondaryGtr = secondaryGtr;
	}

	public String getCpidRecordIndicator() {
		return cpidRecordIndicator;
	}

	public void setCpidRecordIndicator(String cpidRecordIndicator) {
		this.cpidRecordIndicator = cpidRecordIndicator;
	}

	public String getGeographicLocationCode() {
		return geographicLocationCode;
	}

	public void setGeographicLocationCode(String geographicLocationCode) {
		this.geographicLocationCode = geographicLocationCode;
	}

	public String getArchitecturalObjectId() {
		return architecturalObjectId;
	}

	public void setArchitecturalObjectId(String architecturalObjectId) {
		this.architecturalObjectId = architecturalObjectId;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPayrollCompanyDescription() {
		return payrollCompanyDescription;
	}

	public void setPayrollCompanyDescription(String payrollCompanyDescription) {
		this.payrollCompanyDescription = payrollCompanyDescription;
	}

	public String getContractorFlag() {
		return contractorFlag;
	}

	public void setContractorFlag(String contractorFlag) {
		this.contractorFlag = contractorFlag;
	}

	public String getPreferredMailingAddress() {
		return preferredMailingAddress;
	}

	public void setPreferredMailingAddress(String preferredMailingAddress) {
		this.preferredMailingAddress = preferredMailingAddress;
	}

	public String getJfcActivityOrigin() {
		return jfcActivityOrigin;
	}

	public void setJfcActivityOrigin(String jfcActivityOrigin) {
		this.jfcActivityOrigin = jfcActivityOrigin;
	}

	public String getPrimaryEmailAddress() {
		return primaryEmailAddress;
	}

	public void setPrimaryEmailAddress(String primaryEmailAddress) {
		this.primaryEmailAddress = primaryEmailAddress;
	}


}
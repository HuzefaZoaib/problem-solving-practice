package com.att.demo.model;

import java.util.List;

public class SearchResponse {
	private List<AppMasterDetails> appMasterDetails;
	private List<ResponseFilter> responseFilter;
	private List<String> categoryNames;
	
	private boolean similarSearchFlag;
	private String searchText;

//	public List<Categories> getCategories() {
//		return categories;
//	}
//
//	public void setCategories(List<Categories> categories) {
//		this.categories = categories;
//	}
	
	
	
	public boolean isSimilarSearchFlag() {
		return similarSearchFlag;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public void setSimilarSearchFlag(boolean similarSearchFlag) {
		this.similarSearchFlag = similarSearchFlag;
	}

	public List<String> getCategoryNames() {
		return categoryNames;
	}

	public void setCategoryNames(List<String> categoryNames) {
		this.categoryNames = categoryNames;
	}

	public List<AppMasterDetails> getAppMasterDetails() {
		return appMasterDetails;
	}

	public void setAppMasterDetails(List<AppMasterDetails> appMasterDetails) {
		this.appMasterDetails = appMasterDetails;
	}

	public List<ResponseFilter> getResponseFilter() {
		return responseFilter;
	}

	public void setResponseFilter(List<ResponseFilter> responseFilter) {
		this.responseFilter = responseFilter;
	}

//	public List<Filters> getfilters() {
//		return filters;
//	}
//
//	public void setfilters(List<Filters> responsefilters) {
//		this.filters = responsefilters;
//	}

//	public List<ResponseFilter> getResponsefilters() {
//		return responsefilters;
//	}
//
//	public void setResponsefilters(List<ResponseFilter> responsefilters) {
//		this.responsefilters = responsefilters;
//	}
//	
	
	

	

}

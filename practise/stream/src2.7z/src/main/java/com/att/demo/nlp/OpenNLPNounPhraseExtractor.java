package com.att.demo.nlp;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import opennlp.tools.chunker.ChunkerME;
import opennlp.tools.chunker.ChunkerModel;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.Span;
import org.springframework.stereotype.Component;

/**
 *
 * Extracts noun phrases from a sentence. To create sentences using OpenNLP use
 * the SentenceDetector classes.
 */
@Component
public class OpenNLPNounPhraseExtractor {

    public List<String> nounPhraseExtractor(String description) throws IOException {

        HashMap<String, Integer> termFrequencies = new HashMap<>();
        InputStream enToken = OpenNLPNounPhraseExtractor.class.getClassLoader().getResourceAsStream("en-token.bin");
        TokenizerModel tm = new TokenizerModel(enToken);
        TokenizerME wordBreaker = new TokenizerME(tm);
        InputStream enPos = OpenNLPNounPhraseExtractor.class.getClassLoader().getResourceAsStream("en-pos-maxent.bin");
        POSModel pm = new POSModel(enPos);
        POSTaggerME posme = new POSTaggerME(pm);
        InputStream enChunker = OpenNLPNounPhraseExtractor.class.getClassLoader().getResourceAsStream("en-chunker.bin");
        ChunkerModel chunkerModel = new ChunkerModel(enChunker);
        ChunkerME chunkerME = new ChunkerME(chunkerModel);

        //words is the tokenized sentence
        String[] words = wordBreaker.tokenize(description);
        //posTags are the parts of speech of every word in the sentence (The chunker needs this info of course)
        String[] posTags = posme.tag(words);
        //chunks are the start end "spans" indices to the chunks in the words array
        Span[] chunks = chunkerME.chunkAsSpans(words, posTags);
        //chunkStrings are the actual chunks
        String[] chunkStrings = Span.spansToStrings(chunks, words);
        for (int i = 0; i < chunks.length; i++) {
            String np = chunkStrings[i];
            if (chunks[i].getType().equals("NP")) {
                if (termFrequencies.containsKey(np)) {
                    termFrequencies.put(np, termFrequencies.get(np) + 1);
                } else {
                    termFrequencies.put(np, 1);
                }
            }
        }

        List<String> keywordList = new ArrayList<>();
        for ( String str : termFrequencies.keySet() ) {

            String[] arr = str.split("\\s+");


            if( arr[0].equalsIgnoreCase("the")) {
                keywordList.add(String.join(" ", Arrays.copyOfRange(arr, 1, arr.length)));
            }

            if (arr.length > 1) {
                keywordList.add(str);
            }
        }

        return keywordList;
    }


}
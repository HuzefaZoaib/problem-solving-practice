package com.att.demo.entity;

import com.azure.core.annotation.Get;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.Transient;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Entity
@Table(name = "AppMasterSubFilter")
public class AppMasterSubFilter 
{
	@Id
	@SequenceGenerator(name = "app_master_sub_filter_seq", initialValue=1000)
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "app_master_sub_filter_seq")
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "app_id")
	private Integer app_id;
	
	@Column(name = "sub_filter_id")
	private Integer sub_filter_id ;
	
	@Column(name="filter_id")
	private Integer filter_id;

	public Integer getFilter_id() {
		return filter_id;
	}

	public void setFilter_id(Integer filter_id) {
		this.filter_id = filter_id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getApp_id() {
		return app_id;
	}

	public void setApp_id(Integer app_id) {
		this.app_id = app_id;
	}

	public Integer getSub_filter_id() {
		return sub_filter_id;
	}

	public void setSub_filter_id(Integer sub_filter_id) {
		this.sub_filter_id = sub_filter_id;
	}

	@Getter
	@Setter
	public class AppMasterSubFilterDeleteLog implements Serializable {

		//
		// This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
		// and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
		// is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
		//
		// Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
		// I could face issue because of the mismatched property names from the original entity.
		//

		private Integer id;
		private Integer app_id;
		private Integer sub_filter_id;
		private Integer filter_id;
	}

}

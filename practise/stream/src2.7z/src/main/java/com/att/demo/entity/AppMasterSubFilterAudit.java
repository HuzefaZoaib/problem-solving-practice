package com.att.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "AppMasterSubFilterAudit")
public class AppMasterSubFilterAudit {
	
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "AppMasterSubFilterAuditSeq")
    @SequenceGenerator(name = "AppMasterSubFilterAuditSeq", sequenceName = "APP_MASTER_SUB_FILTER_AUDIT_ID_SEQ", allocationSize = 1, initialValue=1)
    @Column(name = "id")
	private Integer id;
	
	@Column(name = "app_id")
	private Integer app_id;
	
	@Column(name = "sub_filter_id")
	private Integer sub_filter_id ;
	
	@Column(name="filter_id")
	private Integer filter_id;
	
	@Column(name = "updatedBy")
    private String updatedBy;

    @Column(name = "updatedDateTime")
    private LocalDateTime updatedDateTime;
    
    @Column(name = "snapShotId")
    private Integer snapShotId;
    

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getApp_id() {
		return app_id;
	}

	public void setApp_id(Integer app_id) {
		this.app_id = app_id;
	}

	public Integer getSub_filter_id() {
		return sub_filter_id;
	}

	public void setSub_filter_id(Integer sub_filter_id) {
		this.sub_filter_id = sub_filter_id;
	}

	public Integer getFilter_id() {
		return filter_id;
	}

	public void setFilter_id(Integer filter_id) {
		this.filter_id = filter_id;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	

	public Integer getSnapShotId() {
		return snapShotId;
	}

	public void setSnapShotId(Integer snapShotId) {
		this.snapShotId = snapShotId;
	}

	@Override
	public String toString() {
		return "AppMasterSubFilterAudit [id=" + id + ", app_id=" + app_id + ", sub_filter_id=" + sub_filter_id
				+ ", filter_id=" + filter_id + ", updatedBy=" + updatedBy + ", updatedDateTime=" + updatedDateTime
				+ ", snapShotId=" + snapShotId + "]";
	}

	public AppMasterSubFilterAudit(Integer app_id, Integer sub_filter_id, Integer filter_id,
			String updatedBy, LocalDateTime updatedDateTime, Integer snapShotId) {
		super();
		this.app_id = app_id;
		this.sub_filter_id = sub_filter_id;
		this.filter_id = filter_id;
		this.updatedBy = updatedBy;
		this.updatedDateTime = updatedDateTime;
		this.snapShotId = snapShotId;
	}

	

	
    
    
    

}

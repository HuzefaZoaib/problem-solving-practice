package com.att.demo.repository;

import com.att.demo.entity.AppMasterAudit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppMasterAuditRepository extends JpaRepository<AppMasterAudit, Integer> {
}

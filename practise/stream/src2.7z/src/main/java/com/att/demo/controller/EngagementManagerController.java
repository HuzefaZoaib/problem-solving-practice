package com.att.demo.controller;

import com.att.demo.entity.EngagementManagerMarket;
import com.att.demo.entity.Role;
import com.att.demo.entity.User;
import com.att.demo.model.EngagementManager;
import com.att.demo.repository.EngagementManagerMarketRepository;
import com.att.demo.repository.RoleRepository;
import com.att.demo.security.UserService;
import com.att.demo.util.web.WebRequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/engagement-manager")
public class EngagementManagerController {

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private EngagementManagerMarketRepository engagementManagerMarketRepository;

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping("/list")
    public List<EngagementManager> getEngagementManagers() throws Exception {

        List<EngagementManager> market = engagementManagerMarketRepository.findAllWithMarketCsv();
        market.forEach(em ->
            em.setFullName(webRequestUtil.getUserFullNameWithAttId(em.getAttId()))
        );

        market.forEach(em ->
                em.setAvpFullName(webRequestUtil.getUserFullNameWithAttId(em.getAvpAttId()))
        );

        // Separate the records with Market HQRAN
        List<EngagementManager> hqranMarket = market.stream()
                .filter(em -> em.getMarket().contains("HQRAN"))
                .collect(Collectors.toList());

        // Remove the records with Market HQRAN
        market = market.stream()
                .filter(em -> !em.getMarket().contains("HQRAN"))
                .collect(Collectors.toList());

        market.sort(Comparator.comparing(EngagementManager::getMarket));

        // Put the hqranMarket on top of the market list
        market.addAll(0, hqranMarket);

        return market;
    }

    @GetMapping("/markets")
    public List<String> getListOfMarkets() throws Exception {

        List<EngagementManagerMarket> markets = engagementManagerMarketRepository.findAll();
        return markets.stream()
                .map(EngagementManagerMarket::getMarket)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    @PostMapping()
    public EngagementManager save(@RequestBody EngagementManager engagementManager) throws Exception {

        String managerAttId = engagementManager.getAttId();

        List<EngagementManagerMarket> engagementManagerMarkets = convertToEngagementManagerMarkets(engagementManager);
        engagementManagerMarkets.forEach(engagementManagerMarket -> {
            engagementManagerMarketRepository.save(engagementManagerMarket);
        });


        engagementManager = engagementManagerMarketRepository.findForSpecificAttIdWithMarketCsv(managerAttId);

        engagementManager.setFullName(webRequestUtil.getUserFullNameWithAttId(engagementManager.getAttId()));
        engagementManager.setAvpFullName(webRequestUtil.getUserFullNameWithAttId(engagementManager.getAvpAttId()));

        return engagementManager;
    }

    @PostMapping("/{managerAttId}")
    @Transactional
    public EngagementManager update(@PathVariable("managerAttId") String managerAttId, @RequestBody EngagementManager engagementManager) throws Exception {

        engagementManagerMarketRepository.deleteByAttId(managerAttId);

        List<EngagementManagerMarket> engagementManagerMarkets = convertToEngagementManagerMarkets(engagementManager);
        engagementManagerMarkets.forEach(engagementManagerMarket -> {
            engagementManagerMarketRepository.save(engagementManagerMarket);
        });


        engagementManager = engagementManagerMarketRepository.findForSpecificAttIdWithMarketCsv(managerAttId);

        engagementManager.setFullName(webRequestUtil.getUserFullNameWithAttId(engagementManager.getAttId()));
        engagementManager.setAvpFullName(webRequestUtil.getUserFullNameWithAttId(engagementManager.getAvpAttId()));

        return engagementManager;
    }

    @DeleteMapping("/{managerAttId}")
    @Transactional
    public void delete(@PathVariable("managerAttId") String managerAttId) throws Exception {
        engagementManagerMarketRepository.deleteByAttId(managerAttId);
    }

    private EngagementManager convertToEngagementManager(EngagementManagerMarket engagementManagerMarket) {

        EngagementManager engagementManager = new EngagementManager();
        engagementManager.setId(engagementManagerMarket.getId());
        engagementManager.setAttId(engagementManagerMarket.getAttId());
        engagementManager.setRoleId(engagementManagerMarket.getRoleId());
        engagementManager.setAvpAttId(engagementManagerMarket.getAvpAttId());
        engagementManager.setMarket(engagementManagerMarket.getMarket());

        String fullName = webRequestUtil.getUserFullNameWithAttId(engagementManager.getAttId());
        engagementManager.setFullName(fullName);

        String avpFullName = webRequestUtil.getUserFullNameWithAttId(engagementManager.getAvpAttId());
        engagementManager.setAvpFullName(avpFullName);

        Long engagementManagerRoleId = roleRepository.findByRoleName(Role.ACEHUB_ROLES.ENGAGEMENT_MANAGER.toString()).getId();
        engagementManager.setRoleId(engagementManagerRoleId);

        return engagementManager;
    }

    private List<EngagementManagerMarket> convertToEngagementManagerMarkets(EngagementManager engagementManager) {

        Long engagementManagerRoleId = roleRepository.findByRoleName(Role.ACEHUB_ROLES.ENGAGEMENT_MANAGER.toString()).getId();

        // Split the market CSV into individual markets
        String[] markets = engagementManager.getMarket().split(",");
        List<EngagementManagerMarket> engagementManagerMarkets = new ArrayList<>();
        for (String market : markets) {
            EngagementManagerMarket engagementManagerMarket = new EngagementManagerMarket();
            engagementManagerMarket.setId(engagementManager.getId());
            engagementManagerMarket.setAttId(engagementManager.getAttId());
            engagementManagerMarket.setRoleId(engagementManagerRoleId);
            engagementManagerMarket.setAvpAttId(engagementManager.getAvpAttId());
            engagementManagerMarket.setMarket(market.trim());

            engagementManagerMarkets.add(engagementManagerMarket);
        }

        return engagementManagerMarkets;
    }
}

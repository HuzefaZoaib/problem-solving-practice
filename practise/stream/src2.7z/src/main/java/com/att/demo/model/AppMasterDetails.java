package com.att.demo.model;

import com.att.demo.entity.JobAid;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class AppMasterDetails {

    private int id;
    private String ITAP;
    private String name;
    private String category;
    private String installType;
    private String descriptionOneLine;
    private String description;
    private String imageUrl;
    private String applicationContact;
    private boolean onboardStatus;
    private String intendedUser;
    private String UseCases;
    private String subcategory;
    private String Keywords;
    private String ToolProvider;
    private String appUrl;
    private String ApplicationOwner;
    private String ApplicationType;
    private String fullName;
    private String launchStatus;
    private String domain;
    private String functionalMappings;
    private Boolean addNewApplication = false;
	private List<JobAid> jobAids = new ArrayList<>();

    public String getFunctionalMappings() {
        if (functionalMappings == null) {
            return "";
        }
        return functionalMappings;
    }
}

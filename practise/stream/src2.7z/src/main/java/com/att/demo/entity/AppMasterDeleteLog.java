package com.att.demo.entity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "app_master_delete_log")
public class AppMasterDeleteLog {

	//
	// This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
	// and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
	// is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
	//
	// Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
	// I could face issue because of the mismatched property names from the original entity.
	//

	private static final Logger logger= LoggerFactory.getLogger(AppMasterDeleteLog.class);

	// ID will be the same as the AppMaster ID
	// this primary key will be provided the application
	@Id
	private Integer app_id;

	@Column(name = "itap_id")
	private String ITAP;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "category_id")
	private int category;

	@Column(name = "install_type")
	private String installType;

	@Column(name = "description_one_line")
	private String descriptionOneLine;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "image_url")
	private String imageUrl;

	@Column(name = "application_contact")
	private String applicationContact;
	
	@Column(name = "onboard_status")
	private Boolean onboardStatus;
	
	@Column(name = "intended_user")
	private String intendedUser;
	
	@Column(name="UseCases")
	private String UseCases;

	@Column(name="subcategory_id")
	@JoinColumn(name="subcategory_id", nullable=false)
	private int subcategoryid;

	@Column(name="ToolProvider")
	private String ToolProvider;
	
	@Column(name = "app_url")
    private String appUrl;
	
	@Column(name="ApplicationOwner")
	private String ApplicationOwner;
	
	@Column(name="ApplicationType")
	private String ApplicationType;
	
	@Column(name="fullName")
	private String fullName;

	@Column(name="domain", length = 100)
	private String domain;

	@Column(columnDefinition = "boolean default false")
	private boolean deletedFlag;

	@Column
	private String deletedByAttId;

	@Column
	@Temporal(TemporalType.TIMESTAMP)
	private Date deletedOn;

	@Column(name="launchStatus")
	private String launchStatus;

	// Storing as a JSON
	@Column(columnDefinition = "text")
	private String appMasterSubFilterListJson;

	// Storing as a JSON
	@Column(columnDefinition = "text")
	private String keywordListJson;

	// Storing as a JSON
	@Column(columnDefinition = "text")
	private String functionalMappingListJson;

	// Storing as a JSON
	@Column(columnDefinition = "text")
	private String featureRequestListJson;

	public void setId(Integer appId) {
		this.app_id = appId;
	}

	public Integer getId() {
		return this.app_id;
	}

	// List to JSON Conversions
	@Transient
	private ObjectMapper objectMapper;

	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public void setAppMasterSubFilters(List<AppMasterSubFilter> appMasterSubFilters) {
		try {
			List<AppMasterSubFilter.AppMasterSubFilterDeleteLog> appMasterSubFilterDeleteLogs = appMasterSubFilters.stream()
					.map(appMasterSubFilter -> {
						AppMasterSubFilter.AppMasterSubFilterDeleteLog appMasterSubFilterDeleteLog = appMasterSubFilter.new AppMasterSubFilterDeleteLog();
						BeanUtils.copyProperties(appMasterSubFilter, appMasterSubFilterDeleteLog);
						return appMasterSubFilterDeleteLog;
					}).toList();

			this.appMasterSubFilterListJson = this.objectMapper.writeValueAsString(appMasterSubFilterDeleteLogs);
		} catch (IOException e) {
			logger.info("Error converting appMasterSubFilters to JSON: " + e.getMessage());
		}
    }

	public void setKeywordList(List<Keyword> keywords) {
		try {
			List<Keyword.KeywordDeleteLog> deleteLogs = keywords.stream()
					.map(entity -> {
						Keyword.KeywordDeleteLog deleteLog = entity.new KeywordDeleteLog();
						BeanUtils.copyProperties(entity, deleteLog);
						return deleteLog;
					}).toList();

			this.keywordListJson = this.objectMapper.writeValueAsString(deleteLogs);
		} catch (IOException e) {
			logger.info("Error converting keywords to JSON: " + e.getMessage());
		}
	}

	public void setFunctionalMappings(List<AppFunctionalMapping> functionalMappings) {
		try {
			List<AppFunctionalMapping.AppFunctionalMappingDeleteLog> deleteLogs = functionalMappings.stream()
					.map(entity -> {
						AppFunctionalMapping.AppFunctionalMappingDeleteLog deleteLog = entity.new AppFunctionalMappingDeleteLog();
						BeanUtils.copyProperties(entity, deleteLog);
						return deleteLog;
					}).toList();

			this.functionalMappingListJson = this.objectMapper.writeValueAsString(deleteLogs);
		} catch (IOException e) {
			logger.info("Error converting functionalMappings to JSON: " + e.getMessage());
		}
	}

	public void setFeatureRequests(List<FeatureRequest> featureRequests) {
		try {
			List<FeatureRequest.FeatureRequestDeleteLog> deleteLogs = featureRequests.stream()
					.map(entity -> {
						FeatureRequest.FeatureRequestDeleteLog deleteLog = entity.new FeatureRequestDeleteLog();
						BeanUtils.copyProperties(entity, deleteLog);
						return deleteLog;
					}).toList();

			this.featureRequestListJson = this.objectMapper.writeValueAsString(deleteLogs);
		} catch (IOException e) {
			logger.info("Error converting featureRequests to JSON: " + e.getMessage());
		}
	}
}

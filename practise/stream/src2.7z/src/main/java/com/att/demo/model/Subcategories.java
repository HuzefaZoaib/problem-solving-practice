package com.att.demo.model;

import java.util.List;
import java.util.Map;

public class Subcategories {
	private String name;
	 private List<AppMasterDetails> apps;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<AppMasterDetails> getApps() {
		return apps;
	}
	public void setApps(List<AppMasterDetails> apps) {
		this.apps = apps;
	}
	@Override
	public String toString() {
		return "SubCategories [name=" + name + ", apps=" + apps + "]";
	}
	

}

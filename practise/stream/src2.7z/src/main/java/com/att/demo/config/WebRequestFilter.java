package com.att.demo.config;

import com.att.demo.util.web.WebRequestUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;

import java.io.IOException;

public class WebRequestFilter  implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        WebRequestUtil.setRequest(request);
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } finally {
            WebRequestUtil.clear();
        }
    }
}

package com.att.demo.controller;

import com.att.demo.entity.FunctionalMapping;
import com.att.demo.model.FunctionalMappingTree;
import com.att.demo.service.FunctionMappingService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/function-mapping")
public class FunctionMappingController {

    @Autowired
    private FunctionMappingService functionMappingService;

    @GetMapping(value = "/list-active")
    public List<FunctionalMappingTree> getAllActiveFunctionalMappings(HttpServletRequest request){
        return functionMappingService.getFunctionMappingTree();
    }

    @GetMapping(value = "/list")
    public List<FunctionalMappingTree> getFunctionalMappings(HttpServletRequest request){
        return functionMappingService.getFunctionMappingTree(request);
    }

    @PostMapping(value = "/{parentId}")
    public FunctionalMappingTree saveFunctionalMappingNode(@PathVariable Integer parentId, @RequestBody String name,
                                                           @RequestParam("appId") Optional<String> appId,
                                                           HttpServletRequest httpServletRequest){

        FunctionalMapping newFunctionalMapping = functionMappingService.saveNewFunctionalMapping(parentId, name, appId, httpServletRequest);

        return new FunctionalMappingTree(newFunctionalMapping.getId(),
                newFunctionalMapping.getName(), newFunctionalMapping.getLevel(),
                newFunctionalMapping.getStatus());
    }

    @PutMapping(value = "/approve/{functionMappingId}")
    public FunctionalMappingTree approve(@PathVariable Integer functionMappingId){
        return functionMappingService.approve(functionMappingId);
    }

    @PutMapping(value = "/reject/{functionMappingId}")
    public FunctionalMappingTree reject(@PathVariable Integer functionMappingId){
        return functionMappingService.reject(functionMappingId);
    }

    @PostMapping(value = "/approved/{parentId}")
    public FunctionalMappingTree saveApprovedFunctionMappingNode(@PathVariable Integer parentId, @RequestBody String name, HttpServletRequest httpServletRequest){

        FunctionalMapping newFunctionalMapping = functionMappingService.saveNewApprovedFunctionMapping(parentId, name, httpServletRequest);

        return new FunctionalMappingTree(newFunctionalMapping.getId(),
                newFunctionalMapping.getName(), newFunctionalMapping.getLevel(),
                newFunctionalMapping.getStatus());
    }

    @DeleteMapping(value = "/approved/{nodeId}")
    public FunctionalMappingTree deleteApprovedFunctionMappingNode(@PathVariable Integer nodeId, HttpServletRequest httpServletRequest){

        FunctionalMapping newFunctionalMapping = functionMappingService.deleteApprovedFunctionMapping(nodeId, httpServletRequest);

        return new FunctionalMappingTree(newFunctionalMapping.getId(),
                newFunctionalMapping.getName(), newFunctionalMapping.getLevel(),
                newFunctionalMapping.getStatus());
    }

    @PutMapping(value = "/approved/{nodeId}")
    public FunctionalMappingTree updateApprovedFunctionMappingNode(@PathVariable Integer nodeId, @RequestBody String updatedName, HttpServletRequest httpServletRequest){

        FunctionalMapping newFunctionalMapping = functionMappingService.updateApprovedFunctionMapping(nodeId, updatedName, httpServletRequest);

        return new FunctionalMappingTree(newFunctionalMapping.getId(),
                newFunctionalMapping.getName(), newFunctionalMapping.getLevel(),
                newFunctionalMapping.getStatus());
    }
}

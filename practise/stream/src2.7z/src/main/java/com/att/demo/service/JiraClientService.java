package com.att.demo.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class JiraClientService {

    private static final Logger logger= LoggerFactory.getLogger(JiraClientService.class);

    @Autowired
    private RestTemplate restTemplate;

    @Value("${jira.base.api.url}")
    private String JIRA_BASE_API_URL;

    @Value("${jira.bearer.token}")
    private String JIRA_BEARER_TOKEN;

    @Value("${jira.project.key}")
    private String JIRA_PROJECT_KEY;

    @Value("${jira.parent.epic.key}")
    private String JIRA_PARENT_EPIC_KEY;

    @Autowired
    private ObjectMapper mapper;

    public String createIssue(String summary, String description, String assignee) throws Exception {

        String issueJsonStr = ResourceUtilService.readFileFromResources("jira-request/create-issue.json");
        ObjectNode issueJson = (ObjectNode) mapper.readTree(issueJsonStr);

        ObjectNode fields = (ObjectNode)issueJson.get("fields");
        fields.put("summary", summary);
        fields.put("description", description);

        ObjectNode projectNode = (ObjectNode)fields.get("project");
        projectNode.put("key", JIRA_PROJECT_KEY);

        ObjectNode _assignee = (ObjectNode)fields.get("assignee");
        _assignee.put("name", assignee);

        String issueJsonStrTranslated = mapper.writeValueAsString(issueJson);
        logger.info("Create Issue Request: "+issueJsonStrTranslated);

        String key = "";
        try {
            key = postCreateIssue(issueJsonStrTranslated);
        } catch (org.springframework.web.client.HttpClientErrorException.BadRequest e) {

            // in case incorrect assignee this message will be thrown
            // org.springframework.web.client.HttpClientErrorException$BadRequest:
            // 400 : "{"errorMessages":[],"errors":{"assignee":"User 'na3839' does not exist."}}"
            // replace will return "{"errorMessages":[],"errors":{"assignee":"User 'na3839' does not exist."}}"

            try {
                String _msg = e.getMessage();
                _msg = _msg.replace("400 : ", "");
                _msg = _msg.substring(1, _msg.length() - 1); // remove the start and end quotes
                JsonNode errorNode = mapper.readTree(_msg);
                if (errorNode.has("errors") && errorNode.get("errors").has("assignee")) {
                    throw new AssigneeNotFoundException(
                            assignee,
                            errorNode.get("errors").get("assignee").asText());
                }
            }catch(AssigneeNotFoundException aex) {
                throw aex;
            }catch(Exception ex) {
                logger.error("Error while parsing the error message from Jira API: " + e.getMessage(), ex);
            }

            throw e;
        }

        linkToParentEpic(key);
        return key;
    }

    public void updateIssue(String issueKey, String summary, String description) throws Exception {

        if(isClosed(issueKey)) {
            return;
        }

        String issueJsonStr = ResourceUtilService.readFileFromResources("jira-request/update-issue.json");
        ObjectNode issueJson = (ObjectNode) mapper.readTree(issueJsonStr);

        ObjectNode summaryFld = (ObjectNode)issueJson.get("update").get("summary").get(0);
        summaryFld.put("set", summary);

        ObjectNode desField = (ObjectNode)issueJson.get("fields");
        desField.put("description", description);

        String issueJsonStrTranslated = mapper.writeValueAsString(issueJson);
        logger.info("Update Issue Request: "+issueJsonStrTranslated);

        putUpdateIssue(issueKey, issueJsonStrTranslated);
    }

    public void cancelIssue(String issueKey) throws Exception {

        if(isClosed(issueKey)) {
            return;
        }

        String issueJsonStr = ResourceUtilService.readFileFromResources("jira-request/cancel-issue.json");
        ObjectNode issueJson = (ObjectNode) mapper.readTree(issueJsonStr);

        String issueJsonStrTranslated = mapper.writeValueAsString(issueJson);
        logger.info("Close Issue Request: "+issueJsonStrTranslated);

        transistionIssue(issueKey, issueJsonStrTranslated);
    }

    public String getIssue(String key) {

        HttpEntity<String> requestEntity = new HttpEntity<>(getJiraApiHeaders());
        ResponseEntity<String> response = restTemplate.exchange(
                getJiraUpdateIssueAPIURL(key), HttpMethod.GET, requestEntity, String.class);

        logger.info("Response from API for getIssue: " + response.getBody());

        return response.getBody();
    }

    public String getIssueStatus(String key) throws Exception {

        String issueJsonStr = this.getIssue(key);
        ObjectNode issueJson = (ObjectNode) mapper.readTree(issueJsonStr);

        return issueJson.get("fields").get("status").get("name").asText();
    }

    public void linkToParentEpic(String key) throws Exception {

        String linkJsonStr = ResourceUtilService.readFileFromResources("jira-request/link-issue.json");
        ObjectNode linkJson = (ObjectNode)mapper.readTree(linkJsonStr);

        ((ObjectNode)linkJson.get("outwardIssue")).put("key", key);
        ((ObjectNode)linkJson.get("inwardIssue")).put("key", JIRA_PARENT_EPIC_KEY);

        String linkJsonStrTranslated = mapper.writeValueAsString(linkJson);
        logger.info("Link Issue: "+linkJsonStrTranslated);
        postIssue(linkJsonStrTranslated);
    }

    private String postCreateIssue(String fileContent)  {

        HttpEntity<String> request = new HttpEntity<>(fileContent, getJiraApiHeaders());
        ObjectNode response = restTemplate.postForObject(getJiraCreateIssueAPIURL(), request, ObjectNode.class);

        logger.info("Response from API for Create Issue: " + response.toPrettyString());

        return response.get("key").asText();
    }

    private void putUpdateIssue(String issueKey, String fileContent)  {

        HttpEntity<String> request = new HttpEntity<>(fileContent, getJiraApiHeaders());
        restTemplate.put(getJiraUpdateIssueAPIURL(issueKey), request);
    }

    private void postIssue(String fileContent)  {

        HttpEntity<String> request = new HttpEntity<>(fileContent, getJiraApiHeaders());
        restTemplate.postForObject(getJiraLinkIssueAPIURL(), request, String.class);

        // IssueLink is a POST API but it is not returning any response, for reference
        // https://developer.atlassian.com/cloud/jira/platform/rest/v2/api-group-issue-links/#api-rest-api-2-issuelink-linkid-get
    }

    private void transistionIssue(String issueKey, String fileContent)  {

        HttpEntity<String> request = new HttpEntity<>(fileContent, getJiraApiHeaders());
        restTemplate.postForObject(getJiraStatusChangeIssueAPIURL(issueKey), request, String.class);

        // IssueLink is a POST API but it is not returning any response, for reference
        // https://developer.atlassian.com/cloud/jira/platform/rest/v2/api-group-issue-links/#api-rest-api-2-issuelink-linkid-get
    }

    private HttpHeaders getJiraApiHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(this.JIRA_BEARER_TOKEN.trim());

        return headers;
    }

    private String getJiraAPIBaseURL() {
        return this.JIRA_BASE_API_URL;
    }

    private String getJiraCreateIssueAPIURL() {
        return getJiraAPIBaseURL()+"/issue/";
    }

    private String getJiraUpdateIssueAPIURL(String key) {
        return getJiraAPIBaseURL()+"/issue/"+key;
    }

    private String getJiraLinkIssueAPIURL() {
        return getJiraAPIBaseURL()+"/issueLink";
    }

    private String getJiraStatusChangeIssueAPIURL(String key) {
        return getJiraAPIBaseURL()+"/issue/"+key+"/transitions";
    }

    private boolean isClosed(String issueKey) throws Exception {
        String status = this.getIssueStatus(issueKey);
        if("Closed".equals(status)) {
            logger.info("Issue:{} is already closed, so not updating it.", issueKey);
            return true;
        }

        if("Cancelled".equals(status)) {
            logger.info("Issue:{} is already cancelled, so not updating it.", issueKey);
            return true;
        }

        return false;
    }

    public class AssigneeNotFoundException extends Exception {

        private String assignee;

        public AssigneeNotFoundException(String assignee, String message) {
            super(message);
            this.assignee = assignee;
        }

        public String getAssignee() {
            return assignee;
        }
    }
}

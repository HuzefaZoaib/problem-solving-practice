package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.Category;
import com.att.demo.model.SearchRequest;
import com.att.demo.model.SearchResponse;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

    default String getName(Integer id) {
        if(id == null) {
            return "";
        }

        Optional<Category> category = findById(id);
        if(!category.isPresent()) {
            return "";
        }

        return category.get().getName();
    }

    @Query(value="select category_id as id, category_name as name from category", nativeQuery = true)
    List<Object[]> findAllIdAndName();
}

package com.att.demo.model;

public class FilterValues
{
	private String filterValueName;
	private String filterValueCount;

	
	public FilterValues(String filterValueName, String filterValueCount) {
		super();
		this.filterValueName = filterValueName;
		this.filterValueCount = filterValueCount;
	}
	public FilterValues()
	{
		
	}
	@Override
	public String toString() {
		return "FilterValues [filterValueName=" + filterValueName + ", filterValueCount=" + filterValueCount + "]";
	}

	public String getFilterValueName() {
		return filterValueName;
	}
	public void setFilterValueName(String filterValueName) {
		this.filterValueName = filterValueName;
	}
	public String getFilterValueCount() {
		return filterValueCount;
	}
	public void setFilterValueCount(String filterValueCount) {
		this.filterValueCount = filterValueCount;
	}
	

}

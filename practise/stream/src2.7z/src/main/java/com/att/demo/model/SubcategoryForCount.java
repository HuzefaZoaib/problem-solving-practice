package com.att.demo.model;

public class SubcategoryForCount extends Subcategories
{

	public SubcategoryForCount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	private int subcategoryid;
	private int categoryid;
	public int getSubcategoryid() {
		return subcategoryid;
	}
	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	@Override
	public String toString() {
		return "SubcategoryForCount [subcategoryid=" + subcategoryid + ", categoryid=" + categoryid + "]";
	}
	
	

}

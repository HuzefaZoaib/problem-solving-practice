package com.att.demo.service;

import java.util.List;


import java.util.Map;
import java.util.Optional;

import com.att.demo.model.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.att.demo.entity.AppMaster;

import com.att.demo.service.AppMasterServiceImpl.OwnerRecord;

public interface AppMasterService {

	enum TAB_ACTIVITY {
		LAUNCHED(1),
		GAIN_FOCUS(2),
		CLOSED(3),
		LOST_FOCUS(4),	// Tab Switched due to some other tab closed
		LAUNCHED_IN_NEW_BROWSER(5);

		int id;
		int getId() {
			return id;
		};

		TAB_ACTIVITY(int id) {
			this.id = id;
		}
	};

	AppMaster saveAppMaster(AppMaster appMaster);

	List<AppMaster> saveAppMasters(List<AppMaster> appMasters);

	List<AppMaster> getAppMasters();

	AppMasterDetails getAppMasterByItapID(String itapid);

	//String deleteAppMasterByItapID(String itapid);
	
//	AppMaster searchAppMaster(AppMaster appMaster);
	
	SearchResponse getAppMasterBySearch(SearchRequest searchRequest);
	
	SearchReponseWithFilter getAppMasterByFilter(SearchRequest searchRequest);

	FavoriteRequest addAppIdToFavorite(FavoriteRequest favoriteRequest);
	
	List<Integer> getFavoriteAppByUserId(String userId);
	
	List<SubCategory> getSubCategories(int categor_id);

	List<AppNameDropDownData> getAppNameDropDownData();

	int getSubCatogeryId(String subcategoryName);
	
	Map<String, List> getMasterDropDownData();
	
	String updateKeywords(int app_id, List<String> keywords);
	
	String addNewApplication(AppMaster appMasterDetail);
	
	List<String> getAppKeyWords(int app_id);

	List<Integer> getAppFunctionalMappingIds(Integer appId);

	ResponseEntity<?> updateExistingApp(AppMasterDetails appMasterDetail, HttpServletRequest httpServletRequest);

	List<AppMasterDetails> getFavoriteAppMasterDetailsByAttId(String attId);

	void addAppIdToRecent(RecentRequest recentRequest);
	
	List<AppMasterDetails> getRecentTenAppIds(String user_id);
	
	
	List<AppMasterDetails> getRecentAndFavorite(String user_id);
	
	String getLoginUserFullName(String LoginId);
	
	String updateFavoriteOrder(FavoriteOrderAttId favoriteOrderAttId);
	
	List<AppMasterDetails> getAllMyApps(String user_id);
	
	String getLearnMore(int catgeory_id, String subcatgory_name);

	ResponseEntity<?> uploadAppThumbnail(HttpServletRequest httpServletRequest, MultipartFile thumbnail, String uploadInfo, String category, String subcategory, Map<String,MultipartFile> jobAidDocuments) throws org.springframework.web.multipart.MaxUploadSizeExceededException;

	ResponseEntity<?> uploadAppThumbnail(HttpServletRequest httpServletRequest, MultipartFile thumbnail, String uploadInfo, String category, String subcategory);

	ResponseEntity<?>  getAppThumbnail(HttpServletRequest httpServletRequest, String category, String subcategory, String imgName);

    String tabActivity(int app_id, TAB_ACTIVITY tabActivity, HttpServletRequest httpServletRequest);

	ResponseEntity<?> getViewMoreData(int categoryId, int subcategoryId, boolean retiredToggle);

	void loadAppContacts();

	Map<String,String> getLoadedAppContacts();
}



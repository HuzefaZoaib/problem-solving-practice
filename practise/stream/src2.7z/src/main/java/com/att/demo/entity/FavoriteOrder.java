package com.att.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "FavoriteOrder")
public class FavoriteOrder 
{
	
	public FavoriteOrder() {
		super();
	}

	public FavoriteOrder(String att_id, String favorder) {
		super();
		this.att_id = att_id;
		this.favorder = favorder;
	}
	
	@Id
	@Column(name = "att_id")
	private String att_id;
	 
	@Column(name = "favorder")
	private String favorder;
	
	public String getAtt_id() {
		return att_id;
	}

	public void setAtt_id(String att_id) {
		this.att_id = att_id;
	}

	public String getFavorder() {
		return favorder;
	}

	public void setFavorder(String favorder) {
		this.favorder = favorder;
	}

	
	
	
	

}

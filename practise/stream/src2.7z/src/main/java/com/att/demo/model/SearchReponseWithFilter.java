package com.att.demo.model;

import java.util.List;

public class SearchReponseWithFilter
{
	List<Categories> categories;
	List<ResponseFilter> responseFilter;
	public List<Categories> getCategories() {
		return categories;
	}
	public void setCategories(List<Categories> categories) {
		this.categories = categories;
	}
	public List<ResponseFilter> getResponseFilter() {
		return responseFilter;
	}
	public void setResponseFilter(List<ResponseFilter> responseFilter) {
		this.responseFilter = responseFilter;
	}
	
	

}

package com.att.demo.service;


import com.att.demo.model.WeeklyAppUsage;
import com.att.demo.model.WeeklyTrafficUsage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserActivityProfilingService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${sqlTop10Applications}")
    private String sqlTop10Applications;

    @Value("${sqlAppActiveDuration}")
    private String sqlAppActiveDuration;

    @Value("${sqlTabAppGroupingDuration}")
    private String sqlTabAppGroupingDuration;

    @Value("${sqlTrafficWeeklyUsage}")
    private String sqlTrafficWeeklyUsage;

    @Value("${sqlTrafficWeeklyUsageParamBased}")
    private String sqlTrafficWeeklyUsageParamBased;

    @Value("${sqlTrafficMonthlyUsageParamBased}")
    private String sqlTrafficMonthlyUsageParamBased;

    @Value("${sqlAppWeeklyUsage}")
    private String sqlAppWeeklyUsage;

    @Value("${sqlAceHubTrafficUsageDefaultMinMaxDate}")
    private String sqlAceHubTrafficUsageDefaultMinMaxDate;

    public Map<String,Integer> findTop10Applications() {
        Map<String,Integer> appLaunchCounts = new LinkedHashMap<String,Integer>();
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlTop10Applications);
        for (Map<String, Object> row : rows) {
            String app_id = String.valueOf(row.get("app_name"));
            Integer count = Integer.valueOf(String.valueOf(row.get("launch_count")));
            appLaunchCounts.put(app_id, count);
        }

        return appLaunchCounts;
    }

    public Map<String, BigDecimal> findAppActiveDuration() {
        Map<String,BigDecimal> results = new LinkedHashMap<String,BigDecimal>();
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlAppActiveDuration);
        for (Map<String, Object> row : rows) {
            String app_id = String.valueOf(row.get("app_id"));
            BigDecimal activeTime = new BigDecimal(String.valueOf(row.get("app_total_active_time")));
            results.put(app_id, activeTime);
        }

        return results;
    }

    public Map<String, BigDecimal> findTabAppGroupingDuration() {
        Map<String,BigDecimal> results = new LinkedHashMap<String,BigDecimal>();
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlAppActiveDuration);
        for (Map<String, Object> row : rows) {
            String app_id = String.valueOf(row.get("app_id"));
            BigDecimal activeTime = new BigDecimal(String.valueOf(row.get("total_active_time")));
            results.put(app_id, activeTime);
        }

        return results;
    }

    public List<WeeklyTrafficUsage> findWeeklyTrafficUsage() {

        List<WeeklyTrafficUsage> results = jdbcTemplate.query(sqlTrafficWeeklyUsage, (rs, rowNum) -> {
            WeeklyTrafficUsage weeklyTrafficUsage = new WeeklyTrafficUsage();
            weeklyTrafficUsage.setCountUniqueHit(rs.getInt("count_unique_hit"));
            weeklyTrafficUsage.setCountTotalHit(rs.getInt("count_total_hit"));
            weeklyTrafficUsage.setWeekStart(rs.getDate("week_start"));
            return weeklyTrafficUsage;

        }, new Object[]{});

        return results;
    }

    public List<WeeklyAppUsage> findWeeklyAppUsage() {

        List<WeeklyAppUsage> results = jdbcTemplate.query(sqlAppWeeklyUsage, new Object[]{}, (rs, rowNum) -> {
            WeeklyAppUsage weeklyAppUsage = new WeeklyAppUsage();
            weeklyAppUsage.setAppId(rs.getString("app_id"));
            weeklyAppUsage.setAppName(rs.getString("app_name"));
            weeklyAppUsage.setAppLaunchHit(rs.getInt("app_launch_hit"));
            weeklyAppUsage.setWeekStart(rs.getDate("week_start"));

            return weeklyAppUsage;
        });

        // fetch app ids
        List<Integer> appIds = results.stream().map(WeeklyAppUsage::getAppId).map(Integer::parseInt).toList();
        Map<Integer, String> appColors = generateAppColors(appIds);

        // set color code
        for (WeeklyAppUsage weeklyAppUsage : results) {
            String appId = weeklyAppUsage.getAppId();
            String colorCode = appColors.get(Integer.parseInt(appId));
            weeklyAppUsage.setColorCode(colorCode);
        }

        return results;
    }

    public Map<Integer, String> generateAppColors(List<Integer> appIds) {
        Map<Integer, String> appColors = new LinkedHashMap<>();
        for (Integer appId : appIds) {
            int hash = appId.hashCode();
            int r = (hash & 0xFF0000) >> 16;
            int g = (hash & 0x00FF00) >> 8;
            int b = hash & 0x0000FF;
            String color = String.format("#%02X%02X%02X", r, g, b);
            appColors.put(appId, color);
        }
        return appColors;
    }

    public List<String> findAceHubTrafficUsageDefaultMinMaxDate() {
        List<String> results = new ArrayList<>();

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");

        jdbcTemplate.query(sqlAceHubTrafficUsageDefaultMinMaxDate, new RowCallbackHandler() {
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                results.add(df.format(rs.getDate("min_date")));
                results.add(df.format(rs.getDate("max_date")));
            }
        });

        return results;
    }

    public List<WeeklyTrafficUsage> findWeeklyTrafficUsage(Map<String, String> params) {

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");

        List<WeeklyTrafficUsage> results = new ArrayList<>();

        results = jdbcTemplate.query(sqlTrafficWeeklyUsageParamBased, (rs, rowNum) -> {
            WeeklyTrafficUsage weeklyTrafficUsage = new WeeklyTrafficUsage();
            weeklyTrafficUsage.setCountUniqueHit(rs.getInt("count_unique_hit"));
            weeklyTrafficUsage.setCountTotalHit(rs.getInt("count_total_hit"));
            weeklyTrafficUsage.setWeekStart(rs.getDate("week_start"));
            return weeklyTrafficUsage;

        }, params.get("startDateStr"),
                params.get("endDateStr"));


        return results;
    }

    public List<WeeklyTrafficUsage> findMonthlyTrafficUsage(Map<String, String> params) {

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");

        List<WeeklyTrafficUsage> results = new ArrayList<>();

        results = jdbcTemplate.query(sqlTrafficMonthlyUsageParamBased, (rs, rowNum) -> {
                    WeeklyTrafficUsage weeklyTrafficUsage = new WeeklyTrafficUsage();
                    weeklyTrafficUsage.setCountUniqueHit(rs.getInt("count_unique_hit"));
                    weeklyTrafficUsage.setCountTotalHit(rs.getInt("count_total_hit"));
                    weeklyTrafficUsage.setWeekStart(rs.getDate("month_start"));
                    return weeklyTrafficUsage;

                }, params.get("startDateStr"),
                params.get("endDateStr"));


        return results;
    }
}



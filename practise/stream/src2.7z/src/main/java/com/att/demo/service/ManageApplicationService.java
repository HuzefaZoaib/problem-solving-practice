package com.att.demo.service;

import com.att.demo.entity.AppMaster;
import com.att.demo.entity.AppMasterDeleteLog;
import com.att.demo.entity.FeatureRequest;
import com.att.demo.model.ManageApplication;
import com.att.demo.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.lang.Collections;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ManageApplicationService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private AppMasterRepository appMasterRepository;

    @Autowired
    private AppMasterDeleteLogRepository appMasterDeleteLogRepository;

    @Autowired
    private AppMasterService appMasterService;

    @Autowired
    private AppMasterSubFilterRepository appMasterSubFilterRepository;

    @Autowired
    private KeywordRepository keywordRepository;

    @Autowired
    private AppFunctionalMappingRepository appFunctionalMappingRepository;

    @Autowired
    private ObjectMapper objectMapper;

    public List<ManageApplication> getAllApplications() {
        // This method should return a list of all ManageApplication objects
        // For now, returning an empty list

        // Fetch all the application from v_app_master and translate into ManageApplication
        // using the appMasterRepository
        List<ManageApplication> applications = jdbcTemplate.query(
            "SELECT id, name, full_name, description_one_line, application_owner, application_contact, install_type, " +
                    "(select distinct true from feature_request where app_id = app.id and deleted is null or deleted = false) as has_fr " +
                    "FROM v_app_master app order by concat(name, ' - ' ,full_name)",
            (rs, rowNum) -> {
                ManageApplication app = new ManageApplication();
                app.setId(rs.getInt("id"));
                app.setName(rs.getString("name"));
                app.setFullName(rs.getString("full_name"));
                app.setDescriptionOneLine(rs.getString("description_one_line"));
                app.setApplicationOwner(rs.getString("application_owner"));
                app.setApplicationContact(rs.getString("application_contact"));
                app.setRetiredFlag("Retired".equals(rs.getString("install_type")));
                app.setHasFeatureRequest(rs.getBoolean("has_fr"));

                return app;
            }
        );

        return applications;
    }

    public static final String DELETE_APPLICATION_ERROR = "Application cannot be deleted because it has Feature Requests. " +
            "Consider marking the application as Retired instead or " +
            "delete all the Feature Requests associated to the application, first.";

    @Transactional
    public ManageApplication deleteApplication(Integer appId, String attId) {

        // This method will delete an application and return the deleted application
        Optional<AppMaster> appMaster = appMasterRepository.findById(appId);
        if(appMaster.isPresent()) {
            AppMaster _appMaster = appMaster.get();

            // We will not delete the Feature Requests
            // we will throw an exception that Application cannot be deleted because it has Feature Requests
            if(!Collections.isEmpty(_appMaster.getFeatureRequests())
                && !_appMaster.getFeatureRequests().stream().allMatch(FeatureRequest::isDeleted)) {

                throw new RuntimeException(DELETE_APPLICATION_ERROR);
            }

            AppMasterDeleteLog appMasterDeleteLog = new AppMasterDeleteLog();
            appMasterDeleteLog.setObjectMapper(objectMapper);
            BeanUtils.copyProperties(_appMaster, appMasterDeleteLog);
            appMasterDeleteLog.setDeletedFlag(true);
            appMasterDeleteLog.setDeletedByAttId(attId);
            appMasterDeleteLog.setDeletedOn(new java.util.Date());
            appMasterDeleteLogRepository.save(appMasterDeleteLog);

            // Delete the AppMasterSubFilters
            _appMaster.getAppMasterSubFilters()
                .forEach(entry -> {
                    appMasterSubFilterRepository.deleteById(entry.getId());
                });

            // Delete the Keywords
            _appMaster.getKeywordList()
                .forEach(entry -> {
                    keywordRepository.deleteById(entry.getKeywordId());
                });

            // Delete the AppFunctionalMapping
            _appMaster.getFunctionalMappings()
                .forEach(entry -> {
                    appFunctionalMappingRepository.deleteById(entry.getId());
                });

            appMasterRepository.deleteById(appId);

            ManageApplication app = new ManageApplication();
            app.setId(_appMaster.getId());
            app.setName(_appMaster.getName());
            app.setFullName(_appMaster.getFullName());
            app.setDescriptionOneLine(_appMaster.getDescriptionOneLine());
            app.setApplicationOwner(_appMaster.getApplicationOwner());
            app.setApplicationContact(_appMaster.getApplicationContact());
            app.setRetiredFlag("Retired".equals(_appMaster.getInstallType()));

            return app;
        }

        return null;
    }
}

package com.att.demo.security;

import com.att.demo.entity.User;
import com.att.demo.repository.UserRepository;
import com.att.demo.service.AppMasterService;
import com.att.demo.util.web.WebRequestUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuthenticationService {

    private static final Logger logger= LoggerFactory.getLogger(AuthenticationService.class);

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ApplicationContext applicationContext;

    public ResponseEntity<?> authenticateUser(HttpServletRequest httpServletRequest){

        String userId= this.webRequestUtil.getWebJunctionData(httpServletRequest);
        if(null == userId || userId.isEmpty()){
            return ResponseEntity.badRequest().body("User ID is missing in the header!");
        }
        User user= null;
        try{
            user = userService.saveOrUpdateUser(userId);
            populateUserAppDetails(user);
        }catch (Exception e){
            logger.error(Arrays.toString(e.getStackTrace()));
        }

        String token= jwtUtil.generateToken(userId);
        ResponseCookie jwtCookie= ResponseCookie.from("jwt", token)
                .httpOnly(true)
                .secure(true)
                .path("/")
                .maxAge(24 * 60 * 60)
                .build();

        return ResponseEntity.ok()
                .header("Set-Cookie", jwtCookie.toString())
                .body(user);
    }

    public ResponseEntity<?> authenticateUserToken(HttpServletRequest request) {
        Cookie[] cookies= request.getCookies();

        Cookie jwtCookie = cookies != null ? Arrays.stream(cookies)
                .filter(cookie -> "jwt".equalsIgnoreCase(cookie.getName()))
                .findFirst()
                .orElse(null) : null;

        if(jwtCookie!=null) {

            String userId="";
            String token = jwtCookie.getValue();
            try {
                Claims claims = jwtUtil.getClaimsFromToken(token);
                userId = claims.getSubject();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            if(userId!=null){
                UserDetails userDetails= this.userService.loadUserByUsername(userId); // this is fetching from user_login table

                if(jwtUtil.validateToken(token, userDetails)){
                    User user= userRepository.findByUserId(userId); // this is fetching from fn_user table

                    if(user!=null) {
                        populateUserAppDetails(user);
                        return ResponseEntity.ok(user);
                    }

                    return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
                }
            }

        } else if(this.webRequestUtil.getWebJunctionData(request) != null &&
                        !this.webRequestUtil.getWebJunctionData(request).isBlank() ) {

            return this.authenticateUser(request);
        }

        return ResponseEntity.status(401).body(false);
    }

    public boolean isLoginUserAdmin() {
        List<GrantedAuthority> lst = this.userService.loadUserByUsername(webRequestUtil.getUserAttId()).getAuthorities().stream().filter(
                authority -> authority.getAuthority().equals("ACE Hub Admin")).collect(Collectors.toList());

        return !lst.isEmpty();
    }

    public void populateUserAppDetails(User user) {

        AppMasterService appMasterService = applicationContext.getBean(AppMasterService.class);
        user.setHasFavorite(!appMasterService.getFavoriteAppMasterDetailsByAttId(user.getAttId()).isEmpty());
        user.setHasRecent(!appMasterService.getRecentTenAppIds(user.getAttId()).isEmpty());
        user.setHasManaged(!appMasterService.getAllMyApps(user.getAttId()).isEmpty());

    }
}

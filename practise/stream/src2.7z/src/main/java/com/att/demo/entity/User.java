package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@Table(name = "user_login")
public class User {

    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "UserLoginIdSeq")
    @SequenceGenerator(name = "UserLoginIdSeq", sequenceName = "USER_LOGIN_ID_SEQ", allocationSize = 1, initialValue=1)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id")
    private String userId;

    @Column(name="full_name")
    private String fullName;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> role;

    public String getAttId() {
        return userId;
    }

    @Transient
    private boolean hasFavorite;

    @Transient
    private boolean hasRecent;

    @Transient
    private boolean hasManaged;
}
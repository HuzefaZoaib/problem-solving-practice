package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.demo.entity.Keyword;

import java.util.List;
import java.util.stream.Collectors;

public interface KeywordRepository extends JpaRepository<Keyword, Integer> {

    List<Keyword> findByAppId(Integer appId);

    default String getKeywordsByAppId(Integer appId) {
        List<Keyword> keywords = this.findByAppId(appId);
        return keywords.stream().map(Keyword::getKeyword).collect(Collectors.joining("|"));
    }
}
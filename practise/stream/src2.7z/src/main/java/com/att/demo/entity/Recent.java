package com.att.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Recent")
public class Recent 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "recentSeq")
	@SequenceGenerator(name = "recentSeq", sequenceName = "RECENT_ID", allocationSize = 1)
	@Column(name = "id")
	private Long id;

	@Column(name = "att_id")
	private String att_id;
	
	@Column(name = "app_id")
	private int app_id;
	
	@Column(name = "inserted_date_time")
	private LocalDateTime inserted_date_time;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAtt_id() {
		return att_id;
	}

	public void setAtt_id(String att_id) {
		this.att_id = att_id;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public LocalDateTime getInserted_date_time() {
		return inserted_date_time;
	}

	public void setInserted_date_time(LocalDateTime inserted_date_time) {
		this.inserted_date_time = inserted_date_time;
	}
	

}

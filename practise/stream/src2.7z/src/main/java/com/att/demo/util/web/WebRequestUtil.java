package com.att.demo.util.web;

import com.att.demo.model.WebPhone;
import com.att.demo.service.AppMasterServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface WebRequestUtil {

    WebPhone getUserByAttId(String attid);

    String getWebJunctionData(HttpServletRequest request);

    default String getUserAttId() {
        return this.getWebJunctionData(WebRequestUtil.getCurrentHttpRequest());
    }

    static ThreadLocal<HttpServletRequest> requestThreadLocal = new ThreadLocal<>();

    static void setRequest(HttpServletRequest request) {
        requestThreadLocal.set(request);
    }

    static void clear() {
        requestThreadLocal.remove();
    }

    static HttpServletRequest getRequest() {
        return requestThreadLocal.get();
    }

    static HttpServletRequest getCurrentHttpRequest() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return attrs.getRequest();
    }

    default String getFullNameFromAttID(String attId) {
        String firstName = "";
        String lastName = "";
        List<AppMasterServiceImpl.OwnerRecord> fullnameList = new ArrayList<AppMasterServiceImpl.OwnerRecord>();
        WebPhone webPhone = getUserByAttId(attId);

        if(webPhone == null){
            return null;
        }else{
            firstName = webPhone.getFirstName();
            lastName = webPhone.getLastName();
            if(!firstName.isEmpty() && ! lastName.isEmpty()) {
                return firstName.concat(" ").concat(lastName);
            }else if(!firstName.isEmpty()) {
                return firstName;
            }else if(!lastName.isEmpty()) {
                return lastName;
            }
        }

        return null; //if first and last names are null/empty
    }

    default String fetchFullNameWithAttIdFromWebPhone(String attId) throws Exception {

        WebPhone webPhone = getUserByAttId(attId);

        if (webPhone == null) {
            return null;
        } else {

            String firstName = webPhone.getFirstName();
            String lastName = webPhone.getLastName();
            firstName = capitalize(firstName);
            lastName = capitalize(lastName);

            String fullName = firstName + " " + lastName+" ("+attId+")";
            return  fullName;
        }
    }

    Logger logger= LoggerFactory.getLogger(WebRequestUtil.class);

    Map<String, String> CACHED_FULL_NAME_WITH_ATT_ID = new HashMap<>();

    default String getUserFullNameWithAttId(String attId) {

        String fullName = attId;
        try {
            if(StringUtils.isAllBlank(attId)) {
                return "";
            }

            // If the user is already in the cache, return the cached value
            if(CACHED_FULL_NAME_WITH_ATT_ID.containsKey(attId)) {
                return CACHED_FULL_NAME_WITH_ATT_ID.get(attId);
            }

            fullName = fetchFullNameWithAttIdFromWebPhone(attId);
            if (fullName != null) {
                CACHED_FULL_NAME_WITH_ATT_ID.put(attId, fullName);
            } else {
                CACHED_FULL_NAME_WITH_ATT_ID.put(attId, attId);
                logger.error("AttId: {}, Full Name: Not Found", attId);
            }
        } catch (Exception e) {
            CACHED_FULL_NAME_WITH_ATT_ID.put(attId, attId);
            logger.info("Error fetching user details for AttId: " + attId + " - " + e.getMessage());
            //logger.error("Error fetching user details for AttId: " + attId + " - " + e.getMessage(), e);
        }

        return fullName;
    }

    default String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        // name could have a space in between also
        String[] parts = str.split(" ");
        StringBuilder capitalized = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                capitalized.append(StringUtils.capitalize(part.toLowerCase()));
                capitalized.append(" ");
            }
        }

        return capitalized.toString().trim();
    }
}

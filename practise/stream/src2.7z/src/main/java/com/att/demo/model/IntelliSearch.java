package com.att.demo.model;

import java.util.List;

public class IntelliSearch
{
	private String searchText;
	private List<String> similarSearch;
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	public List<String> getSimilarSearch() {
		return similarSearch;
	}
	public void setSimilarSearch(List<String> similarSearch) {
		this.similarSearch = similarSearch;
	}
	
	

}

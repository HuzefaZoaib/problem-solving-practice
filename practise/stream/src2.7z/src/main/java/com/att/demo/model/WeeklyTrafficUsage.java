package com.att.demo.model;

import lombok.Getter;
import lombok.Setter;

import java.text.SimpleDateFormat;
import java.util.Date;

@Getter
@Setter
public class WeeklyTrafficUsage {

    private Date weekStart;
    private Integer countUniqueHit;
    private Integer countTotalHit;

    public String getWeekStartStr() {

        // Convert Date to String in the format "yyyy-MM-dd"
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return weekStart != null ? dateFormat.format(weekStart) : "";
    }

}

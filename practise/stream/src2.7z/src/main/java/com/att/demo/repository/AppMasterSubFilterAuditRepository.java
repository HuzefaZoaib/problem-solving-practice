package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.demo.entity.AppMasterSubFilterAudit;


public interface AppMasterSubFilterAuditRepository extends JpaRepository<AppMasterSubFilterAudit, Integer> {
}

package com.att.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Subcategory")
public class SubCategory
{
	@Id
	@Column(name = "subcategory_id")
	private int subcategoryid;
	
	@Column(name = "subcategory_name")
	private String name;
	
	@OneToMany(mappedBy = "subcategoryid", cascade = CascadeType.ALL)
    private List<AppMaster> apps;
	
	@Column(name="category_id")
	@JoinColumn(name="category_id", nullable=false)
	private int categoryid;
	
	public int getSubcategoryid() {
		return subcategoryid;
	}
	
	@Column(name="learnMoreData")  
	private String learnMoreData;



	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getLearnMoreData() {
		return learnMoreData;
	}

	public void setLearnMoreData(String learnMoreData) {
		this.learnMoreData = learnMoreData;
	}

	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<AppMaster> getApps() {
		return apps;
	}

	public void setApps(List<AppMaster> apps) {
		this.apps = apps;
	}
	

}

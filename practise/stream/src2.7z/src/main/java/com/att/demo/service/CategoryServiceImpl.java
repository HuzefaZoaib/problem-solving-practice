package com.att.demo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

import com.att.demo.entity.UserInfo;
import com.att.demo.entity.FnUserAudit;
import com.att.demo.model.WebPhone;
import com.att.demo.repository.KeywordRepository;
import com.att.demo.repository.UserInfoRepository;
import com.att.demo.util.web.WebRequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.att.demo.entity.Category;
import com.att.demo.model.AppMasterDetails;
import com.att.demo.model.Categories;
import com.att.demo.model.Subcategories;
import com.att.demo.repository.CategoryRepository;
import com.att.demo.repository.UserAuditRepository;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	UserInfoRepository userInfoRepository;

	@Autowired
	UserAuditRepository userAuditRepository;

	@Autowired
	KeywordRepository keywordRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	@Qualifier("postgresqlJdbcTemplate")
	private JdbcTemplate template;

	private final ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private WebRequestUtil webRequestUtil;

	public Category saveCategory(Category category) {
		return categoryRepository.save(category);
	}

	public List<Category> saveCategories(List<Category> categories) {
		return categoryRepository.saveAll(categories);
	}

	public List<Category> getcategories() {
		return categoryRepository.findAll();
	}

	public Optional<Category> getCategoryByID(int categoryid) {
		return categoryRepository.findById(categoryid);
	}

	public String deleteCategory(int categoryid) {
		categoryRepository.deleteById(categoryid);
		return "AppMaster Removed";

	}

	public List<Categories> getcategoriesWithCount(boolean retiredToggle) {

		List<Categories> results = new ArrayList<>();
		String queryForCategoryWithCount="";
		if(retiredToggle)
		{
			queryForCategoryWithCount = "SELECT * FROM app_master ";
			
		}
		else
		{
			queryForCategoryWithCount = "SELECT * FROM app_master where install_type!='Retired' ";
			
		}
			
		System.out.println("queryForCategoryWithCount: " + queryForCategoryWithCount);

		template.query(queryForCategoryWithCount, new RowMapper<Object>() {

			@Override
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				int categoryId1 = resultSet.getInt("category_id");
				String categoryQuery1 = "SELECT category_name FROM category WHERE category_id = ?";
				String categoryName1 = template.queryForObject(categoryQuery1, String.class, categoryId1);
				System.out.println(categoryName1);
				Categories category = null;

				for (Categories existingCategory : results) {
					if (existingCategory.getName().equals(categoryName1)) {
						category = existingCategory;
						break;
					}
				}
//				List<SubCategories> subcategories = null;
				if (category == null) {
					category = new Categories();
					category.setName(categoryName1);
					category.setSubCategories(new ArrayList<>());
					results.add(category);
				}

				Subcategories subcategory = new Subcategories();
				int subcategoryId = resultSet.getInt("subcategory_id");
				String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
				String subcategoryName = template.queryForObject(subcategoryQuery, String.class, subcategoryId);
				System.out.println(subcategoryQuery);
				subcategory.setName(subcategoryName);

				List<AppMasterDetails> apps = new ArrayList<>();
				AppMasterDetails app = new AppMasterDetails();
				app.setName(resultSet.getString("name"));
				app.setCategory(categoryName1);
				app.setSubcategory(subcategoryName);
				app.setDescription(resultSet.getString("description"));
				app.setId(resultSet.getInt("id"));
				app.setDescriptionOneLine(resultSet.getString("description_one_line"));
				app.setImageUrl(resultSet.getString("image_url"));
				app.setInstallType(resultSet.getString("install_type"));
				app.setApplicationOwner(resultSet.getString("application_owner"));
				app.setApplicationType(resultSet.getString("application_type"));
				app.setFullName(resultSet.getString("full_name"));
				app.setLaunchStatus(resultSet.getString("launch_status"));


//				select sub_filter_name from sub_filters where id in
//				(select sub_filter_id from app_master_sub_filter where app_id= 13 and filter_id=2);

				String intendedUserQuery="select sub_filter_name from sub_filters where id in"
						+ "(select sub_filter_id from app_master_sub_filter where app_id= "+app.getId()+" and filter_id=2)";
				List<String> IntendedUserList=template.queryForList(intendedUserQuery,String.class);
				app.setIntendedUser(String.join(", ", IntendedUserList));
				app.setITAP(resultSet.getString("itap_id"));

				final String keywords = keywordRepository.getKeywordsByAppId(resultSet.getInt("id"));
				app.setKeywords(keywords);
				app.setOnboardStatus(resultSet.getBoolean("onboard_status"));
				app.setToolProvider(resultSet.getString("tool_provider"));
				app.setUseCases(resultSet.getString("use_cases"));
				app.setDomain(resultSet.getString("domain"));
				app.setApplicationContact(resultSet.getString("application_contact"));
				app.setAppUrl(resultSet.getString("app_url"));
				app.setFullName(resultSet.getString("full_name"));
				apps.add(app);
				subcategory.setApps(apps);
				category.getSubcategories().add(subcategory);
				category.setCount(category.getSubcategories().size());
				//System.out.println("category: " + category.toString());
				return null;
			}

		});
		System.out.println("In Line 119");

		List<Categories> formattedResult = new ArrayList<>();

		for (Categories category : results) {
			System.out.println("In Line 123");

			List<Subcategories> formattedSubCatList = new ArrayList<>();

			for (Subcategories subCat : category.getSubcategories()) {

				boolean addSubCat = true;
				for (Subcategories existingSubCategory : formattedSubCatList) {
					if (existingSubCategory.getName().equals(subCat.getName())) {
						existingSubCategory.getApps().addAll(subCat.getApps());
						addSubCat = false;
						break;
					}

				}
				if (addSubCat) {
					System.out.println("In addSubCat");

					formattedSubCatList.add(subCat);

				}
				category.setSubCategories(formattedSubCatList);

			}
			formattedResult.add(category);
		}

		for (int index = 0; index < formattedResult.size(); index++) {
			int count = 0;
			for (int y = 0; y < formattedResult.get(index).getSubcategories().size(); y++) {
				count = count + formattedResult.get(index).getSubcategories().get(y).getApps().size();
			}
			System.out.println("Count="+count);
			formattedResult.get(index).setCount(count);
			//System.out.println("formattedResult: " + formattedResult);
		}
		List<Categories> formattedOrderList = new ArrayList<Categories>();
		formattedOrderList.add(getCategoryByName("Plan", formattedResult));
		formattedOrderList.add(getCategoryByName("Design", formattedResult));
		formattedOrderList.add(getCategoryByName("Build", formattedResult));	
		formattedOrderList.add(getCategoryByName("Operate", formattedResult));

		return formattedOrderList;
	}
	private Categories getCategoryByName(String name, List<Categories> formattedList) {
		Categories c = new Categories();
		for (Categories cat : formattedList) {
			if (cat.getName().equals(name)) {
				c = cat;
			}
		}
		return c;
	}

	@Override
	public void checkUserInfo(String attId) throws Exception {
		List<UserInfo> userInfo = userInfoRepository.findByOrgUserId(attId);
		if(userInfo.isEmpty()){
			WebPhone webPhone = webRequestUtil.getUserByAttId(attId);
			UserInfo userInfo1 = new UserInfo();
			Date lastLoginDate=new Date();
			userInfo1.setLastLoginDate(lastLoginDate);
			userInfo1.setFirstName(webPhone.getFirstName());
			userInfo1.setLastName(webPhone.getLastName());
			userInfo1.setOrgUserId(attId);
			userInfoRepository.save(userInfo1);
		}
	}

	@Override
	public String insertAuditLog(String attId) {

		List<UserInfo> userInfo = userInfoRepository.findByOrgUserId(attId);
		long user_id=userInfo.get(0).getOrgId();
		FnUserAudit fnUserAudit = new FnUserAudit();
		fnUserAudit.setAttId(attId);
		fnUserAudit.setOrgId(user_id);

		LocalDateTime localDateTime = LocalDateTime.now();
		fnUserAudit.setAccessedDateAndTime(localDateTime);
		fnUserAudit.setResource("Home Page");
		try
		{
			userAuditRepository.save(fnUserAudit);
			return "Audited for User:"+attId;

		}
		catch(Exception e)
		{
			return "Not Audited for User :"+attId;
		}
	}

	@Override
	public List<Category> getAllCategories() {

		List<Object[]> categories = categoryRepository.findAllIdAndName();

		List<Category> categoryList = new ArrayList<>();
		for (Object[] category : categories) {
			Category cat = new Category();
			cat.setId((Integer) category[0]);
			cat.setName((String) category[1]);
			categoryList.add(cat);
		}

		return categoryList;
	}

	@Override
	public String getCategoryName(Integer categoryId, Optional<String> defaultReturnVal) {
		if(categoryId == null) {
			return defaultReturnVal.orElse("");
		}

		Optional<Category> category = categoryRepository.findById(categoryId);
		if(!category.isPresent()) {
			return defaultReturnVal.orElse("");
		}

		return category.get().getName();
	}

	@Override
	public String getSubCategoryName(Integer subcategoryId, Optional<String> defaultReturnVal) {

		try {
			String subcategoryQuery = "SELECT subcategory_name FROM subcategory WHERE subcategory_id = ?";
			return template.queryForObject(subcategoryQuery, String.class, subcategoryId);
		} catch(org.springframework.dao.EmptyResultDataAccessException e) {
			// Handle the case where no subcategory is found
			return defaultReturnVal.orElse("");
		}
	}
}
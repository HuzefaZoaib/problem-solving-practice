package com.att.demo;

import com.att.demo.service.AppMasterService;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.att.demo.repository.AppMasterRepository;

import javax.sql.DataSource;
import java.util.Properties;

@SpringBootApplication(scanBasePackages={
		"com.att.demo", "com.att.demo.service","com.att.demo.controller"})
@EnableJpaRepositories(basePackageClasses = AppMasterRepository.class)
public class RanMarketplaceApplication implements ApplicationListener<ApplicationStartedEvent> {

	@Autowired
	private AppMasterService appMasterService;

	public static void main(String[] args) {

		SpringApplication application = new SpringApplication(RanMarketplaceApplication.class);

		// To split the password within the property
		String emailPassword = getEmailPassword();
		String emailUser = getEmailUser();

		Properties properties = new Properties();
		properties.put("spring.mail.username", emailUser);
		properties.put("spring.mail.password", emailPassword);
		application.setDefaultProperties(properties);

		application.run(args);
	}

	private static String getEmailPassword() {
		String mtaCredentials = System.getenv("EMAIL_USER_PSWD");
		if (mtaCredentials != null && mtaCredentials.indexOf(':') > 0)
			return mtaCredentials.substring(mtaCredentials.indexOf(":") + 1);

		return mtaCredentials;
	}

	private static String getEmailUser() {
		String mtaCredentials = System.getenv("EMAIL_USER_PSWD");
		String username = mtaCredentials;
		if (mtaCredentials != null && mtaCredentials.indexOf(':') > 0)
			 username = mtaCredentials.substring(0, mtaCredentials.indexOf(":"));

		return username+"-AP@MTA01.ATT-MAIL.COM";
	}

	@Autowired
	private DataSource dataSource;

	@Override
	public void onApplicationEvent(ApplicationStartedEvent event) {
		// Setup the Flyway in a way that it will execute the DML scripts only
		// after Hibernate/SpringJPA will done with the DDL matching the Entities
		Flyway.configure().baselineOnMigrate(true).dataSource(dataSource).load().migrate();

		appMasterService.loadAppContacts();
	}
}

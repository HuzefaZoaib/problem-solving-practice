package com.att.demo.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class PostgresqlConfig {
	@Bean
	@ConfigurationProperties("spring.datasource.postgresql")
	public DataSourceProperties postgresqlDataSourceProperties(){
		return new DataSourceProperties();
	}

	@Bean(name="postgresqldb")
	@ConfigurationProperties(prefix = "spring.datasource.postgresql")
	public DataSource postgresqlDataSource(){
		return postgresqlDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name="postgresqlJdbcTemplate")
	public JdbcTemplate postgresqlJdbcTemplate(@Qualifier("postgresqldb") DataSource ds){
		return new JdbcTemplate(ds);
	}
}

package com.att.demo.model;

import java.util.List;


public class Filters {
	private String filtername;
	private int filterNameCount;
	private List<String> filtervalues;
	private int filterValuesCount;
	public String getFiltername() {
		return filtername;
	}
	public void setFiltername(String filtername) {
		filtername = filtername.trim().replace(' ', '_');
		filtername = filtername.toLowerCase();
		this.filtername = filtername;
	}
	
	
	public List<String> getFiltervalues() {
		return filtervalues;
	}
	public void setFiltervalues(List<String> filtervalues) {
		this.filtervalues = filtervalues;
	}
	public int getFilterNameCount() {
		return filterNameCount;
	}
	public void setFilterNameCount(int filterNameCount) {
		this.filterNameCount = filterNameCount;
	}
	public int getFilterValuesCount() {
		return filterValuesCount;
	}
	public void setFilterValuesCount(int filterValuesCount) {
		this.filterValuesCount = filterValuesCount;
	}
	@Override
	public String toString() {
		return "Filters [filtername=" + filtername + ", filterNameCount=" + filterNameCount + ", filtervalues="
				+ filtervalues + ", filterValuesCount=" + filterValuesCount + "]";
	}

}

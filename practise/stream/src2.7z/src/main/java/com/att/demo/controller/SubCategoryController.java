package com.att.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.demo.entity.SubCategory;
import com.att.demo.service.SubCategoryService;

@RestController
public class SubCategoryController {
	

	@Autowired
	private SubCategoryService subCategoryService;
	
	
	@GetMapping(value = "/restcontroller-get-subCategory-data")
	public List<SubCategory> findAll() {

		return subCategoryService.getsubcategories();
	}
	
	@GetMapping(value = "/restcontroller-get-subCategory-data-by-id/{id}")
	public Optional<SubCategory> find(@PathVariable int id) {

		return subCategoryService.getSubCategoryByID(id);
	}
	
	@PostMapping(value = "/restcontroller-subCategory-data-save")
	public HttpStatusCode AppMasterInster(@RequestBody SubCategory subCategory)
	{
		subCategoryService.saveSubCategory(subCategory);
		
		return HttpStatus.CREATED;
		
	
	}
	
	@DeleteMapping(value = "/restcontroller-SubCategory-data-delete/{itapid}")
	public String SubCategoryDelete(@PathVariable int id) {
		
		return subCategoryService.deleteSubCategory(id);
		
	}
	
	
	
	
	
	
	

}

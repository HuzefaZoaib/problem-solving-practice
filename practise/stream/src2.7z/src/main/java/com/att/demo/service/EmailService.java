/*
 * ============LICENSE_START==========================================
 * ONAP Portal SDK
 * ===================================================================
 * Copyright © 2017 AT&T Intellectual Property. All rights reserved.
 * ===================================================================
 *
 * Unless otherwise specified, all software contained herein is licensed
 * under the Apache License, Version 2.0 (the "License");
 * you may not use this software except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *             http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Unless otherwise specified, all documentation contained herein is licensed
 * under the Creative Commons License, Attribution 4.0 Intl. (the "License");
 * you may not use this documentation except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *             https://creativecommons.org/licenses/by/4.0/
 *
 * Unless required by applicable law or agreed to in writing, documentation
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ============LICENSE_END============================================
 *
 *
 */
package com.att.demo.service;

import com.att.demo.entity.AppConfigInDB;
import com.att.demo.repository.AppConfigInDBRepository;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.Arrays;


@Service
public class EmailService {

    private static final Logger logger= LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender emailSender;

    @Value("${spring.mail.username}")
    private String from;

    @Autowired
    private AppConfigInDBRepository appConfigInDBRepository;

    public void emailSimpleMessage(String subject, String body, String to, String[] cc) throws MessagingException {

        if ("true".equalsIgnoreCase(
                appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.DISABLE_EMAIL_NOTIFICATION))) {

            logger.info("Email notification is disabled. Therefore, not sending email with Subject: {}, To: {}, CC: {}",
                    subject, to, Arrays.toString(cc));
            return;
        }

        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");

        helper.setFrom("ACE Hub Notification <" + from + ">");
        helper.setTo(to);
        if (cc != null && cc.length > 0) {
            helper.setCc(cc);
        }
        helper.setSubject(subject);
        helper.setText(body, true);

        System.out.println(MessageFormat.format("Email is going to be send. From:{0}, To:{1} with Subject:{2}",
                Arrays.asList(message.getFrom()), to, message.getSubject()));

        emailSender.send(message);
    }

    public void emailSimpleMessage(String subject, String body, String[] to, String[] cc) throws MessagingException {

        if ("true".equalsIgnoreCase(
                appConfigInDBRepository.getValue(AppConfigInDB.APP_CONFIGS.DISABLE_EMAIL_NOTIFICATION))) {

            logger.info("Email notification is disabled. Therefore, not sending email with Subject: {}, To: {}, CC: {}",
                    subject, Arrays.toString(to), Arrays.toString(cc));

            return;
        }

        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");

        helper.setFrom("ACE Hub Notification <" + from + ">");
        helper.setTo(to);
        if (cc != null && cc.length > 0) {
            helper.setCc(cc);
        }
        helper.setSubject(subject);
        helper.setText(body, true);

        System.out.println(MessageFormat.format("Email is going to be send. From:{0}, To:{1} with Subject:{2}",
                Arrays.asList(message.getFrom()), Arrays.asList(to), message.getSubject()));

        emailSender.send(message);
    }
}

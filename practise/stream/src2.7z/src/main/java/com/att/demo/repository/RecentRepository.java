package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.Favorite;
import com.att.demo.entity.Recent;


@Repository
public interface RecentRepository extends JpaRepository<Recent, Long>{

}

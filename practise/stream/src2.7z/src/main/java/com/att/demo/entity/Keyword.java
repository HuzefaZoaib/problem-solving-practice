package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Table(name = "Keyword")
public class Keyword 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "KeywordIdSeq")
	@SequenceGenerator(name = "KeywordIdSeq", sequenceName = "KEYWORD_ID", allocationSize = 1, initialValue=2000)
	@Column(name = "keywordId")
	private int keywordId;
	
	@Column(name = "keyword")
	private String keyword ;
	
	@Column(name = "appId")
	private int appId ;
	
	@Column(name="appName")
	private String appName;
	
	@Column(name="fullName")
	private String fullName;

	@Column(name = "status")
	private String status ;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getKeywordId() {
		return keywordId;
	}

	public void setKeywordId(int keywordId) {
		this.keywordId = keywordId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	@Override
	public String toString() {
		return "Keyword [keywordId=" + keywordId + ", keyword=" + keyword + ", appId=" + appId + "]";
	}

	@Getter
	@Setter
	public class KeywordDeleteLog implements Serializable {

		//
		// This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
		// and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
		// is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
		//
		// Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
		// I could face issue because of the mismatched property names from the original entity.
		//

		private int keywordId;
		private String keyword ;
		private int appId ;
		private String appName;
		private String fullName;
		private String status ;

	}
}

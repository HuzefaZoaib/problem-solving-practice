package com.att.demo.service;

import com.att.demo.entity.AppFunctionalMapping;
import com.att.demo.entity.FunctionalMapping;
import com.att.demo.entity.UserInfo;
import com.att.demo.model.FunctionalMappingTree;
import com.att.demo.model.WebPhone;
import com.att.demo.repository.AppFunctionalMappingRepository;
import com.att.demo.repository.AppMasterRepository;
import com.att.demo.repository.FunctionalMappingRepository;
import com.att.demo.repository.UserInfoRepository;
import com.att.demo.util.web.WebRequestUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.*;

@Service
public class FunctionMappingService {

    @Autowired
    private FunctionalMappingRepository functionalMappingRepository;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserInfoRepository userInfoRepository;

    @Autowired
    private AppFunctionalMappingRepository appFunctionalMappingRepository;

    @Autowired
    private AppMasterRepository appMasterRepository;

    @Value("${function.mapping.admin.url}")
    private String functionMappingAdminUrl;

    @Value("${function.mapping.admin.emails}")
    private String functionMappingAdminEmails;

    public List<FunctionalMappingTree> getFunctionMappingTree() {

        List<FunctionalMapping> functionalMappings = functionalMappingRepository.findByActive(true);

        return createFunctionMappingTree(functionalMappings);
    }

    public List<FunctionalMappingTree> getFunctionMappingTree(HttpServletRequest request) {

        String userId = this.webRequestUtil.getWebJunctionData(request);
        List<FunctionalMapping> functionalMappings = functionalMappingRepository.findByActiveAndStatusApproved(true);
        functionalMappings.addAll( functionalMappingRepository.findByActiveAndUpdatedByAndStatusPending(true, userId) );

        return createFunctionMappingTree(functionalMappings);
    }

    public List<FunctionalMappingTree> createFunctionMappingTree(List<FunctionalMapping> functionalMappings) {

        Comparator<FunctionalMapping> c = (n1, n2) -> n1.getLevel().compareTo(n1.getLevel());
        functionalMappings.sort(c);
        OptionalInt maxLevelOp = functionalMappings.stream().mapToInt(FunctionalMapping::getLevel).max();

        List<FunctionalMappingTree> nodeDtoList = new ArrayList<>();
        Map<String,FunctionalMappingTree> nodes = new HashMap<>();

        for (FunctionalMapping fm : functionalMappings) {
            if ("root".equals(fm.getParent())) {
                FunctionalMappingTree t = new FunctionalMappingTree(
                        fm.getId(), fm.getChild(), fm.getLevel(), fm.getStatus());
                nodeDtoList.add(t);
                nodes.put(fm.getChild(), t);
            }
        }

        for(int i=2; maxLevelOp.isPresent() && i<=maxLevelOp.getAsInt(); i++) {
            for (FunctionalMapping fm : functionalMappings) {
                if (fm.getLevel() == i) {
                    FunctionalMappingTree t = new FunctionalMappingTree(
                            fm.getId(), fm.getChild(), fm.getLevel(), fm.getStatus());
                    nodes.get(fm.getParent()).getChildren().add(t);
                    nodes.put(fm.getChild(), t);
                }
            }
        }

        return nodeDtoList;
    }

    public FunctionalMapping saveNewFunctionalMapping(Integer parentId, String child,
                                                      Optional<String> appId,
                                                      HttpServletRequest httpServletRequest) {

        // Special case, to save a node at the root
        if(parentId==-4999) {
            return this.saveNewFunctionalMappingAtRoot(child, httpServletRequest, appId);
        }

        Optional<FunctionalMapping> _parent = this.functionalMappingRepository.findById(parentId);

        if(_parent.isPresent()) {
            FunctionalMapping parent = _parent.get();
            FunctionalMapping newFunctionalMapping = new FunctionalMapping();
            newFunctionalMapping.setParent(parent.getName());
            newFunctionalMapping.setName(child);
            newFunctionalMapping.setLevel(parent.getLevel()+1);
            newFunctionalMapping.setStatus(FunctionalMapping.FunctionalMappingStatus.Pending);

            String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
            newFunctionalMapping.setUpdatedBy(userId);

            this.functionalMappingRepository.save(newFunctionalMapping);

            String[] adminEmails = functionMappingAdminEmails.split(",");
            for(String adminEmail : adminEmails) {
                if(!adminEmail.isBlank()) {
                    this.newFunctionMappingNotify(newFunctionalMapping, userId, adminEmail.trim(), appId);
                }
            }

            return newFunctionalMapping;
        }

        throw new RuntimeException(MessageFormat.format("Functional Mapping with parentId:{0} does not exist",parentId));
    }

    public FunctionalMapping saveNewFunctionalMappingAtRoot(String child, HttpServletRequest httpServletRequest, Optional<String> appId) {

        FunctionalMapping newFunctionalMapping = new FunctionalMapping();
        newFunctionalMapping.setParent("root");
        newFunctionalMapping.setName(child);
        newFunctionalMapping.setLevel(1);
        newFunctionalMapping.setStatus(FunctionalMapping.FunctionalMappingStatus.Pending);

        String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
        newFunctionalMapping.setUpdatedBy(userId);

        this.functionalMappingRepository.save(newFunctionalMapping);

        String[] adminEmails = functionMappingAdminEmails.split(",");
        for(String adminEmail : adminEmails) {
            if(!adminEmail.isBlank()) {
                this.newFunctionMappingNotify(newFunctionalMapping, userId, adminEmail, appId);
            }
        }

        return newFunctionalMapping;
    }

    private void newFunctionMappingNotify(FunctionalMapping newFunctionMapping, String userId, String adminEmail, Optional<String> appId) {

        String subject = "ACE Hub - New Application Function requested";
        StringBuilder emailBody = new StringBuilder("\n");
        String userName = getUserName(userId);
        userName = StringUtils.capitalize(userName);
        emailBody.append("The user "+userName+" has requested the following new function");
        if(appId.isPresent()) {
            String appName = appMasterRepository.getAppName(appId.get());
            emailBody.append(" to assign for the application \"" +appName +"\"");
        }
        emailBody.append(".\n");
        emailBody.append(newFunctionMapping.getParent()+" -> "+newFunctionMapping.getChild());
        emailBody.append("\n");
        emailBody.append("\n");
        emailBody.append("Please click below to approve or reject it\n");
        emailBody.append(functionMappingAdminUrl);
        emailBody.append("\n");

        try {
            this.emailService.emailSimpleMessage(subject, emailBody.toString(), adminEmail, null);
        }catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error occurred while sending the email for New Mapping: "
                    +newFunctionMapping.getParent()+" -> "+newFunctionMapping.getChild());
        }
    }

    public FunctionalMappingTree approve(Integer functionMappingId) {

        FunctionalMapping fm = this.functionalMappingRepository.findById(functionMappingId).get();
        fm.setStatus(FunctionalMapping.FunctionalMappingStatus.Approved);
        this.functionalMappingRepository.save(fm);

        notifyOnFunctionMappingApproveReject(fm);

        return new FunctionalMappingTree(fm.getId(),
                fm.getName(), fm.getLevel(),
                fm.getStatus());
    }

    public FunctionalMappingTree reject(Integer functionMappingId) {

        FunctionalMapping fm = this.functionalMappingRepository.findById(functionMappingId).get();
        fm.setStatus(FunctionalMapping.FunctionalMappingStatus.Rejected);
        fm.setActive(false);

        List<AppFunctionalMapping> appFunctionalMappings = appFunctionalMappingRepository.findByFunctionalMappingId(fm.getId());
        if(appFunctionalMappings.isEmpty()) {
            // If Function is not linked to any of the Application then Delete it
            this.functionalMappingRepository.delete(fm);
        } else {
            this.functionalMappingRepository.save(fm);
        }

        notifyOnFunctionMappingApproveReject(fm);

        return new FunctionalMappingTree(fm.getId(),
                fm.getName(), fm.getLevel(),
                fm.getStatus());
    }

    private void notifyOnFunctionMappingApproveReject(FunctionalMapping functionMapping) {

        String userId = functionMapping.getUpdatedBy();
        String subject = "ACE Hub: New Function Mapping has been " +functionMapping.getStatus();
        StringBuilder emailBody = new StringBuilder();
        //emailBody.append("Hi, " +functionMapping.getUpdatedBy() +",\n");
        emailBody.append("\n");
        emailBody.append("The requested function mapping for your application has been "+functionMapping.getStatus()+" by the ACE Hub Admin.\n");
        emailBody.append("Please take the necessary action, if any required.");
        emailBody.append("\n");
        emailBody.append(functionMapping.getParent()+" -> "+functionMapping.getChild());
        emailBody.append("\n");

        try {
            this.emailService.emailSimpleMessage(subject, emailBody.toString(), (userId + "@att.com"), null);
        }catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error occurred while sending the email for to notify user about Approve/Reject: "
                    +functionMapping.getParent()+" -> "+functionMapping.getChild());
        }
    }

    private String getUserName(String attId) {

        String userName = "";
        List<UserInfo> userInfo = userInfoRepository.findByOrgUserId(attId);
        if(userInfo.size() == 1){
            String value = userInfo.get(0).getFirstName();
            userName += StringUtils.capitalize(value == null ? "" :  value.toLowerCase());
            userName += " ";
            value = userInfo.get(0).getLastName();
            userName += StringUtils.capitalize(value == null ? "" :  value.toLowerCase());
        }

        return userName;
    }
    
    public FunctionalMapping saveNewApprovedFunctionMapping(Integer parentId, String child, HttpServletRequest httpServletRequest) {

        // Special case, to save a node at the root
        if(parentId==-4999) {
            return this.saveNewApprovedFunctionalMappingAtRoot(child, httpServletRequest);
        }

        Optional<FunctionalMapping> _parent = this.functionalMappingRepository.findById(parentId);

        if(_parent.isPresent()) {
            FunctionalMapping parent = _parent.get();
            FunctionalMapping newFunctionalMapping = new FunctionalMapping();
            newFunctionalMapping.setParent(parent.getName());
            newFunctionalMapping.setName(child);
            newFunctionalMapping.setLevel(parent.getLevel()+1);
            newFunctionalMapping.setStatus(FunctionalMapping.FunctionalMappingStatus.Approved);

            String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
            newFunctionalMapping.setUpdatedBy(userId);

            this.functionalMappingRepository.save(newFunctionalMapping);

            //No Notification Required
            //this.newFunctionMappingNotify(newFunctionalMapping, userId);

            return newFunctionalMapping;
        }

        throw new RuntimeException(MessageFormat.format("Functional Mapping with parentId:{0} does not exist",parentId));
    }

    public FunctionalMapping saveNewApprovedFunctionalMappingAtRoot(String child, HttpServletRequest httpServletRequest) {

        FunctionalMapping newFunctionalMapping = new FunctionalMapping();
        newFunctionalMapping.setParent("root");
        newFunctionalMapping.setName(child);
        newFunctionalMapping.setLevel(1);
        newFunctionalMapping.setStatus(FunctionalMapping.FunctionalMappingStatus.Approved);

        String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
        newFunctionalMapping.setUpdatedBy(userId);

        this.functionalMappingRepository.save(newFunctionalMapping);

        // Approved Nodes do not needs to be Notified
        //this.newFunctionMappingNotify(newFunctionalMapping, userId);

        return newFunctionalMapping;
    }

    public FunctionalMapping deleteApprovedFunctionMapping(Integer nodeId, HttpServletRequest httpServletRequest) {

        Optional<FunctionalMapping> _node = this.functionalMappingRepository.findById(nodeId);

        if(_node.isPresent()) {
            FunctionalMapping node = _node.get();
            node.setStatus(FunctionalMapping.FunctionalMappingStatus.Deleted);
            node.setActive(false);

            String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
            node.setUpdatedBy(userId);

            List<AppFunctionalMapping> appFunctionalMappings = appFunctionalMappingRepository.findByFunctionalMappingId(node.getId());
            if(appFunctionalMappings.isEmpty()) {
                functionalMappingRepository.delete(node);
            } else {
                functionalMappingRepository.save(node);
            }

            return node;
        }

        throw new RuntimeException(MessageFormat.format("Functional Mapping with nodeId:{0} does not exist",nodeId));
    }

    public FunctionalMapping updateApprovedFunctionMapping(Integer nodeId, String updatedName, HttpServletRequest httpServletRequest) {

        Optional<FunctionalMapping> _node = this.functionalMappingRepository.findById(nodeId);

        if(_node.isPresent()) {
            FunctionalMapping node = _node.get();

            // We need to change the reference also therefore get nodes where it is Parent
            List<FunctionalMapping> children = this.functionalMappingRepository.findByParent(node.getName());

            node.setName(updatedName);
            children.forEach( child -> child.setParent(updatedName) );

            String userId = this.webRequestUtil.getWebJunctionData(httpServletRequest);
            node.setUpdatedBy(userId);

            functionalMappingRepository.save(node);
            functionalMappingRepository.saveAll(children);

            return node;
        }

        throw new RuntimeException(MessageFormat.format("Functional Mapping with nodeId:{0} does not exist",nodeId));
    }
}

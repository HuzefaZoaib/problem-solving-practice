package com.att.demo.repository;

import com.att.demo.entity.SubFilters;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubFilterRepository extends JpaRepository<SubFilters, Integer> {
    List<SubFilters> findByFilterIdOrderBySubFilterNameAsc(int filterId);
}

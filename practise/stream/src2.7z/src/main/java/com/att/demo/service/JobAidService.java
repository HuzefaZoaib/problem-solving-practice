package com.att.demo.service;

import com.att.demo.repository.JobAidRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobAidService {

    @Autowired
    private JobAidRepository jobAidRepository;

}

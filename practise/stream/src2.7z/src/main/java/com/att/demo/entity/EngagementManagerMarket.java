package com.att.demo.entity;

import com.att.demo.model.EngagementManager;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@SqlResultSetMapping(name = "EngagementManagerWithMarketCsv",
        classes = @ConstructorResult(
                targetClass = EngagementManager.class,
                columns = {
                        @ColumnResult(name = "attId", type = String.class),
                        @ColumnResult(name = "market", type = String.class),
                        @ColumnResult(name = "avpAttId", type = String.class),
                }
        )
)
@NamedNativeQuery(name = "EngagementManagerMarket.findAllWithMarketCsv",
        query = "select e.att_id as attId, e.avp_att_id as avpAttId, " +
                "STRING_AGG(distinct market,', ' order by market) as market from engagement_manager_market e group by e.att_id, e.role_id, e.avp_att_id",
        resultSetMapping = "EngagementManagerWithMarketCsv")
@NamedNativeQuery(name = "EngagementManagerMarket.findForSpecificAttIdWithMarketCsv",
        query = "select e.att_id as attId, e.avp_att_id as avpAttId, " +
                "STRING_AGG(distinct market,', ' order by market) as market from engagement_manager_market e group by e.att_id, e.role_id, e.avp_att_id " +
                "having e.att_id = :attId",
        resultSetMapping = "EngagementManagerWithMarketCsv")
@Getter
@Setter
@Entity
public class EngagementManagerMarket {

    // Due to Typo Id has become String, in the production as well
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EngagementManagerMarketSeq")
    private Integer id;

    private String attId;
    private Long roleId;
    private String market;
    private String avpAttId;
}

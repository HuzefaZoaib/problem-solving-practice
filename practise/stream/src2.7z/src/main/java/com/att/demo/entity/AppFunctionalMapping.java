package com.att.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
public class AppFunctionalMapping
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "AppFunctionalMappingIdSeq")
	@SequenceGenerator(name = "AppFunctionalMappingIdSeq")
	private int id;
	
	@Column
	private Integer functionalMappingId ;
	
	@Column
	private int appId;
	
	@Column
	private String appName;
	
	@Column
	private String fullName;

	// The following column is for creating a Reference only. By the way, we are already using appId for actual mapping.
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="appId", referencedColumnName="id", insertable=false, updatable=false)
	private AppMaster appMaster;

	// The following column is for creating a Reference only. By the way, we are already using appId for actual mapping.
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="functionalMappingId", referencedColumnName="id", insertable=false, updatable=false)
	private FunctionalMapping functionalMapping;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getFunctionalMappingId() {
		return functionalMappingId;
	}

	public void setFunctionalMappingId(Integer functionalMappingId) {
		this.functionalMappingId = functionalMappingId;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public AppMaster getAppMaster() {
		return appMaster;
	}

	public void setAppMaster(AppMaster appMaster) {
		this.appMaster = appMaster;
	}

	@Setter
	@Getter
	public class AppFunctionalMappingDeleteLog implements Serializable {

		//
		// This DeleteLog version is created to void Recursion due to reference to AppMaster or other entities
		// and skip Foreign Key constraint to AppMaster while translating it to JSON. Because once AppMaster
		// is deleted then it constraints cannot be satisfied while translating back to Entity from JSON.
		//
		// Also I havn't changed the properties names because BeanUtils.copyProperties() will not work and
		// I could face issue because of the mismatched property names from the original entity.
		//

		private int id;
		private Integer functionalMappingId ;
		private int appId;
		private String appName;
		private String fullName;
	}
}

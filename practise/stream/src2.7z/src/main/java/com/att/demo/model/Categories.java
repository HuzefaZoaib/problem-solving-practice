package com.att.demo.model;

import java.util.List;

public class Categories {
	private String name;
	private int count;
	private int weight;
	private List<Subcategories> subcategories;
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	

	

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Subcategories> getSubcategories() {
		return subcategories;
	}

	public void setSubCategories(List<Subcategories> subcategories) {
		this.subcategories = subcategories;
	}

	@Override
	public String toString() {
		return "Categories [name=" + name + ", count=" + count + ", subcategories=" + subcategories + "]";
	}

	public Categories(String name, int count, List<Subcategories> subcategories) {
		super();
		this.name = name;
		this.count = count;
		this.subcategories = subcategories;
	}

	public Categories() {
		super();
	}
	
	

}

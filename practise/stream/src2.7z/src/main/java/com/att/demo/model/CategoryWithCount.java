package com.att.demo.model;



public class CategoryWithCount extends Categories {
	
	
	public CategoryWithCount() {
		super();
	}
	
	private int categoryid;
	

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	@Override
	public String toString() {
		return "CategoryWithCount [categoryid=" + categoryid + "]";
	}


	
	
	

}

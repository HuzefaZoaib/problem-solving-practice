package com.att.demo.controller;

import com.att.demo.entity.FeatureRequest;
import com.att.demo.repository.FeatureRequestRepository;
import com.att.demo.service.FeatureRequestService;
import com.att.demo.service.JiraClientService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Date;

@RestController
@RequestMapping("/api/jira")
public class JiraController {

    @Autowired
    private JiraClientService jiraClientService;

    @Autowired
    private FeatureRequestRepository featureRequestRepository;

    @Autowired
    private FeatureRequestService featureRequestService;

    @GetMapping("/status/{issueKey}/{id}")
    public ResponseEntity<?> getJiraStatus(@PathVariable String issueKey, @PathVariable Integer id) {
        try {
            String issueJsonStr = jiraClientService.getIssue(issueKey);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode issueJson = mapper.readTree(issueJsonStr);

            JsonNode fields = issueJson.get("fields");
            JsonNode statusNode = fields.get("status");

            ObjectNode result = mapper.createObjectNode();
            String _status = statusNode.get("name").asText();
            String generalizeStatus = generalizeStatue(_status);
            result.put("status", generalizeStatus);
            result.put("statusDescription", statusNode.has("description") ? statusNode.get("description").asText() : "");
            result.put("tentativeCompleteDate", fields.has("customfield_12875") && !fields.get("customfield_12875").isNull() ? fields.get("customfield_12875").asText() : "");
            result.put("environment", fields.has("environment") && !fields.get("environment").isNull() ? fields.get("environment").asText() : "");
            result.put("assignee", fields.has("assignee") && fields.get("assignee") != null && fields.get("assignee").has("displayName") ? fields.get("assignee").get("displayName").asText() : "");
            result.put("summary", fields.has("summary") ? fields.get("summary").asText() : "");
            result.put("dueDate", fields.has("duedate") && !fields.get("duedate").isNull() ? fields.get("duedate").asText() : "");

            boolean isCompleted = false;

            switch (generalizeStatus) {
                case "Completed":
                    isCompleted = updateFeatureRequestStatus(id, "Completed", result.get("assignee").asText());
                    break;
                case "Open":
                    updateFeatureRequestStatus(id, "Acknowledged", result.get("assignee").asText());
                    break;
                case "On Hold":
                    updateFeatureRequestStatus(id, "On Hold", result.get("assignee").asText());
                    break;
                case "In Progress":
                    updateFeatureRequestStatus(id, "In Progress", result.get("assignee").asText());
                    break;
                case "Rejected":
                    updateFeatureRequestStatus(id, "Rejected", result.get("assignee").asText());
                    break;
            }
            result.put("isCompleted", isCompleted);

            ArrayNode updates = mapper.createArrayNode();
            if (fields.has("comment") && fields.get("comment").has("comments")) {
                for (JsonNode comment : fields.get("comment").get("comments")) {
                    ObjectNode update = mapper.createObjectNode();
                    update.put("author", comment.has("author") && comment.get("author").has("displayName") ? comment.get("author").get("displayName").asText() : "");
                    update.put("body", comment.has("body") ? comment.get("body").asText() : "");
                    update.put("created", comment.has("created") ? comment.get("created").asText() : "");
                    updates.add(update);
                }
            }
            result.set("updates", updates);
            return ResponseEntity.ok(result);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch JIRA status: " + ex.getMessage());
        }
    }

    private boolean updateFeatureRequestStatus(Integer id, String newStatus, String assignee) {
        FeatureRequest fr = featureRequestService.getAppDetails(id);
        if (fr != null && !newStatus.equals(fr.getStatus())) {
            fr.setStatus(newStatus);
            fr.setUpdatedAt(new Date());
            fr.setUpdatedByAttId(assignee);
            try {
                featureRequestService.updateFeatureRequest(fr);
                featureRequestService.statusEmailToSubmitter(fr);
                return "Completed".equals(newStatus);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @GetMapping("/getStatus/{id}")
    public FeatureRequest getFeatureRequestById(@PathVariable Integer id) {
        return featureRequestRepository.getById(id);
    }

    private String generalizeStatue(String jiraStatus) {

        // Jira Status: Open, In Progress, Reopened, Closed, On Hold, Canceled, Abandoned, Rank
        // Map
        // - Open, In Progress, Reopened, Rank -> In Progress
        // - On Hold -> On Hold
        // - Canceled, Abandoned -> Rejected
        // - Done, Closed -> Completed

        switch (jiraStatus) {

            case "In Progress":
            case "Reopened":
            case "Rank":
                return "In Progress";
            case "On Hold":
                return "On Hold";
            case "Canceled":
            case "Abandoned":
                return "Rejected";
            case "Closed":
                return "Completed";
            default:
                return jiraStatus;

        }
    }
}

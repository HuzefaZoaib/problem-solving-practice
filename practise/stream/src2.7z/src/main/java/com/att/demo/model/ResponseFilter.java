package com.att.demo.model;

import java.util.List;

public class ResponseFilter {
	
	private String filtername;
	private int filterNameCount;
	private List<FilterValues> filtervalues;
	public String getFiltername() {
		return filtername;
	}
	public void setFiltername(String filtername)
	{
		filtername = filtername.replace('_',' ');
		String [] SplittedFilterName = filtername.split(" ");
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<SplittedFilterName.length;i++)
		{
		    
			String word = SplittedFilterName[i];
			SplittedFilterName[i] = SplittedFilterName[i].substring(0, 1).toUpperCase() + SplittedFilterName[i].substring(1);
			sb.append(SplittedFilterName[i]);
			if(i<1)sb.append(" ");
			
		}
		System.out.println(sb.toString());
		
		this.filtername = sb.toString();
	}
	public int getFilterNameCount() {
		return filterNameCount;
	}
	public void setFilterNameCount(int filterNameCount) {
		this.filterNameCount = filterNameCount;
	}
	public List<FilterValues> getFiltervalues() {
		return filtervalues;
	}
	public void setFiltervalues(List<FilterValues> filtervalues) {
		this.filtervalues = filtervalues;
	}
	public void removeSubFilter(String subfilterName) {
	    filtervalues.removeIf(subFilter -> subFilter.getFilterValueName().equals(subfilterName));
	}
	@Override
	public String toString() {
		return "ResponseFilter [filtername=" + filtername + ", filterNameCount=" + filterNameCount + ", filtervalues="
				+ filtervalues + "]";
	}
	
	

}

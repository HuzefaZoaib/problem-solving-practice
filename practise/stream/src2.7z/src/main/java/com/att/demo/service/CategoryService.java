package com.att.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.att.demo.entity.Category;
import com.att.demo.model.Categories;
import com.att.demo.model.Transaction;
import jakarta.servlet.http.HttpServletRequest;

public interface CategoryService {

	Category saveCategory(Category category);

	List<Category> saveCategories(List<Category> categories);

	List<Category> getcategories();

	Optional<Category> getCategoryByID(int categoryid);

	String deleteCategory(int categoryid);

//	void searchCategory(Transaction transaction);
	
	List<Categories> getcategoriesWithCount(boolean retiredToggle);
	
	String insertAuditLog(String loginId);

	void checkUserInfo(String attId) throws Exception;

	List<Category> getAllCategories();

	String getCategoryName(Integer categoryId, Optional<String> defaultReturnVal);

	String getSubCategoryName(Integer subcategoryId, Optional<String> defaultReturnVal);
}

package com.att.demo.controller;

import com.att.demo.exception.ErrorResponse;
import com.att.demo.model.ManageApplication;
import com.att.demo.service.ManageApplicationService;
import com.att.demo.util.web.WebRequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/manage-application")
public class ManageApplicationController {

    @Autowired
    private ManageApplicationService manageApplicationService;

    @Autowired
    private WebRequestUtil webRequestUtil;

    @GetMapping("/list")
    public List<ManageApplication> manageApplication() {
        return manageApplicationService.getAllApplications();
    }

    @DeleteMapping("/{id}")
    public ManageApplication deleteApplication(@PathVariable Integer id) {

        return manageApplicationService.deleteApplication(id, webRequestUtil.getUserAttId());
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException e) {

        if(ManageApplicationService.DELETE_APPLICATION_ERROR.equals(e.getMessage())) {
            ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), e.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }

        throw e;
    }
}

package com.att.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import java.net.InetSocketAddress;
import java.net.Proxy;

@Profile("!local")
@Configuration
public class RestTemplateEnvConfig {

    private static final Logger logger= LoggerFactory.getLogger(RestTemplateEnvConfig.class);

    @Value("${proxy.host}")
    private String proxyHost;

    @Value("${proxy.port}")
    private int proxyPort;

    @Bean
    public RestTemplate restTemplateWithProxy() {

        logger.info("RestTemplate is going to be created with proxy host: "+proxyHost+" and port: "+proxyPort);

        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        InetSocketAddress address = new InetSocketAddress(proxyHost, proxyPort);
        Proxy proxy = new Proxy(Proxy.Type.HTTP, address);
        requestFactory.setProxy(proxy);
        return new RestTemplate(requestFactory);
    }
}

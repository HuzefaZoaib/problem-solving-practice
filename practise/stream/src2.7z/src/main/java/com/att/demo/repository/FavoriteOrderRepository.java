package com.att.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.demo.entity.Category;
import com.att.demo.entity.FavoriteOrder;

@Repository
public interface FavoriteOrderRepository extends JpaRepository<FavoriteOrder, String>{

}
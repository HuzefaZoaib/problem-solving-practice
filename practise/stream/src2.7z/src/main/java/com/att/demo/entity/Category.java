package com.att.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Category")
public class Category {
	@Id
	@Column(name = "category_id")
	private int categoryid;
	
	@Column(name = "category_name")
	private String name ;

	@OneToMany(mappedBy = "categoryid", cascade = CascadeType.ALL)
    private List<SubCategory> subcategories;

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SubCategory> getSubcategories() {
		return subcategories;
	}

	public void setSubcategories(List<SubCategory> subcategories) {
		this.subcategories = subcategories;
	}
	
	public Integer getId() {
		return this.categoryid;
	}

	public void setId(Integer id) {
		this.categoryid = id;
	}
}

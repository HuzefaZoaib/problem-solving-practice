--
-- Function Mapping Table Alter
--
alter table functional_mapping
alter column parent type varchar(50);

alter table functional_mapping
alter column child type varchar(50);

--
-- Functional Mapping Initial Setup
--

insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Traffic History',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Market Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Submarket Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Line of Business Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Device Category Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','QCI Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Site Level Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Phase Level Traffic Forecast',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','Phase Level',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'root','RAN Capacity planning',1,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'RAN Capacity planning','Carrier Adds',2,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'RAN Capacity planning','Radio Swaps',2,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'RAN Capacity planning','Bandwidth Expansion',2,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'RAN Capacity planning','Spectrum Exhaust',2,true,'Approved','system');
insert into functional_mapping(id,parent,child,level,active,status,updated_by) values(nextval('functional_mapping_seq'),'RAN Capacity planning','What if Scenario',2,true,'Approved','system');


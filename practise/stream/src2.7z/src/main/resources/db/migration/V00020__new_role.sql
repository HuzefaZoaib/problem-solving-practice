--
-- New Roles
--
insert into role(id,name) values(1,'ACE Hub Admin');
insert into role(id,name) values(2,'ACE Hub Standard');

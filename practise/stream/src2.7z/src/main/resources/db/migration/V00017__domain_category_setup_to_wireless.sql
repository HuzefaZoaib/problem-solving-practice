--
-- Domain filter and Subfilter setup - Correction for Domain:Unknown to Wireless
--

-- Delete the previous mappings, which is to Unknown
delete from app_master_sub_filter where filter_id = 6 and
sub_filter_id in (select b.id from sub_filters b where filter_id=6 and sub_filter_name <> 'EIAP - rApps');

update "app_master" set "domain" = 'N/A' where "domain" <> 'EIAP - rApps' or domain is null;

-- Map the applications to the Domain.Unknown
insert into app_master_sub_filter(id, app_id, filter_id, sub_filter_id)
select NEXTVAL('app_master_sub_filter_seq'), app_id, filter_id, sub_filter_id from
(select a.id app_id from app_master a where a.domain <> 'EIAP - rApps') aa,
(select b.filter_id, b.id as sub_filter_id from sub_filters b where filter_id=6 and sub_filter_name='Wireless') bb;

-- --
update "app_master" set "domain" = 'Wireless' where "domain" <> 'EIAP - rApps';


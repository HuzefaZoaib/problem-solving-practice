--
-- Default Admin Users
--
insert into user_login(id,full_name,user_id) values(NEXTVAL('user_login_id_seq'),'HUZEFA ZOAIB','hz0208');
insert into user_login(id,full_name,user_id) values(NEXTVAL('user_login_id_seq'),'ABBAS FAZAL','af9900');
insert into user_login(id,full_name,user_id) values(NEXTVAL('user_login_id_seq'),'MARVIN CAMACHO','mc0733');

-- Huzefa Zoaib
insert into user_role(user_id,role_id) values((select id from user_login where user_id='hz0208'),1);
insert into user_role(user_id,role_id) values((select id from user_login where user_id='hz0208'),2);

-- Abbas Fazal
insert into user_role(user_id,role_id) values((select id from user_login where user_id='af9900'),1);
insert into user_role(user_id,role_id) values((select id from user_login where user_id='af9900'),2);

-- Marvin Camacho
insert into user_role(user_id,role_id) values((select id from user_login where user_id='mc0733'),1);
insert into user_role(user_id,role_id) values((select id from user_login where user_id='mc0733'),2);

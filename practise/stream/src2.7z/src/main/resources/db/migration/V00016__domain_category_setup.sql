--
-- Domain filter and Subfilter setup
--

insert into filter(id,filter_name) values(6, 'domain');

insert into sub_filters(id,filter_id,sub_filter_name) values(NEXTVAL('sub_filters_id_seq'),6,'Wireless');
insert into sub_filters(id,filter_id,sub_filter_name) values(NEXTVAL('sub_filters_id_seq'),6,'Other');
insert into sub_filters(id,filter_id,sub_filter_name) values(NEXTVAL('sub_filters_id_seq'),6,'EIAP - rApps');
insert into sub_filters(id,filter_id,sub_filter_name) values(NEXTVAL('sub_filters_id_seq'),6,'Unknown');

alter table app_master
add column if not exists domain varchar(100);

alter table app_master_audit
add column if not exists domain varchar(100);

-- Map the applications to the Domain.Unknown
insert into app_master_sub_filter(id, app_id, filter_id, sub_filter_id)
select NEXTVAL('app_master_sub_filter_seq'), app_id, filter_id, sub_filter_id from
(select a.id app_id from app_master a) aa,
(select b.filter_id, b.id as sub_filter_id from sub_filters b where filter_id=6 and sub_filter_name='Unknown') bb;


-- update the view so that the new column get reflected in the view
DROP VIEW if exists v_app_master;
CREATE VIEW v_app_master
 AS
select * from app_master mst inner join (
            select app_id, STRING_AGG(distinct keyword,'|') as keywords from keyword group by app_id) keyword
            on mst.id = keyword.app_id;

COMMENT ON VIEW v_app_master
    IS 'App Master along with piped separated keywords';


--
-- Update feature request workflow fields
-- status, rejection_reason
--

update feature_request
    set status = 'Under Review', updated_at = now(), updated_by_att_id = 'system'
where
    jira_issue_key is not null
    and deleted is null or deleted = false;


update feature_request
    set status = 'Submit'
where
    jira_issue_key is null
    and deleted is null or deleted = false;


update feature_request
    set status = 'Rejected', rejection_reason = 'Rejected by the system', updated_at = now(), updated_by_att_id = 'system'
where
    deleted = true;

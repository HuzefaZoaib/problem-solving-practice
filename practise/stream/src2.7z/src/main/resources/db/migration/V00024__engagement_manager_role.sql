--
-- New Engagement Manager Role
--
insert into role(id,name) values(3,'ACE Hub Engagement Manager');

--
-- Subfilter Table
-- Because now new subfilters are created by the user, we need to add a new column
--
alter table sub_filters
add column if not exists updated_by varchar(100) default 'system';

alter table sub_filters
add column if not exists app_id integer;

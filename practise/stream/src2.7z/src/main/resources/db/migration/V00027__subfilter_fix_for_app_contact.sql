--
-- There are lot irrelevant entries for App Contact filter in sub_filters table.
-- Therefore clearing those entries which are not yet mapped to any Application,
-- and then re-inserting the entries from fn_user table.
--

delete from sub_filters sf
where sf.filter_id=4 and
not exists (select 1 from app_master_sub_filter asf where asf.filter_id=sf.filter_id and asf.sub_filter_id=sf.id);


insert into sub_filters(id,filter_id,sub_filter_name)
select NEXTVAL('sub_filters_id_seq'),4,org_user_id from fn_user as attIds
where not exists(select 1 from sub_filters where filter_id=4 and sub_filter_name=attIds.org_user_id);


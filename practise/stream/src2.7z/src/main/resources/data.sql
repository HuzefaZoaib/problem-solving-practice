CREATE TABLE app_master (
itap_id INT PRIMARY KEY,
    category_id INT,
    subcategory_id INT,
    descriptionOneLine VARCHAR(255),
    description TEXT,
    image_url VARCHAR(50),
    useCases TEXT


)